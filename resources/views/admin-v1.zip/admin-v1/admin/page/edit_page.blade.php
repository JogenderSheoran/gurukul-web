@extends('admin.layouts.main')
@section('content')

<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <div id="kt_content_container" class="container-xxl">
            <div class="card mb-5 mb-xl-10">
                <div class="card-header border-0 cursor-pointer" role="button"
                     data-bs-toggle="collapse"
                     data-bs-target="#kt_account_profile_details"
                     aria-expanded="true"
                     aria-controls="kt_account_profile_details">
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">Edit Global Content</h3>
                    </div>
                </div>

                <div id="kt_account_profile_details" class="collapse show">
                    <form action="{{ route('global-contents.update', $content->id) }}"
                          method="POST"
                          enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="card-body border-top p-9">

                            <!-- Page Type -->
                            <div class="row mb-6">
                                <label class="col-lg-4 col-form-label required fw-bold fs-6">Section</label>
                                <div class="col-lg-8">
                                    <input type="text" name="page_type"
                                           class="form-control form-control-lg form-control-solid"
                                           value="{{ old('page_type', $content->page_type) }}" required />
                                </div>
                            </div>

                            <!-- Key -->
                            <div class="row mb-6">
                                <label class="col-lg-4 col-form-label required fw-bold fs-6">Content Key</label>
                                <div class="col-lg-8">
                                    <input type="text" name="key" id="keyField"
                                           class="form-control form-control-lg form-control-solid"
                                           value="{{ old('key', $content->key) }}" required />
                                </div>
                            </div>

                            <!-- Value Field -->
                            <div class="row mb-6">
                                <label class="col-lg-4 col-form-label required fw-bold fs-6">Content Value</label>
                                <div class="col-lg-8" id="valueInputContainer">
                                    @php
                                        $isImage = Str::contains($content->key, ['image', 'logo', 'banner']);
                                    @endphp

                                    @if($isImage)
                                        <input type="file" name="value" class="form-control mb-2" accept="image/*">
                                        <input type="hidden" name="old_value" value="{{ $content->value }}">
                                        <div>
                                            <img src="{{ asset('storage/' . $content->value) }}" width="100">
                                        </div>
                                    @else
                                        <textarea id="editor" name="value"
                                                  class="form-control form-control-lg form-control-solid"
                                                  rows="5">{{ old('value', $content->value) }}</textarea>
                                    @endif
                                </div>
                            </div>

                            <!-- Submit -->
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card-footer d-flex justify-content-end py-6 px-9">
                                        <button type="submit" class="btn btn-primary">Update Content</button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </form>
                </div> <!-- end collapse -->
            </div>
        </div>
    </div>
</div>

<!-- CKEditor CDN -->
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>

<!-- CKEditor Initialization (only if editor exists) -->
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const editorField = document.querySelector('#editor');
        if (editorField) {
            ClassicEditor
                .create(editorField)
                .catch(error => {
                    console.error('CKEditor init error:', error);
                });
        }
    });
</script>

@endsection
