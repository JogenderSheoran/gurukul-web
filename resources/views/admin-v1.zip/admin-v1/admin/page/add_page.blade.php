@extends('admin.layouts.main')
@section('content')

<!--begin::Content wrapper-->
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <div id="kt_content_container" class="container-xxl">
            <div class="card mb-5 mb-xl-10">
                <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse"
                    data-bs-target="#kt_account_profile_details" aria-expanded="true"
                    aria-controls="kt_account_profile_details">
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">Global Content Page</h3>
                    </div>
                </div>

                <div id="kt_account_profile_details" class="collapse show">
                    <form action="{{ route('global-contents.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body border-top p-9">

                            <!-- Page Type -->
                            <div class="row mb-6">
                                <label class="col-lg-4 col-form-label required fw-bold fs-6">Section</label>
                                <div class="col-lg-8">
                                    <input type="text" name="page_type"
                                        class="form-control form-control-lg form-control-solid"
                                        placeholder="e.g. home, about, contact" required />
                                </div>
                            </div>

                            <!-- Key -->
                            <div class="row mb-6">
                                <label class="col-lg-4 col-form-label required fw-bold fs-6">Content Key</label>
                                <div class="col-lg-8">
                                    <input type="text" name="key" id="keyField"
                                        class="form-control form-control-lg form-control-solid"
                                        placeholder="e.g. home_banner_title or about_image" required />
                                </div>
                            </div>

                            <!-- Content Value (dynamic textarea or image) -->
                            <div class="row mb-6" id="valueRow">
                                <label class="col-lg-4 col-form-label required fw-bold fs-6">Content Value</label>
                                <div class="col-lg-8" id="valueInputContainer">
                                    <textarea id="editor_default" name="value"
                                        class="form-control form-control-lg form-control-solid" rows="5"
                                        placeholder="Enter content..."></textarea>
                                </div>
                            </div>

                            <!-- Submit -->
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card-footer d-flex justify-content-end py-6 px-9">
                                        <button type="submit" class="btn btn-primary">Save Global Content</button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end::Content wrapper-->

<!-- JS Scripts directly at end -->
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>

<script>
    let editorInstance = null;

    async function destroyEditor() {
        if (editorInstance) {
            await editorInstance.destroy();
            editorInstance = null;
        }
    }

    function injectField(key, container) {
        container.innerHTML = '';

        if (
            key.includes("image") ||
            key.includes("logo") ||
            key.includes("banner") ||
            key.includes("hero_image") ||
            key.includes("background_image")
        ) {
            const input = document.createElement("input");
            input.type = "file";
            input.name = "value";
            input.className = "form-control";
            input.accept = "image/*";
            input.required = true;
            container.appendChild(input);
        } else {
            const uniqueId = "editor_" + Date.now(); // generate unique ID
            const textarea = document.createElement("textarea");
            textarea.id = uniqueId;
            textarea.name = "value";
            textarea.className = "form-control form-control-lg form-control-solid";
            textarea.placeholder = "Enter content...";
            textarea.rows = 5;
            container.appendChild(textarea);

            setTimeout(() => {
                ClassicEditor
                    .create(document.querySelector(`#${uniqueId}`))
                    .then(editor => {
                        editorInstance = editor;
                    })
                    .catch(error => {
                        console.error(error);
                    });
            }, 50);
        }
    }

    document.addEventListener("DOMContentLoaded", function () {
        const keyField = document.getElementById("keyField");
        const container = document.getElementById("valueInputContainer");

        keyField.addEventListener("input", async function () {
            const key = this.value.toLowerCase();
            await destroyEditor();
            injectField(key, container);
        });

        const initialKey = keyField.value.toLowerCase();
        injectField(initialKey, container);
    });
</script>
<script>
document.querySelector('form').addEventListener('submit', function (e) {
    if (editorInstance) {
        const value = editorInstance.getData().trim();
        if (value === '') {
            alert('Content value is required.');
            e.preventDefault();
        }
    }
});
</script>

@endsection
