@extends('admin-v1.layouts.header')

@section('title', $title)

@section('content')
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">{{ $title }}</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ route('admin-v1.dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Driver Notifications</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <!-- Statistics Cards -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3>{{ $totalNotifications }}</h3>
                        <p>Total Notifications</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-bell"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3>{{ $sentNotifications }}</h3>
                        <p>Sent Successfully</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3>{{ $failedNotifications }}</h3>
                        <p>Failed</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-times-circle"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3>{{ $activeDrivers }}</h3>
                        <p>Active Drivers</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Send Notification Card -->
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-paper-plane mr-2"></i>Send New Notification</h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <form id="sendNotificationForm" enctype="multipart/form-data" onsubmit="return false;">
                @csrf
                <div class="card-body">
                    <div class="form-group">
                        <label for="title">Notification Title <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="Enter notification title" required>
                    </div>

                    <div class="form-group">
                        <label for="message">Notification Message <span class="text-danger">*</span></label>
                        <textarea class="form-control" id="message" name="message" rows="3" placeholder="Enter notification message" required></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="site_type">Driver Type <span class="text-danger">*</span></label>
                                <select class="form-control" id="site_type" name="site_type" required>
                                    <option value="all">All Drivers</option>
                                    <option value="1">On-Site</option>
                                    <option value="2">Off-Site</option>
                                    <option value="3">On-Site Callers</option>
                                </select>
                                <small class="form-text text-muted">Select which type of drivers should receive this notification</small>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="image">Notification Image (Optional)</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="image" name="image" accept="image/*">
                                    <label class="custom-file-label" for="image">Choose image...</label>
                                </div>
                                <small class="form-text text-muted">Max size: 2MB. Formats: JPG, PNG, GIF</small>
                            </div>
                        </div>
                    </div>

                    <!-- Image Preview -->
                    <div class="form-group" id="image_preview_container" style="display: none;">
                        <label>Image Preview</label>
                        <div>
                            <img id="image_preview" src="" alt="Preview" class="img-thumbnail" style="max-width: 300px;">
                            <button type="button" class="btn btn-sm btn-danger ml-2" id="remove_image">
                                <i class="fas fa-times"></i> Remove
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary" id="sendBtn">
                        <i class="fas fa-paper-plane mr-1"></i> Send Notification
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-redo mr-1"></i> Reset
                    </button>
                </div>
            </form>
        </div>

        <!-- Notifications History -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-history mr-2"></i>Notifications History</h3>
            </div>
            <div class="card-body">
                <!-- Filters -->
                <div class="row mb-3">
                    <div class="col-md-2">
                        <select class="form-control" id="filter_site_type">
                            <option value="">All Driver Types</option>
                            <option value="all">All Drivers</option>
                            <option value="1">On-Site</option>
                            <option value="2">Off-Site</option>
                            <option value="3">On-Site Callers</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select class="form-control" id="filter_status">
                            <option value="">All Status</option>
                            <option value="sent">Sent</option>
                            <option value="failed">Failed</option>
                            <option value="pending">Pending</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="date" class="form-control" id="filter_date_from" placeholder="From Date">
                    </div>
                    <div class="col-md-3">
                        <input type="date" class="form-control" id="filter_date_to" placeholder="To Date">
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-primary btn-block" id="applyFilters">
                            <i class="fas fa-filter mr-1"></i> Apply Filters
                        </button>
                    </div>
                </div>

                <div class="table-responsive">
                    <table id="notificationsTable" class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title & Message</th>
                                <th>Driver Type</th>
                                <th>Recipients</th>
                                <th>Status</th>
                                <th>Sent By</th>
                                <th>Sent At</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- View Notification Modal -->
<div class="modal fade" id="viewNotificationModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title"><i class="fas fa-eye mr-2"></i>Notification Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="notificationDetailsContent">
                <div class="text-center">
                    <i class="fas fa-spinner fa-spin fa-3x"></i>
                    <p class="mt-2">Loading...</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {

    // Handle image selection
    $('#image').on('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#image_preview').attr('src', e.target.result);
                $('#image_preview_container').show();
            }
            reader.readAsDataURL(file);
            
            // Update label
            $(this).next('.custom-file-label').html(file.name);
        }
    });

    // Remove image
    $('#remove_image').on('click', function() {
        $('#image').val('');
        $('#image_preview').attr('src', '');
        $('#image_preview_container').hide();
        $('.custom-file-label').html('Choose image...');
    });

    // Send notification form
    $('#sendNotificationForm').on('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const sendBtn = $('#sendBtn');
        
        sendBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin mr-1"></i> Sending...');
        
        $.ajax({
            url: '{{ route("admin-v1.driver-notifications.send") }}',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: response.message,
                    timer: 3000,
                    showConfirmButton: false
                });
                
                $('#sendNotificationForm')[0].reset();
                $('#image_preview_container').hide();
                $('.custom-file-label').html('Choose image...');
                
                // Reload table
                notificationsTable.ajax.reload();
            },
            error: function(xhr) {
                let errorMessage = 'Failed to send notification';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }
                
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: errorMessage
                });
            },
            complete: function() {
                sendBtn.prop('disabled', false).html('<i class="fas fa-paper-plane mr-1"></i> Send Notification');
            }
        });
    });

    // Initialize DataTable
    const notificationsTable = $('#notificationsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("admin-v1.driver-notifications.data") }}',
            data: function(d) {
                d.site_type = $('#filter_site_type').val();
                d.status = $('#filter_status').val();
                d.date_from = $('#filter_date_from').val();
                d.date_to = $('#filter_date_to').val();
            }
        },
        columns: [
            { data: 'id', name: 'id' },
            { data: 'title', name: 'title' },
            { data: 'site_type', name: 'site_type' },
            { data: 'recipients', name: 'recipients' },
            { data: 'status', name: 'status' },
            { data: 'sent_by', name: 'sent_by' },
            { data: 'sent_at', name: 'sent_at' },
            { data: 'created_at', name: 'created_at' },
            { data: 'actions', name: 'actions', orderable: false, searchable: false }
        ],
        order: [[7, 'desc']],
        pageLength: 25,
        responsive: true
    });

    // Apply filters
    $('#applyFilters').on('click', function() {
        notificationsTable.ajax.reload();
    });

    // View notification details
    $(document).on('click', '.view-notification', function() {
        const notificationId = $(this).data('id');
        
        $('#viewNotificationModal').modal('show');
        $('#notificationDetailsContent').html(`
            <div class="text-center">
                <i class="fas fa-spinner fa-spin fa-3x"></i>
                <p class="mt-2">Loading...</p>
            </div>
        `);
        
        $.ajax({
            url: '{{ route("admin-v1.driver-notifications.show", ":id") }}'.replace(':id', notificationId),
            type: 'GET',
            success: function(response) {
                const notification = response.data;
                const sentBy = notification.sent_by || {};
                const siteTypeLabels = {
                    1: 'On-Site',
                    2: 'Off-Site',
                    3: 'On-Site Callers',
                    null: 'All Drivers'
                };
                const siteTypeLabel = siteTypeLabels[notification.site_type] || 'Unknown';
                
                let html = `
                    <div class="row">
                        <div class="col-md-6">
                            <h6><strong>Title:</strong></h6>
                            <p>${notification.title}</p>
                        </div>
                        <div class="col-md-6">
                            <h6><strong>Driver Type:</strong></h6>
                            <p><span class="badge badge-primary">${siteTypeLabel}</span></p>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-12">
                            <h6><strong>Message:</strong></h6>
                            <p>${notification.message}</p>
                        </div>
                    </div>
                    
                    ${notification.image ? `
                    <div class="row mt-3">
                        <div class="col-12">
                            <h6><strong>Image:</strong></h6>
                            <img src="${window.location.origin}/storage/${notification.image}" class="img-fluid" style="max-width: 400px;">
                        </div>
                    </div>
                    ` : ''}
                    
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <h6><strong>Total Recipients:</strong></h6>
                            <p><span class="badge badge-info">${notification.total_recipients} drivers</span></p>
                        </div>
                        <div class="col-md-6">
                            <h6><strong>Status:</strong></h6>
                            <p>${notification.status === 'sent' ? '<span class="badge badge-success">Sent</span>' : 
                                 notification.status === 'failed' ? '<span class="badge badge-danger">Failed</span>' : 
                                 '<span class="badge badge-warning">Pending</span>'}</p>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <h6><strong>Sent By:</strong></h6>
                            <p>${sentBy.name || 'System'}</p>
                        </div>
                        <div class="col-md-6">
                            <h6><strong>Sent At:</strong></h6>
                            <p>${notification.sent_at || 'N/A'}</p>
                        </div>
                    </div>
                    
                    ${notification.error_message ? `
                    <div class="row mt-3">
                        <div class="col-12">
                            <h6><strong>Error Message:</strong></h6>
                            <div class="alert alert-danger">${notification.error_message}</div>
                        </div>
                    </div>
                    ` : ''}
                `;
                
                $('#notificationDetailsContent').html(html);
            },
            error: function() {
                $('#notificationDetailsContent').html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle mr-2"></i>
                        Failed to load notification details
                    </div>
                `);
            }
        });
    });

    // Delete notification
    $(document).on('click', '.delete-notification', function() {
        const notificationId = $(this).data('id');
        
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '{{ route("admin-v1.driver-notifications.destroy", ":id") }}'.replace(':id', notificationId),
                    type: 'DELETE',
                    data: {
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Deleted!',
                            text: response.message,
                            timer: 2000,
                            showConfirmButton: false
                        });
                        
                        notificationsTable.ajax.reload();
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Failed to delete notification'
                        });
                    }
                });
            }
        });
    });

});
</script>
@endpush
