@extends('admin.layouts.main')
@section('content')
    <!--begin::Content wrapper-->
    <div class="d-flex flex-column flex-column-fluid">
        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
            <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
                <!--begin::Page title-->
                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                    <!--begin::Breadcrumb-->
                    <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                        <!--begin::Item-->
                        <li class="breadcrumb-item text-muted">
                            <a href="#" class="text-dark text-hover-primary">Home</a>
                        </li>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item">
                            <span class="bullet bg-gray-400 w-5px h-2px"></span>
                        </li>
                        <li class="breadcrumb-item">Driver</li>
                    </ul>
                    <!--end::Breadcrumb-->
                </div>
                <div class="d-flex align-items-center py-1">
                    <!--begin::Wrapper-->
                    <div class="me-4">
                        <!--end::Menu 1-->
                        <!--end::Menu-->
                    </div>
                    <!--end::Wrapper-->
                    <!--begin::Button-->
                    <a href="{{route('admin.add_driver')}}" class="btn btn-sm btn-primary" id="kt_toolbar_primary_button">Add Driver</a>
                    <!--end::Button-->
                </div>
                <!--end::Page title-->
            </div>
        </div>
        <!--begin::Content-->
        <div id="kt_app_content" class="app-content flex-column-fluid">
            <!--begin::Content container-->
            <div id="kt_app_content_container" class="app-container container-xxl">
                <!--begin::Tables Widget 11-->
                <div class="card mb-5 mb-xl-8">
                    <!--begin::Header-->
                    <div class="card-header border-0 pt-5">
                        <h3 class="card-title align-items-start flex-column">
                            <span class="card-label fw-bold fs-3 mb-1">Driver List</span>
                        </h3>
                        <i class="ki-duotone ki-magnifier fs-1 position-absolute ms-6"><span class="path1"></span><span class="path2"></span></i>
		                <input type="text" data-kt-docs-table-filter="search"  class="form-control form-control-solid w-250px ps-15" placeholder="Search....."/>
                    </div>
                    <!--end::Header-->
                    <!--begin::Body-->
                    <div class="card-body py-3">
                        <!--begin::Table container-->
                        <div class="table-responsive">
                            <!--begin::Table-->
                            <table  id="kt_datatable_example_1" class="table align-middle table-row-dashed fs-6 gy-5">
                            <thead>
                                <tr class="fw-bold text-dark bg-light">
                                    <th class="ps-4 min-w-100px rounded-start"><b>Name</b></th>
                                    <th class="min-w-100px"><b>Mobile</b></th>
                                    <th class="min-w-100px"><b>Pin</b></th>
                                    <th class="min-w-100px"><b>Site</b></th>
                                    <th class="min-w-100px"><b>Ambulance</b></th>
                                    <th class="min-w-100px"><b>Vehicle</b></th>
                                    <th class="min-w-100px"><b>Type</b></th>
                                    <th clsas="min-w-200px"><b>City</b></th>
                                    <th class="min-w-100px"><b>State</b></th>
                                    <th class="min-w-100px"><b>Group</b></th>
                                    <th class="min-w-100px"><b>Serving Area</b></th>
                                    <th class="min-w-100px"><b>Status</b></th>
                                    <th class="min-w-100px"><b>Priority</b></th>
                                    <th class="min-w-100px"><b>Action</b></th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-600 fw-semibold">

                            </tbody>
                                <!--end::Table body-->
                            </table>

                            <!--end::Table-->
                        </div>
                        <!--end::Table container-->
                    </div>
                    <!--begin::Body-->
                </div>
                <!--end::Tables Widget 11-->
            </div>
            <!--end::Content container-->
        </div>
        <!--end::Content-->
    </div>
    <!--end::Content wrapper-->


    <div class="modal fade" tabindex="-1" id="kt_modal_1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Confirmation</h3>
                    <!--begin::Close-->
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ki-duotone ki-cross fs-1"><span class="path1"></span><span class="path2"></span></i>
                    </div>
                    <!--end::Close-->
                </div>

                <div class="modal-body">
                    <p>Are you sure you want to delete this User?</p>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <a href="" class="btn btn-primary" id="save_button">Delete</a>
                </div>
            </div>
        </div>
    </div>

@endsection

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        var dt = $("#kt_datatable_example_1").DataTable({
            "fixedHeader": {
                "header":true,
            },
            processing: true,
            serverSide: true,
            order: false,
            ajax: "{{ route('admin.driverlist') }}",
            columns: [
                {data: 'first_name', name: 'first_name'},
                {data: 'mobile', name: 'mobile'},
                {data: 'pin', name: 'pin'},
                {data: 'site', name: 'site'},
                {data: 'ambulance_type', name: 'ambulance_type'},
                {data: 'vehicle_type', name: 'vehicle_type'},
                {data: 'type', name: 'type'},
                {data: 'city', name: 'city'},
                {data: 'state', name: 'state'},
                {data: 'group', name: 'group'},
                {data: 'serving_area', name: 'serving_area'},
                {data: 'status', name: 'status'},
                {data: 'priority', name: 'priority'},
                {
                    data: 'action',
                    name: 'action',
                    orderable: true,
                    searchable: true
                },
            ]
        });

 $('[data-kt-docs-table-filter="search"]').on('keyup', function () {
        console.log("Search input changed");
        console.log("Search value:", $(this).val());
        dt.search($(this).val()).draw();
        });
    });
</script>

