@extends('admin.layouts.main')
@section('content')
@php
$states = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
    'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
    'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
    'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
    'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal'
];
@endphp
<style>
        .preview-container {
            display: flex;
            flex-wrap: wrap;
        }
        .preview {
            margin: 10px;
            width: 100px;
            height: 100px;
            border: 1px solid #ccc;
            overflow: hidden;
        }
        .preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
</style>
<!--begin::Content wrapper-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Toolbar-->
    <!--end::Toolbar-->
    <!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">

        @if ($errors->any())
            <div class="alert alert-danger">
                <strong>Whoops! Something went wrong.</strong>
                <ul class="mb-0 mt-2">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

            <!--begin::Basic info-->
            <div class="card mb-5 mb-xl-10">
                <!--begin::Card header-->
                <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse"
                    data-bs-target="#kt_account_profile_details" aria-expanded="true"
                    aria-controls="kt_account_profile_details">
                    <!--begin::Card title-->
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">Add Driver</h3>
                    </div>
                    <!--end::Card title-->
                </div>
                <!--begin::Card header-->
                <!--begin::Content-->
                <div id="kt_account_profile_details" class="collapse show">
                    <!--begin::Form-->
                    <form action="{{ route('admin._add_driver') }}" method="post" enctype="multipart/form-data">
                     @csrf
                        <!--begin::Card body-->
                        <div class="card-body border-top p-9">
                            <!--begin::Input group-->
                            <div class="row mb-6">
                                <!--begin::Label-->
                                {{-- <label class="col-lg-4 col-form-label fw-bold fs-6">Avatar</label>--}}
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8">
                                    <!--begin::Image input-->
                                    {{--<div class="image-input image-input-outline" data-kt-image-input="true"
                                        style="background-image: url(assets/media/avatars/blank.png)">
                                        <!--begin::Preview existing avatar-->
                                        <div class="image-input-wrapper w-125px h-125px"
                                            style="background-image: url(assets/media/avatars/150-26.jpg)"></div>
                                        <!--end::Preview existing avatar-->
                                        <!--begin::Label-->
                                        <label
                                            class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                            data-kt-image-input-action="change" data-bs-toggle="tooltip"
                                            title="Change avatar">
                                            <i class="bi bi-pencil-fill fs-7"></i>
                                            <!--begin::Inputs-->
                                            <input type="file" name="avatar" accept=".png, .jpg, .jpeg" />
                                            <input type="hidden" name="avatar_remove" />
                                            <!--end::Inputs-->
                                        </label>
                                        <!--end::Label-->
                                        <!--begin::Cancel-->
                                        <span
                                            class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                            data-kt-image-input-action="cancel" data-bs-toggle="tooltip"
                                            title="Cancel avatar">
                                            <i class="bi bi-x fs-2"></i>
                                        </span>
                                        <!--end::Cancel-->
                                        <!--begin::Remove-->
                                        <span
                                            class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                            data-kt-image-input-action="remove" data-bs-toggle="tooltip"
                                            title="Remove avatar">
                                            <i class="bi bi-x fs-2"></i>
                                        </span>
                                        <!--end::Remove-->
                                    </div>
                                    <!--end::Image input-->
                                    <!--begin::Hint-->
                                    <div class="form-text">Allowed file types: png, jpg, jpeg.</div>
                                    <!--end::Hint-->
                                </div>--}}
                                    <!--end::Col-->
                                </div>
                                <!--end::Input group-->
                                <!--begin::Input group-->
                                <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label required fw-bold fs-6">
                                        Name</label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8">
                                        <!--begin::Row-->
                                        <div class="row">
                                            <!--begin::Col-->
                                            <div class="col-lg-12 fv-row">
                                                <input type="text" name="first_name"
                                                    class="form-control form-control-lg form-control-solid mb-3 mb-lg-0"
                                                    placeholder="Name" 
                                                    value="{{ old('first_name') }}" 
                                                    required />
                                            </div>

                                            <!--end::Col-->
                                        </div>
                                        <!--end::Row-->
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label required fw-bold fs-6">
                                        Mobile</label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8">
                                        <!--begin::Row-->
                                        <div class="row">
                                            <!--begin::Col-->
                                            <div class="col-lg-12 fv-row">
                                                <input type="text" name="mobile_number"
                                                    class="form-control form-control-lg form-control-solid mb-3 mb-lg-0"
                                                    placeholder="Mobile No" value="{{ old('mobile_number') }}"  required />
                                            </div>
                                            <!--end::Col-->
                                        </div>
                                        <!--end::Row-->
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label required fw-bold fs-6">
                                        Pin</label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8">
                                        <!--begin::Row-->
                                        <div class="row">
                                            <!--begin::Col-->
                                            <div class="col-lg-12 fv-row">
                                                <input type="number" name="pin"
                                                    class="form-control form-control-lg form-control-solid mb-3 mb-lg-0"
                                                    placeholder="Enter 6 digit pin" value="{{ old('pin') }}"  required />
                                            </div>
                                            <!--end::Col-->
                                        </div>
                                        <!--end::Row-->
                                    </div>
                                    <!--end::Col-->
                                </div>
                               {{-- <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label required fw-bold fs-6">
                                        Pin</label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8">
                                        <!--begin::Row-->
                                        <div class="row">
                                            <!--begin::Col-->
                                            <div class="col-lg-12 fv-row">
                                                <input type="text" name="pin" id="pin"
                                                    class="form-control form-control-lg form-control-solid mb-3 mb-lg-0"
                                                    placeholder="Pin" required />
                                            </div>
                                            <div id="pin-error" class="text-danger"></div>
                                            <!--end::Col-->
                                        </div>
                                        <!--end::Row-->
                                    </div>
                                    <!--end::Col-->
                                </div>--}}
                                <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label required fw-bold fs-6"> Select Ambulance
                                    </label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8 fv-row">
                                        <select name="vehicle_category_id[]" aria-label="Select a Type"
                                            data-placeholder="Select a vehicle category..."
                                            class="form-select form-select-solid" data-control="select2" data-hide-search="false" multiple required>
                                            <option value="">Ambulance Type</option>
                                            @foreach($vehicle as $v)
                                                <option value="{{$v->id}}" 
                                                    {{ in_array($v->id, old('vehicle_category_id', [])) ? 'selected' : '' }}>
                                                    {{$v->name}}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <!--end::Col-->
                                </div>

                                <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label required fw-bold"> Vehicle Type
                                    </label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8">
                                        <select name="vehicle_type[]" aria-label="Select Vehicle Type"
                                            class="form-select form-select-solid" data-control="select2" data-hide-search="false" multiple required>
                                            <option value="">Vehicle Type</option>
                                            <option value="Echo" {{ in_array('Echo', old('vehicle_type', [])) ? 'selected' : '' }}>Echo</option>
                                            <option value="Bolero" {{ in_array('Bolero', old('vehicle_type', [])) ? 'selected' : '' }}>Bolero</option>
                                            <option value="Tempo" {{ in_array('Tempo', old('vehicle_type', [])) ? 'selected' : '' }}>Tempo Traveller</option>
                                        </select>
                                    </div>
                                    <!--end::Col-->
                                </div>


                                <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label required fw-bold"> Site Type
                                    </label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8">
                                        <select name="site_type" aria-label="Select Site Type"
                                            class="form-select form-select-solid" data-control="select2" data-hide-search="false" required>
                                            <option value="">Site Type</option>
                                            <option value="1" {{ old('site_type') == '1' ? 'selected' : '' }}>On-Site</option>
                                            <option value="2" {{ old('site_type') == '2' ? 'selected' : '' }}>Off-Site</option>
                                            <option value="3" {{ old('site_type') == '3' ? 'selected' : '' }}>On-Site Callers</option>
                                        </select>
                                    </div>
                                    <!--end::Col-->
                                </div>

                                
                                <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label required fw-bold fs-6">City
                                    </label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8 fv-row">
                                        <select class="form-select form-select-solid" data-control="select2" data-hide-search="false" data-placeholder="Select City..." name="city" aria-label="Select a City" required>
                                            <option value="">Select a city...</option>
                                            @foreach($city as $c)
                                                <option value="{{ $c->id }}" {{ old('city') == $c->id ? 'selected' : '' }}>{{ $c->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <!--end::Col-->
                                </div>

                                <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label required fw-bold fs-6">State
                                    </label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8">
                                        <!--begin::Row-->
                                        <div class="row">
                                            <!--begin::Col-->
                                            <div class="col-lg-12 fv-row">
                                                <select class="form-select form-select-solid" data-control="select2" data-hide-search="false" data-placeholder="Select State..." name="state" aria-label="Select a State" required>
                                                    <option></option> <!-- Placeholder for Select2 -->
                                                    @foreach($states as $state)
                                                        <option value="{{ $state }}" {{ old('state') == $state ? 'selected' : '' }}>{{ $state }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <!--end::Col-->
                                        </div>
                                        <!--end::Row-->
                                    </div>
                                    <!--end::Col-->
                                </div>

                                <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label required fw-bold fs-6">
                                    Serving Area</label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8 fv-row">
                                    <input type='text' id="serving_area" name="serving_area" placeholder="Serving Area"
                                        class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" value="{{ old('serving_area') }}" required/>
                                </div>
                                <!--end::Col-->
                            </div>

                            <div class="row mb-6">
    <!--begin::Label-->
    <label class="col-lg-4 col-form-label required fw-bold fs-6">Priority</label>
    <!--end::Label-->
    <!--begin::Col-->
    <div class="col-lg-8 fv-row">
        <select name="priority" aria-label="Select a Type"
            data-placeholder="Select a city..."
            class="form-select form-select-solid form-select-lg" required>
            <option value="local" {{ old('priority') == 'local' ? 'selected' : '' }}>Local</option>
            <option value="outstation" {{ old('priority') == 'outstation' ? 'selected' : '' }}>Out Station</option>
            <option value="both" {{ old('priority') == 'both' ? 'selected' : '' }}>Both</option>
        </select>
    </div>
    <!--end::Col-->
</div>

<div class="row mb-6">
    <!--begin::Label-->
    <label class="col-lg-4 col-form-label required fw-bold fs-6">Type</label>
    <!--end::Label-->
    <!--begin::Col-->
    <div class="col-lg-8 fv-row">
        <select name="type" aria-label="Select a Type" onchange="getGroup()" id="groupdata"
            data-placeholder="Select a Type..."
            class="form-select form-select-solid form-select-lg" required>
            <option value="group" {{ old('type') == 'group' ? 'selected' : '' }}>Group</option>
            <option value="individual" {{ old('type') == 'individual' ? 'selected' : '' }}>Individual</option>
        </select>
    </div>
    <!--end::Col-->
</div>

<div class="row mb-6" id="groupList" style="display: none;">
    <!--begin::Label-->
    <label class="col-lg-4 col-form-label required fw-bold fs-6">Group List</label>
    <!--end::Label-->
    <!--begin::Col-->
    <div class="col-lg-8 fv-row">
        <select name="group" aria-label="Select a Group"
            data-placeholder="Select a Group..."
            class="form-select form-select-solid form-select-lg">
        </select>
    </div>
    <!--end::Col-->
</div>

                                <div class="card card-flush py-4">
                                    <!--begin::Card header-->
                                    <div class="card-header">
                                        <!--begin::Card title-->
                                        <div class="card-title">
                                            <h2>Vehicle Image</h2>
                                        </div>
                                        <!--end::Card title-->
                                    </div>
                                    <!--end::Card header-->
                                    <!--begin::Card body-->
                                    <div class="card-body text-center pt-0">
                                        <!--end::Image input placeholder-->
                                        <div class="image-input image-input-empty image-input-outline image-input-placeholder mb-3"
                                            data-kt-image-input="true">
                                            <!--begin::Preview existing avatar-->
                                            <div class="image-input-wrapper w-150px h-150px"></div>
                                            <!--end::Preview existing avatar-->
                                            <!--begin::Label-->
                                            <label
                                                class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                                data-kt-image-input-action="change" data-bs-toggle="tooltip"
                                                title="Change avatar">
                                                <i class="bi bi-pencil-fill fs-7"></i>
                                                <!--begin::Inputs-->
                                                <input type="file" name="images[]" accept=".png, .jpg, .jpeg" multiple required />
                                                <input type="hidden" name="avatar_remove" />
                                                <!--end::Inputs-->
                                            </label>
                                           
                                        </div>
                                        <!--end::Image input-->
                                        <!--begin::Description-->
                                        <div class="text-muted fs-7">Set the course thumbnail image. Only *.png, *.jpg
                                            and *.jpeg image files are accepted</div>
                                        <!--end::Description-->
                                    </div>
                                    <!--end::Card body-->
                                </div>
                            </div>
                            <div class="preview-container" id="preview-container"></div>
                            <!--end::Card body-->
                            <!--begin::Actions-->
                            <div class="card-footer d-flex justify-content-end py-6 px-9">
                                <button type="submit" class="btn btn-primary"
                                    id="kt_account_profile_details_submit">Save
                                    Changes</button>
                            </div>
                            <!--end::Actions-->
                        </div>
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Content-->
            </div>
            <!--end::Basic info-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
</div>
<!--end::Content wrapper-->

@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#pin').on('input', function() {
        var pin = $(this).val();
        var pinError = $('#pin-error');

        // Remove non-numeric characters
        pin = pin.replace(/\D/g, '');
        
        // Limit length to 6 characters
        if (pin.length > 6) {
            pin = pin.substring(0, 6);
        }

        $(this).val(pin);

        pinError.text(''); // Clear any previous error messages
        if (pin.length !== 6) {
            pinError.text('The pin must be exactly 6 digits.');
        }
    });

    $('#pin').on('keypress', function(e) {
        var key = e.which || e.keyCode;
        // Allow only numeric characters
        if ((key < 48 || key > 57) && key !== 8 && key !== 46) {
            e.preventDefault();
        }
    });
});
</script>

<script>
  function getGroup(){
            const selectedValue = $('#groupdata').val();
            
            if (selectedValue === 'group') {
                $.ajax({
                    url: '{{route("admin.getgroup")}}',
                    method: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(data) {
                        $('select[name="group"]').empty();
                        if (data.data && data.data.length > 0) {
                            $.each(data.data, function(key, group) {
                                console.log("check the group", group);
                                $('select[name="group"]').append(
                                    $('<option></option>').attr('value', group.id).text(group.name)
                                );
                            });

                            $('select[name="group"]').prop('required', true);
                            $('#groupList').show();
                        } else {
                            $('select[name="group"]').prop('required', false);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error fetching group data:', error);
                    }
                });
            }
            else {
                $('#groupList').hide();
                $('select[name="group"]').empty();
            }
        }
</script>
<script>
 $(document).ready(function() {
    $('input[type="file"]').on('change', function(event) {
        const files = event.target.files;
        const previewContainer = $('#preview-container');
        previewContainer.empty();

        for (let i = 0; i < files.length; i++) {
            const file = files[i];

            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const previewDiv = $('<div>').addClass('preview');
                    const img = $('<img>').attr('src', e.target.result);

                    previewDiv.append(img);
                    previewContainer.append(previewDiv);
                };
                reader.readAsDataURL(file);
            }
        }
    });
});
</script>
@section('js')

<script>
function setloader() {
    $('.indicator-label').hide();
    $('.indicator-progress').show();
}

$(document).ready(function() {
    $('.select2').select2({
        placeholder: 'Select a city...',
        allowClear: true
    });
});

$(document).ready(function() {

    var checkedValue = $("input[name='type']:checked").val();

    if (checkedValue == 'link') {
        $('#my_link').prop('required', true);
    } else if (checkedValue == 'course') {
        $('#my_course').prop('required', true);
    } else if (checkedValue == 'video') {
        $('#my_video').prop('required', true);
    } else if (checkedValue == 'pdf') {
        $('#my_pdf').prop('required', true);
    } else if (radioValue == 'category') {
        $('#my_category').prop('required', true);
    } else if (radioValue == 'deal') {
        $('#my_deal').prop('required', true);
    }

});
$(document).ready(function() {
    $('#pin').on('change', function() {
        var pin = $(this).val();
        var pinError = $('#pin-error');
        pinError.text(''); // Clear any previous error messages

        if (!/^\d{6}$/.test(pin)) {
            pinError.text('The pin must be exactly 6 digits.');
        }
    });
});

</script>
@endsection