@extends('admin.layouts.main')
@section('content')
    <!--begin::Content wrapper-->
    <div class="d-flex flex-column flex-column-fluid">
        <!--begin::Content-->
        <div id="kt_app_content" class="app-content flex-column-fluid">
            <!--begin::Content container-->
            <div id="kt_app_content_container" class="app-container container-xxl">
                <!--begin::Tables Widget 11-->
                <div class="card mb-5 mb-xl-8">
                    <!--begin::Header-->
                    <div class="card-header border-0 pt-5">
                        <h3 class="card-title align-items-start flex-column">
                            <span class="card-label fw-bold fs-3 mb-1">Driver Transaction</span>
                        </h3>
                    </div>
                    <!--end::Header-->
                    <!--begin::Body-->
                    <div class="card-body py-3">
                        <!--begin::Table container-->
                        <div class="table-responsive">
                            <input type="hidden" id="driver_id" value="{{$driver_id}}">
                            <!--begin::Table-->
                            <table  id="kt_datatable_example_1" class="table align-middle table-row-dashed fs-6 gy-5">
                            <thead>
                                <tr class="fw-bold text-muted bg-light">
                                    <th class="ps-4 min-w-100px rounded-start">Driver Name</th>
                                    <th class="min-w-100px">Withdrawl/Deposit</th>
                                    <th clsas="min-w-200px">Amount</th>
                                    <th clsas="min-w-200px">Date</th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-600 fw-semibold">
                            
                            </tbody>
                                <!--end::Table body-->
                            </table>
                           
                            <!--end::Table-->
                        </div>
                        <!--end::Table container-->
                    </div>
                    <!--begin::Body-->
                </div>
                <!--end::Tables Widget 11-->
            </div>
            <!--end::Content container-->
        </div>
        <!--end::Content-->
    </div>
    <!--end::Content wrapper-->


    <div class="modal fade" tabindex="-1" id="kt_modal_1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Confirmation</h3>
                    <!--begin::Close-->
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ki-duotone ki-cross fs-1"><span class="path1"></span><span class="path2"></span></i>
                    </div>
                    <!--end::Close-->
                </div>

                <div class="modal-body">
                    <p>Are you sure you want to delete this User?</p>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <a href="" class="btn btn-primary" id="save_button">Delete</a>
                </div>
            </div>
        </div>
    </div>

@endsection
  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        var dt = $("#kt_datatable_example_1").DataTable({
            "fixedHeader": {
                "header":true,
            },
            processing: true,
            serverSide: true,
            order: [[3, 'desc']],
            ajax: {
            url: '{{route("admin.driverTransactionList")}}',
            type: "POST",
            data:{'driver_id':$("#driver_id").val(),"_token": "{{ csrf_token() }}",}
            },
            columns: [
                {data: 'driver_name', name: 'driver_name'},
                {data: 'withdrawal_deposit', name: 'withdrawal_deposit'},
                {data: 'amount', name: 'amount'},
                {data: 'date', name: 'date'},
            ]
        });
    });
</script>

