@extends('admin.layouts.main')
@section('content')
<!--begin::Content wrapper-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Toolbar-->
    <!--end::Toolbar-->
    <!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">
            <!--begin::Basic info-->
            <div class="card mb-5 mb-xl-10">
                <!--begin::Card header-->
                <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse"
                    data-bs-target="#kt_account_profile_details" aria-expanded="true"
                    aria-controls="kt_account_profile_details">
                    <!--begin::Card title-->
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">Driver</h3>
                    </div>
                    <!--end::Card title-->
                </div>
                <!--begin::Card header-->
                <!--begin::Content-->
                <div id="kt_account_profile_details" class="collapse show">
                    <!--begin::Form-->
                    <form action="{{ route('admin.updateDriverStatus') }}" method="post" enctype="multipart/form-data">
                     @csrf
                        <input type="hidden" name="id" value="{{$data->id}}">
                        <!--begin::Card body-->
                        <div class="card-body border-top p-9">
                            <!--begin::Input group-->
                                <!--end::Input group-->
                                <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label required fw-bold fs-6">Select Status
                                        </label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8 fv-row">
                                        <select  aria-label="Select Status" name="profile_status"
                                            class="form-select form-select-solid form-select-lg" required>
                                            <option value="0" @if($data->profile_status==0) selected @endif>Pending</option>
                                            <option value="1" @if($data->profile_status==1) selected @endif>Accepted</option>
                                            <option value="2" @if($data->profile_status==2) selected @endif>Rejected</option>
                                        </select>
                                    </div>
                                    <!--end::Col-->
                                </div>
                            </div>
                            <!--end::Card body-->
                            <!--begin::Actions-->
                            <div class="card-footer d-flex justify-content-end py-6 px-9">
                                <button type="submit" class="btn btn-primary"
                                    id="kt_account_profile_details_submit">Save
                                    Changes</button>
                            </div>
                            <!--end::Actions-->

                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Content-->
            </div>
            <!--end::Basic info-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
</div>
<!--end::Content wrapper-->

@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

@section('js')

<script>
function setloader() {
    $('.indicator-label').hide();
    $('.indicator-progress').show();
}

$(document).ready(function() {

    var checkedValue = $("input[name='type']:checked").val();

    if (checkedValue == 'link') {
        $('#my_link').prop('required', true);
    } else if (checkedValue == 'course') {
        $('#my_course').prop('required', true);
    } else if (checkedValue == 'video') {
        $('#my_video').prop('required', true);
    } else if (checkedValue == 'pdf') {
        $('#my_pdf').prop('required', true);
    } else if (radioValue == 'category') {
        $('#my_category').prop('required', true);
    } else if (radioValue == 'deal') {
        $('#my_deal').prop('required', true);
    }

});
</script>

@endsection