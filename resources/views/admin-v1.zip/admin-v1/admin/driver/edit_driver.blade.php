@extends('admin.layouts.main')
@section('content')
@php 
$states = [
        'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
        'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
        'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
        'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
        'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal'
    ];
@endphp
<style>
        .preview-container {
            display: flex;
            flex-wrap: wrap;
        }
        .preview {
            margin: 10px;
            width: 100px;
            height: 100px;
            border: 1px solid #ccc;
            overflow: hidden;
        }
        .preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
</style>
<!--begin::Content wrapper-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Toolbar-->
    <!--end::Toolbar-->
    <!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">
            <!--begin::Basic info-->
            <div class="card mb-5 mb-xl-10">
                <!--begin::Card header-->
                <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse"
                    data-bs-target="#kt_account_profile_details" aria-expanded="true"
                    aria-controls="kt_account_profile_details">
                    <!--begin::Card title-->
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">Edit Driver</h3>
                    </div>
                    <!--end::Card title-->
                </div>
                <!--begin::Card header-->
                <!--begin::Content-->
                <div id="kt_account_profile_details" class="collapse show">
                    <!--begin::Form-->
                    <form action="{{ route('admin._update_driver') }}" method="post" enctype="multipart/form-data">
                     @csrf
                     <div class="card-body border-top p-9">
                        <input type="hidden" name="id" value="{{$data->id}}">
                       
                        <!--begin::Input group-->
                        <div class="row mb-6">
                            <!--begin::Label-->
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">Name</label>
                            <!--end::Label-->
                            <!--begin::Col-->
                            <div class="col-lg-8">
                                <!--begin::Row-->
                                <div class="row">
                                    <!--begin::Col-->
                                    <div class="col-lg-12 fv-row">
                                        <input type="text" name="first_name"
                                            class="form-control form-control-lg form-control-solid mb-3 mb-lg-0"
                                            placeholder="Name" value="{{ old('first_name', $data->first_name) }}" required />
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <!--end::Row-->
                            </div>
                            <!--end::Col-->
                        </div>
                        

                        <!-- Similar changes for other fields -->
                        <div class="row mb-6">
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">Mobile</label>
                            <div class="col-lg-8">
                                <div class="row">
                                    <div class="col-lg-12 fv-row">
                                        <input type="text" name="mobile_number"
                                            class="form-control form-control-lg form-control-solid mb-3 mb-lg-0"
                                            placeholder="Mobile No" value="{{ old('mobile', $data->mobile) }}" required />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-6">
                            <!--begin::Label-->
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">
                                Pin</label>
                            <!--end::Label-->
                            <!--begin::Col-->
                            <div class="col-lg-8">
                                <!--begin::Row-->
                                <div class="row">
                                    <!--begin::Col-->
                                    <div class="col-lg-12 fv-row">
                                        <input type="number" name="pin"
                                            class="form-control form-control-lg form-control-solid mb-3 mb-lg-0"
                                            placeholder="Enter 6 digit pin" value="{{$data->pin}}" required />
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <!--end::Row-->
                            </div>
                            <!--end::Col-->
                        </div>

                        {{--<div class="row mb-6">
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">
                                Pin</label>
                            <div class="col-lg-8">
                                <div class="row">
                                    <div class="col-lg-12 fv-row">
                                        <input type="text" name="pin" id="pin"
                                            class="form-control form-control-lg form-control-solid mb-3 mb-lg-0"
                                            placeholder="Pin" value="{{$data->pin}}" required />
                                    </div>
                                </div>
                                <div id="pin-error" class="text-danger"></div>
                            </div>
                        </div>--}}
                       
                        @php $vehicle_ids = json_decode($data->vehicle_category_id,true); @endphp
                        <div class="row mb-6">
                        <label class="col-lg-4 col-form-label required fw-bold fs-6">Select Ambulance</label>
                        <div class="col-lg-8 fv-row">
                            <select name="vehicle_category_id[]" aria-label="Select a Type"
                                data-placeholder="Select a vehicle category..."
                                class="form-select form-select-solid" data-control="select2" multiple required>
                               
                                @foreach($vehicle as $v)
                                    <option value="{{ $v->id }}"   {{ in_array($v->id,  $vehicle_ids) ? 'selected' : '' }}>
                                    {{ $v->name }}>
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    @php 
                        $vehicle_type = json_decode($data->vehicle_type, true); 
                    @endphp
                    <div class="row mb-6">
                        <!--begin::Label-->
                        <label class="col-lg-4 col-form-label required fw-bold">Vehicle Type</label>
                        <!--end::Label-->
                        <!--begin::Col-->
                        <div class="col-lg-8">
                            <select name="vehicle_type[]" aria-label="Select Vehicle Type"
                                class="form-select form-select-solid" data-control="select2" data-hide-search="false" multiple required>
                                <option value="" disabled>Select Vehicle Type</option>
                                <option value="Echo" {{ in_array('Echo', $vehicle_type ?? []) ? 'selected' : '' }}>Echo</option>
                                <option value="Bolero" {{ in_array('Bolero', $vehicle_type ?? []) ? 'selected' : '' }}>Bolero</option>
                                <option value="Tempo" {{ in_array('Tempo', $vehicle_type ?? []) ? 'selected' : '' }}>Tempo Traveller</option>
                            </select>
                        </div>
                        <!--end::Col-->
                    </div>

                    <div class="row mb-6">
                        <!--begin::Label-->
                        <label class="col-lg-4 col-form-label required fw-bold"> Site Type
                            </label>
                        <!--end::Label-->
                        <!--begin::Col-->
                        <div class="col-lg-8">
                            <select name="site_type" aria-label="Select Vehicle Type"
                            class="form-select form-select-solid" data-control="select2" data-hide-search="flase" required>
                                    <option value="">Site Type</option>
                                    <option value="1" @if($data->site_type==1) selected @endif>On-Site</option>
                                    <option value="2" @if($data->site_type==2) selected @endif>Off-Site</option>
                                    <option value="2" @if($data->site_type==3) selected @endif>On-SiteCallers</option>
                                    
                            </select>
                        </div>
                        <!--end::Col-->
                    </div>




                        <div class="row mb-6">
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">City</label>
                            <div class="col-lg-8 fv-row">
                                <select class="form-select form-select-solid" data-control="select2" data-hide-search="flase" data-placeholder="Select City..." name="city" aria-label="Select a Type">
                                    @foreach($city as $c)
                                        <option value="{{ $c->id }}" @if($data->city==$c->id) selected @endif>
                                            {{ $c->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="row mb-6">
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">State</label>
                            <div class="col-lg-8">
                                <div class="row">
                                    <div class="col-lg-12 fv-row">
                                    <select class="form-select form-select-solid" data-control="select2" data-hide-search="flase" data-placeholder="Select City..." name="state" aria-label="Select a Type">
                                            <option value="" disabled>Select State</option>
                                            @foreach($states as $state)
                                                <option value="{{ $state }}" {{ old('state', $data->state) == $state ? 'selected' : '' }}>
                                                    {{ $state }}
                                                </option>
                                            @endforeach
                                    </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-6">
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">Serving Area</label>
                            <div class="col-lg-8 fv-row">
                                <input type='text' id="serving_area" name="serving_area" placeholder="Serving Area"
                                    class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" value="{{ old('serving_area', $data->serving_area) }}" required />
                            </div>
                        </div>

                        <div class="row mb-6">
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">Priority</label>
                            <div class="col-lg-8 fv-row">
                                <select name="priority" aria-label="Select a Type"
                                    data-placeholder="Select a city..."
                                    class="form-select form-select-solid form-select-lg" required>
                                    <option value="local" {{ old('priority', $data->priority) == 'local' ? 'selected' : '' }}>Local</option>
                                    <option value="outstation" {{ old('priority', $data->priority) == 'outstation' ? 'selected' : '' }}>Out Station</option>
                                    <option value="both" {{ old('priority', $data->priority) == 'both' ? 'selected' : '' }}>Both</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-6">
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">Type</label>
                            <div class="col-lg-8 fv-row">
                                <select name="type" aria-label="Select a Type" onchange="getGroup()" id="groupdata"
                                    data-placeholder="Select a Type..."
                                    class="form-select form-select-solid form-select-lg" required>
                                    <option value="">Select Type</option>
                                    <option value="group" {{ old('type', $data->type) == 'group' ? 'selected' : '' }}>Group</option>
                                    <option value="individual" {{ old('type', $data->type) == 'individual' ? 'selected' : '' }}>Individual</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-6" id="groupList" style="{{ old('type', $data->type) == 'group' ? '' : 'display: none;' }}">
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">Group List</label>
                            <div class="col-lg-8 fv-row">
                                <select name="group" aria-label="Select a Group"
                                    data-placeholder="Select a Group..."
                                    class="form-select form-select-solid form-select-lg" required>
                                    @foreach($groups as $group)
                                        <option value="{{ $group->id }}" {{ $group->id == old('group', $data->group_id) ? 'selected' : '' }}>
                                            {{ $group->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="row mb-6" id="groupList" style="display: none;">
                            <!--begin::Label-->
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">Group List</label>
                            <!--end::Label-->
                            <!--begin::Col-->
                            <div class="col-lg-8 fv-row">
                                <select name="group" aria-label="Select a Group"
                                    data-placeholder="Select a Group..."
                                    class="form-select form-select-solid form-select-lg">
                                </select>
                            </div>
                            <!--end::Col-->
                        </div>

                        <div class="card card-flush py-4">
                                    <!--begin::Card header-->
                                    <div class="card-header">
                                        <!--begin::Card title-->
                                        <div class="card-title">
                                            <h2>Vehicle Image</h2>
                                        </div>
                                        <!--end::Card title-->
                                    </div>
                                    <!--end::Card header-->
                                    <!--begin::Card body-->
                                    <div class="card-body text-center pt-0">
                                        <!--begin::Image input-->
                                        <!--begin::Image input placeholder-->
                                        <style>
                                        .image-input-placeholder {
                                            background-image: url("{{ asset('admin_theme/html/theme/demo1/dist/assets/media/svg/files/image.jpg')}}");
                                        }

                                        [data-theme="dark"] .image-input-placeholder {
                                            background-image: url("{{ asset('assets/media/svg/files/image.jpg')}}");
                                        }
                                        </style>
                                        <!--end::Image input placeholder-->
                                        <div class="image-input image-input-empty image-input-outline image-input-placeholder mb-3"
                                            data-kt-image-input="true">
                                            <!--begin::Preview existing avatar-->
                                            <div class="image-input-wrapper w-150px h-150px"></div>
                                            <!--end::Preview existing avatar-->
                                            <!--begin::Label-->
                                            <label
                                                class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                                data-kt-image-input-action="change" data-bs-toggle="tooltip"
                                                title="Change avatar">
                                                <i class="bi bi-pencil-fill fs-7"></i>
                                                <!--begin::Inputs-->
                                                <input type="file" name="images[]" accept=".png, .jpg, .jpeg" multiple/>
                                                <input type="hidden" name="avatar_remove" />
                                                <!--end::Inputs-->
                                            </label>
                                            <!--end::Label-->
                                            <!--begin::Cancel-->
                                            <span
                                                class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                                data-kt-image-input-action="cancel" data-bs-toggle="tooltip"
                                                title="Cancel avatar">
                                                <i class="bi bi-x fs-2"></i>
                                            </span>
                                            <!--end::Cancel-->
                                            <!--begin::Remove-->
                                            <span
                                                class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                                data-kt-image-input-action="remove" data-bs-toggle="tooltip"
                                                title="Remove avatar">
                                                <i class="bi bi-x fs-2"></i>
                                            </span>
                                            <!--end::Remove-->
                                        </div>
                                        <!--end::Image input-->
                                        <!--begin::Description-->
                                        <div class="text-muted fs-7">Set the course thumbnail image. Only *.png, *.jpg
                                            and *.jpeg image files are accepted</div>
                                        <!--end::Description-->
                                    </div>
                                    <!--end::Card body-->
                                </div>
                                <div class="preview-container" id="preview-container"></div>
                            <!--end::Card body-->
                            <!--begin::Actions-->
                            <div class="card-footer d-flex justify-content-end py-6 px-9">
                                <button type="submit" class="btn btn-primary"
                                    id="kt_account_profile_details_submit">Save
                                    Changes</button>
                            </div>
                            <!--end::Actions-->
                        </div>

                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Content-->
            </div>
            <!--end::Basic info-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
</div>
<!--end::Content wrapper-->

@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#pin').on('input', function() {
        var pin = $(this).val();
        var pinError = $('#pin-error');

        // Remove non-numeric characters
        pin = pin.replace(/\D/g, '');
        
        // Limit length to 6 characters
        if (pin.length > 6) {
            pin = pin.substring(0, 6);
        }

        $(this).val(pin);

        pinError.text(''); // Clear any previous error messages
        if (pin.length !== 6) {
            pinError.text('The pin must be exactly 6 digits.');
        }
    });

    $('#pin').on('keypress', function(e) {
        var key = e.which || e.keyCode;
        // Allow only numeric characters
        if ((key < 48 || key > 57) && key !== 8 && key !== 46) {
            e.preventDefault();
        }
    });
});
</script>
<script>
 $(document).ready(function() {
    $('input[type="file"]').on('change', function(event) {
        const files = event.target.files;
        const previewContainer = $('#preview-container');
        previewContainer.empty();

        for (let i = 0; i < files.length; i++) {
            const file = files[i];

            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const previewDiv = $('<div>').addClass('preview');
                    const img = $('<img>').attr('src', e.target.result);

                    previewDiv.append(img);
                    previewContainer.append(previewDiv);
                };
                reader.readAsDataURL(file);
            }
        }
    });
});
</script>
<script>
  function getGroup(){
            const selectedValue = $('#groupdata').val();
            
            if (selectedValue === 'group') {
                $.ajax({
                    url: '{{route("admin.getgroup")}}',
                    method: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(data) {
                        $('select[name="group"]').empty();
                        if (data.data && data.data.length > 0) {
                            $.each(data.data, function(key, group) {
                                console.log("check the group", group);
                                $('select[name="group"]').append(
                                    $('<option></option>').attr('value', group.id).text(group.name)
                                );
                            });

                            $('select[name="group"]').prop('required', true);
                            $('#groupList').show();
                        } else {
                            $('select[name="group"]').prop('required', false);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error fetching group data:', error);
                    }
                });
            }
            else {
                $('#groupList').hide();
                $('select[name="group"]').empty();
            }
        }
</script>
@section('js')

<script>
function setloader() {
    $('.indicator-label').hide();
    $('.indicator-progress').show();
}

$(document).ready(function() {

    var checkedValue = $("input[name='type']:checked").val();

    if (checkedValue == 'link') {
        $('#my_link').prop('required', true);
    } else if (checkedValue == 'course') {
        $('#my_course').prop('required', true);
    } else if (checkedValue == 'video') {
        $('#my_video').prop('required', true);
    } else if (checkedValue == 'pdf') {
        $('#my_pdf').prop('required', true);
    } else if (radioValue == 'category') {
        $('#my_category').prop('required', true);
    } else if (radioValue == 'deal') {
        $('#my_deal').prop('required', true);
    }

});
</script>

@endsection