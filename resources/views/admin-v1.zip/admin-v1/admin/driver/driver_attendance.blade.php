@extends('admin.layouts.main')
@section('content')
    <!--begin::Content wrapper-->
    <div class="d-flex flex-column flex-column-fluid">
        <!--begin::Content-->
        <div id="kt_app_content" class="app-content flex-column-fluid">
            <!--begin::Content container-->
            <div id="kt_app_content_container" class="app-container container-xxl">
                <!--begin::Tables Widget 11-->
                <div class="card mb-5 mb-xl-8">
                    <!--begin::Header-->
                    <div class="card-header border-0 pt-5">
                        <h3 class="card-title align-items-start flex-column">
                            <span class="card-label fw-bold fs-3 mb-1">Driver Attendance</span>
                        </h3>
                    </div>
                    <!--end::Header-->
                    <!--begin::Body-->
                    <div class="card-body py-3">
                        <!--begin::Table container-->
                        <div class="table-responsive">
                            <!--begin::Table-->
                            <table  id="kt_datatable_example_1" class="table align-middle table-row-dashed fs-6 gy-5">
                            <thead>
                                <tr class="fw-bold text-muted bg-light">
                                    <th clsas="min-w-200px">Selfi</th>
                                    <th clsas="min-w-200px">Plant Name</th>
                                    <th clsas="min-w-200px">Date</th>
                                    <th class="min-w-100px">Shift Type</th>
                                    <th clsas="min-w-200px">CheckIn</th>
                                    <th clsas="min-w-200px">CheckIn Lat,Long</th>
                                    <th clsas="min-w-200px">CheckOut</th>
                                    <th clsas="min-w-200px">CheckOut Lat,Long</th>
                                    <th clsas="min-w-200px">Meter Reading</th>
                                    <th clsas="min-w-200px">Mechanical Check</th>
                                    <th clsas="min-w-200px">Medical Supply</th>
                                    <th clsas="min-w-200px">Cleanliness Hygiene</th>
                                    <th clsas="min-w-200px">Communication Documentation</th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-600 fw-semibold">
                                @foreach ($data as $item)                                    
                                <tr>
                                    <td>@if($item->photo)<img src="{{asset("/images/driver/".$item->photo)}}" height="80" width="80">@endif</td>
                                    <td>{{$item->plant_name}}</td>
                                    <td>{{$item->date}}</td>
                                    <td>{{$item->shift_type}}</td>
                                    <td>{{$item->check_in_date.' '.$item->check_in_time}}</td>
                                    <td>{{$item->latitude.', '.$item->longitude}}</td>
                                    <td>{{$item->check_out_date.' '.$item->check_out_time}}</td>
                                    <td>{{$item->checkout_latitude.', '.$item->checkout_longitude}}</td>
                                    <td>{{$item->meter_reading}}</td>
                                    <td>@if($item->engine_mechanical_check) {{ implode(",",json_decode($item->engine_mechanical_check))}} @endif</td>
                                    <td>@if($item->emergency_medical_supply) {{ implode(",",json_decode($item->emergency_medical_supply))}} @endif</td>
                                    <td>@if($item->cleanliness_hygiene) {{ implode(",",json_decode($item->cleanliness_hygiene))}} @endif</td>
                                    <td>@if($item->communication_documentation) {{ implode(",",json_decode($item->communication_documentation))}} @endif</td>
                                </tr>
                                @endforeach
                            </tbody>
                                <!--end::Table body-->
                            </table>
                           
                            <!--end::Table-->
                        </div>
                        <!--end::Table container-->
                    </div>
                    <!--begin::Body-->
                </div>
                <!--end::Tables Widget 11-->
            </div>
            <!--end::Content container-->
        </div>
        <!--end::Content-->
    </div>
    <!--end::Content wrapper-->
@endsection

