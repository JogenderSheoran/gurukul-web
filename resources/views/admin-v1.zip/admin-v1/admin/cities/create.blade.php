@extends('admin.layouts.main')
@section('content')
<!--begin::Content wrapper-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Toolbar-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <div id="kt_content_container" class="container-xxl">
            <div class="card mb-5 mb-xl-10">
                <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse" data-bs-target="#kt_account_profile_details" aria-expanded="true" aria-controls="kt_account_profile_details">
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">Add City</h3>
                    </div>
                </div>
                <div id="kt_account_profile_details" class="collapse show">
                <form action="{{ route('cities.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="card-body border-top p-9">

                        <!-- Title -->
                        <div class="row mb-6">
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">City Name</label>
                            <div class="col-lg-8">
                                <input type="text" name="city_name" class="form-control form-control-lg form-control-solid" placeholder="Enter city name" required />
                            </div>
                        </div>

                        <!-- Submit -->
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card-footer d-flex justify-content-end py-6 px-9">
                                    <button type="submit" class="btn btn-primary">Save City</button>
                                </div>
                            </div>
                        </div>

                    </div>
                </form>
                </div>
                <!--end::Content-->
            </div>
            <!--end::Basic info-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
</div>
<!--end::Content wrapper-->

<script>
    var i = 1;

    function addField() {
        html = '<div class="row" id="field' + i + '"><div class="col-lg-4"><input type="file" class="md-input" name="card_img[]" style="margin-top:20px;"></div><div class="col-lg-4"><label>Link</label><input type="text" class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" name="link[]"></div><div class="col-lg-4"><label>Description</label><input type="text" class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" name="description[]"></div><div class="col-lg-4"><i class="fa fa-minus best_remove_button" id="remove-field' + i + '" onclick="removeField(' + i + ')"></i></div></div>';

        $("#input-fields").append(html);
        i++;
    }

    function removeField(count) {
        $("#field" + count).remove();
    }
</script>
<script>
    document.getElementById("keyField").addEventListener("input", function () {
        const key = this.value.toLowerCase();
        const container = document.getElementById("valueInputContainer");

        if (key.includes("image") || key.includes("logo") || key.includes("banner") || key.includes("hero_image") || key.includes("background_image")) {
            container.innerHTML = `<input type="file" name="value" class="form-control" accept="image/*" required>`;
        } else if (key.includes("description") || key.includes("text") || key.includes("html")) {
            container.innerHTML = `<textarea name="value" class="form-control form-control-lg form-control-solid" rows="5" placeholder="Enter content..." required></textarea>`;
        } else {
            container.innerHTML = `<input type="text" name="value" class="form-control form-control-lg form-control-solid" placeholder="Enter value..." required>`;
        }
    });
</script>
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

@section('js')

<script>
    function setloader() {
        $('.indicator-label').hide();
        $('.indicator-progress').show();
    }

    $(document).ready(function() {

        var checkedValue = $("input[name='type']:checked").val();

        if (checkedValue == 'link') {
            $('#my_link').prop('required', true);
        } else if (checkedValue == 'course') {
            $('#my_course').prop('required', true);
        } else if (checkedValue == 'video') {
            $('#my_video').prop('required', true);
        } else if (checkedValue == 'pdf') {
            $('#my_pdf').prop('required', true);
        } else if (radioValue == 'category') {
            $('#my_category').prop('required', true);
        } else if (radioValue == 'deal') {
            $('#my_deal').prop('required', true);
        }

    });
</script>

@endsection