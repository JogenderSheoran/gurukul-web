@extends('admin.layouts.main')
@section('content')
<!--begin::Content wrapper-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Toolbar-->

    <!--end::Toolbar-->
    <!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">
            <!--begin::Basic info-->
            <div class="card mb-5 mb-xl-10">
                <!--begin::Card header-->
                <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse" data-bs-target="#kt_account_profile_details" aria-expanded="true" aria-controls="kt_account_profile_details">
                    <!--begin::Card title-->
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">Edit Service</h3>
                    </div>
                    <!--end::Card title-->
                </div>
                <!--begin::Card header-->
                <!--begin::Content-->
                <div id="kt_account_profile_details" class="collapse show">
                <form action="{{ route('services.update', $service->id) }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="card-body border-top p-9">

                        <!-- Title -->
                        <div class="row mb-6">
                            <label class="col-lg-4 col-form-label required fw-bold fs-6">Title</label>
                            <div class="col-lg-8">
                                <input type="text" name="title" class="form-control form-control-lg form-control-solid"
                                    value="{{ old('title', $service->title) }}" placeholder="Enter service title" required />
                            </div>
                        </div>

                        <!-- Icon -->
                        <div class="row mb-6">
                            <label class="col-lg-4 col-form-label fw-bold fs-6">Icon</label>
                            <div class="col-lg-8">
                                <input type="file" name="icon" class="form-control mb-2" accept="image/*">
                                <input type="hidden" name="old_icon" value="{{ $service->icon }}">

                                @if ($service->icon)
                                    <div class="mt-2">
                                        <img src="{{ asset('storage/' . $service->icon) }}" width="100" class="img-thumbnail" alt="Current Icon">
                                    </div>
                                @endif
                            </div>
                        </div>

                        <!-- Description -->
                        <div class="row mb-6">
                            <label class="col-lg-4 col-form-label fw-bold fs-6">Description</label>
                            <div class="col-lg-8">
                                <textarea name="description" class="form-control form-control-lg form-control-solid"
                                    rows="5" placeholder="Enter service description...">{{ old('description', $service->description) }}</textarea>
                            </div>
                        </div>

                        <!-- Submit -->
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card-footer d-flex justify-content-end py-6 px-9">
                                    <button type="submit" class="btn btn-primary">Update Service</button>
                                </div>
                            </div>
                        </div>

                    </div>
                </form>
                </div>
                <!--end::Content-->
            </div>
            <!--end::Basic info-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
</div>
<!--end::Content wrapper-->



@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

@section('js')

<script>
    function setloader() {
        $('.indicator-label').hide();
        $('.indicator-progress').show();
    }

    $(document).ready(function() {

        var checkedValue = $("input[name='type']:checked").val();

        if (checkedValue == 'link') {
            $('#my_link').prop('required', true);
        } else if (checkedValue == 'course') {
            $('#my_course').prop('required', true);
        } else if (checkedValue == 'video') {
            $('#my_video').prop('required', true);
        } else if (checkedValue == 'pdf') {
            $('#my_pdf').prop('required', true);
        } else if (radioValue == 'category') {
            $('#my_category').prop('required', true);
        } else if (radioValue == 'deal') {
            $('#my_deal').prop('required', true);
        }

    });
</script>
<script>
    $(document).ready(function() {
        var maxField = 10; //Input fields increment limitation
        var y = {
            {
                $y
            }
        };
        var maxFieldy = 10;
        var addButtony = $('.add_best_price');
        var wrappery = $('.best_price_wrapper');
        var fieldHTMLy = '<div id="fieldy' + y + '" class="uk-grid" data-uk-grid-margin><div class="uk-width-medium-1-3"><input type="file" class="md-input" name="card_img[]"/></div><div class="uk-width-medium-1-3"><label>Link</label><input type="text" class="md-input" name="link[]" required/></div><div class="uk-width-medium-1-3"><label>Description</label><input type="text" class="md-input" name="description[]" required/></div><div class="uk-width-medium-1-3"><a href="javascript:void(0);"  title="Add field"><i class="fa fa-minus best_remove_button" id="' + y + '"></i></a></div></div>';

        $(addButtony).click(function() {
            if (y < maxField) {
                y++;
                $(wrappery).append(fieldHTMLy);
            }
        });

        $(wrappery).on('click', '.best_remove_button', function(e) {
            e.preventDefault();
            var id = "#fieldy" + this.id;
            $(id).remove();
            y--;
        });

    });
</script>

@endsection
