@extends('admin.layouts.main')
@section('content')
    <!--begin::Content wrapper-->
    <div class="d-flex flex-column flex-column-fluid">
        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
            <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
                <!--begin::Page title-->
                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                    <!--begin::Breadcrumb-->
                    <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                        <!--begin::Item-->
                        <li class="breadcrumb-item text-muted">
                            <a href="#" class="text-dark text-hover-primary">Home</a>
                        </li>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item">
                            <span class="bullet bg-gray-400 w-5px h-2px"></span>
                        </li>
                        <li class="breadcrumb-item">Services</li>
                    </ul>
                    <!--end::Breadcrumb-->
                </div>
                <div class="d-flex align-items-center py-1">
                    <!--begin::Wrapper-->
                    <div class="me-4">
                        <!--end::Menu 1-->
                        <!--end::Menu-->
                    </div>
                    <!--end::Wrapper-->
                    <!--begin::Button-->
                    <a href="{{route('services.create')}}" class="btn btn-sm btn-primary" id="kt_toolbar_primary_button">Add Service</a>
                    <!--end::Button-->
                </div>
                <!--end::Page title-->
            </div>
        </div>
        <!--begin::Content-->
        <div id="kt_app_content" class="app-content flex-column-fluid">
            <!--begin::Content container-->
            <div id="kt_app_content_container" class="app-container container-xxl">
                <!--begin::Tables Widget 11-->
                <div class="card mb-5 mb-xl-8">
                    <!--begin::Header-->
                    <div class="card-header border-0 pt-5">
                        <h3 class="card-title align-items-start flex-column">
                            <span class="card-label fw-bold fs-3 mb-1">Service List</span>
                        </h3>
                        <i class="ki-duotone ki-magnifier fs-1 position-absolute ms-6"><span class="path1"></span><span class="path2"></span></i>

                        <input type="text" data-kt-docs-table-filter="search"  class="form-control form-control-solid w-250px ps-15" placeholder="Search....."/>
                    </div>
                    <!--end::Header-->
                    <!--begin::Body-->
                    <div class="card-body py-3">
                        <!--begin::Table container-->
                        <div class="table-responsive">
                            <!--begin::Table-->
                            <table  id="kt_datatable_example_1" class="table align-middle table-row-dashed fs-6 gy-5">
                            <thead>
                                <tr class="fw-bold text-dark bg-light">
                                    <th class="ps-4 min-w-100px rounded-start"><b>Title</b></th>
                                    <th class="min-w-100px"><b>Description</b></th>
                                    <th class="min-w-200px"><b>Icon</b></th>
                                    <th class="min-w-100px"><b>Action</b></th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-600 fw-semibold">

                            </tbody>
                                <!--end::Table body-->
                            </table>

                            <!--end::Table-->
                        </div>
                        <!--end::Table container-->
                    </div>
                    <!--begin::Body-->
                </div>
                <!--end::Tables Widget 11-->
            </div>
            <!--end::Content container-->
        </div>
        <!--end::Content-->
    </div>
    <!--end::Content wrapper-->


    <div class="modal fade" tabindex="-1" id="kt_modal_1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Confirmation</h3>
                    <!--begin::Close-->
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                        <i class="ki-duotone ki-cross fs-1"><span class="path1"></span><span class="path2"></span></i>
                    </div>
                    <!--end::Close-->
                </div>

                <div class="modal-body">
                    <p>Are you sure you want to delete this User?</p>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <a href="" class="btn btn-primary" id="save_button">Delete</a>
                </div>
            </div>
        </div>
    </div>

@endsection

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<!-- SweetAlert2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">

<!-- SweetAlert2 JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script type="text/javascript">
  $(document).ready(function () {
    var dt = $("#kt_datatable_example_1").DataTable({
        fixedHeader: {
            header: true,
        },
        processing: true,
        serverSide: true,
        order: [[0, 'desc']],
        ajax: "{{ route('services.list') }}",
        columns: [
            { data: 'title', name: 'title' },
            { data: 'description', name: 'description' },
            { data: 'icon', name: 'icon' },
            { 
                data: 'action', 
                name: 'action', 
                orderable: false, 
                searchable: false 
            },
        ]
    });

 $('[data-kt-docs-table-filter="search"]').on('keyup', function () {
        console.log("Search input changed");
        console.log("Search value:", $(this).val());
        dt.search($(this).val()).draw();
        });
    });


    

    function verify(id,type)
    {
        if(type==1){
            var type=0;
        }
        else{
            var type=1;
        }
    Swal.fire({
    text: "Are you sure you want to change status of this card?",
    icon: "warning",
    showCancelButton: true,
    buttonsStyling: false,
    confirmButtonText: "Yes, Change Status!",
    cancelButtonText: "No, cancel",
    customClass: {
        confirmButton: "btn fw-bold btn-danger",
        cancelButton: "btn fw-bold btn-active-light-primary"
    }
    }).then((function (result) {
        if (result.value) {
            $.ajax({
                type: "POST",
                url: `${window.location.origin}/goaid/api/activate_card`,
                data: {
                        "_token": "{{ csrf_token() }}",
                        "id": id,
                        "type":type
                        } ,
                success: function (response) {
                    console.log("check the response",response);
                    if(response.status=='success'){
                        window.location.reload();
                        Swal.fire({
                        text: "You have changed the status for this card!",
                        icon: "success",
                        buttonsStyling: false,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn fw-bold btn-primary"
                        }
                        }).then((function () {
                            // Remove the row from the DataTable
                            window.location.reload();
                        }));
                    }
                    else{
                        Swal.fire({
                        text: "An error occurred while changing  the status of hospital.",
                        icon: "error",
                        buttonsStyling: false,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn fw-bold btn-primary"
                        }
                    });
                    }

                },
                error: function (error) {
                    console.error("Error deleting vehicle:", error);
                    Swal.fire({
                        text: "An error occurred while deleting the hospital.",
                        icon: "error",
                        buttonsStyling: false,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn fw-bold btn-primary"
                        }
                    });
                }
            });
        } else if (result.dismiss === Swal.DismissReason.cancel) {
            // User clicked "No, cancel"
            Swal.fire({
                text: "Card staus was not changed.",
                icon: "error",
                buttonsStyling: false,
                confirmButtonText: "Ok, got it!",
                customClass: {
                    confirmButton: "btn fw-bold btn-primary"
                }
            });
        }
    }));
}
</script>

