<script>
    var hostUrl = "{{URL::asset('admin_theme/html/theme/demo13/dist/assets/')}}";
</script>

<!--begin::Javascript-->
<!--begin::Global Javascript Bundle(used by all pages)-->
<script src="{{URL::asset('admin_theme/html/theme/demo13/dist/assets/plugins/global/plugins.bundle.js')}}"></script>
<script src="{{URL::asset('admin_theme/html/theme/demo13/dist/assets/js/scripts.bundle.js')}}"></script>
<!--end::Global Javascript Bundle-->
<!--begin::Page Vendors Javascript(used by this page)-->
<script src="{{URL::asset('admin_theme/html/theme/demo13/dist/assets/plugins/custom/fullcalendar/fullcalendar.bundle.js')}}"></script>
<!--end::Page Vendors Javascript-->
<!--begin::Page Custom Javascript(used by this page)-->
<script src="{{URL::asset('admin_theme/html/theme/demo13/dist/assets/js/custom/widgets.js')}}"></script>
<script src="{{URL::asset('admin_theme/html/theme/demo13/dist/assets/js/custom/apps/chat/chat.js')}}"></script>
<script src="{{URL::asset('admin_theme/html/theme/demo13/dist/assets/js/custom/modals/create-app.js')}}"></script>
<script src="{{URL::asset('admin_theme/html/theme/demo13/dist/assets/js/custom/modals/upgrade-plan.js')}}"></script>
<script src="{{URL::asset('admin_theme/html/theme/demo13/dist/assets/plugins/custom/datatables/datatables.bundle.js')}}"></script>


<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

<script>
    @if(Session::has('success'))
    var type = "{{ Session::get('message', 'success') }}"
    switch (type) {
        case 'info':
            toastr.options.timeOut = 5000;
            toastr.info("{{ Session::get('success') }}");
        case 'success':
            toastr.options.timeOut = 5000;
            toastr.success("{{ Session::get('success') }}");
            break;
        case 'warning':
            toastr.options.timeOut = 5000;
            toastr.warning("{{ Session::get('warning') }}");
            break;
        case 'error':
            toastr.options.timeOut = 5000;
            toastr.error("{{ Session::get('error') }}");
            break;
    }
    @endif
</script>