<style>
    .aside-menu .menu-item .menu-link.active {
        color: #fff !important;
        background: linear-gradient(135deg, #fbc002, #ff9900) !important;
        font-weight: bold;
        box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        border-radius: 6px;
    }
    .menu-link {
        color: #fff;
        transition: all 0.3s ease;
        border-radius: 6px;
    }
    .menu-link:hover {
        background: rgba(255, 255, 255, 0.1);
        transform: translateX(5px);
    }
    .menu-icon i {
        font-size: 18px;
        margin-right: 8px;
    }
    .menu-title {
        font-size: 14px;
    }
</style>

<!-- Start of the Sidebar -->
<div id="kt_aside" class="aside aside-dark aside-hoverable" data-kt-drawer="true" data-kt-drawer-name="aside"
    data-kt-drawer-activate="{default: true, lg: false}" data-kt-drawer-overlay="true"
    data-kt-drawer-width="{default:'200px', '300px': '250px'}" data-kt-drawer-direction="start"
    data-kt-drawer-toggle="#kt_aside_mobile_toggle">

    <!-- Logo -->
    <div class="aside-logo flex-column-auto" id="kt_aside_logo">
        <a href="#">
            <img alt="Logo"
                src="{{ URL::asset('admin_theme/html/theme/demo1/dist/assets/media/auth/logo.png') }}"
                style="height:170px;width:170px; margin-top:50px"/>
        </a>
    </div>

    <!-- Menu -->
    <div class="aside-menu flex-column-fluid">
        <div class="hover-scroll-overlay-y my-5 my-lg-5" id="kt_aside_menu_wrapper" data-kt-scroll="true"
            data-kt-scroll-activate="{default: false, lg: true}" data-kt-scroll-height="auto"
            data-kt-scroll-dependencies="#kt_aside_logo, #kt_aside_footer" data-kt-scroll-wrappers="#kt_aside_menu"
            data-kt-scroll-offset="0">

            <div class="menu menu-column menu-title-gray-800" id="#kt_aside_menu" data-kt-menu="true">

                <!-- Menu Section: Dashboard -->
                <div class="menu-item">
                    <a href="#" class="menu-link @if($title=='dashboard') active @endif">
                        <span class="menu-icon"><i class="fa fa-tachometer-alt text-warning"></i></span>
                        <span class="menu-title">Dashboard</span>
                    </a>
                </div>

            
                <div class="menu-item">
                    <a href="{{route('admin.wordpressLeads')}}" class="menu-link @if($title=='WordPress Leads') active @endif">
                        <span class="menu-icon"><i class="fab fa-wordpress text-primary"></i></span>
                        <span class="menu-title">WordPress Leads</span>
                    </a>
                </div>

                

                <!-- ETC Section (Coupon, Card, etc.) can go here -->
                <!-- Add your links in the same format -->
            </div>
        </div>
    </div>
</div>
<!-- End of Sidebar -->
