@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Statistics Cards Row -->
            <div class="row">
                <!-- Total Records -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{ $totalRecords }}</h3>
                            <p>Total Attendance Records</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-clipboard-list"></i>
                        </div>
                    </div>
                </div>

                <!-- Today's Records -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>{{ $todayRecords }}</h3>
                            <p>Today's Records</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-calendar-day"></i>
                        </div>
                    </div>
                </div>

                <!-- Pending Checkouts -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>{{ $pendingCheckouts }}</h3>
                            <p>Pending Check-outs</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                </div>

                <!-- Completed Today -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3>{{ $completedToday }}</h3>
                            <p>Completed Today</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions Row -->
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-bolt mr-2"></i>
                                Quick Actions
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="{{ route('admin-v1.driver-manager.check-in-out') }}" class="btn btn-primary btn-block btn-lg">
                                        <i class="fas fa-clock mr-2"></i>
                                        Check-in / Check-out
                                    </a>
                                </div>
                                <div class="col-md-3">
                                    <a href="{{ route('admin-v1.drivers.locations') }}" class="btn btn-info btn-block btn-lg">
                                        <i class="fas fa-map-marker-alt mr-2"></i>
                                        Driver Locations
                                    </a>
                                </div>
                                <div class="col-md-3">
                                    <a href="{{ route('admin-v1.drivers') }}" class="btn btn-success btn-block btn-lg">
                                        <i class="fas fa-users mr-2"></i>
                                        All Drivers
                                    </a>
                                </div>
                                <div class="col-md-3">
                                    <button class="btn btn-warning btn-block btn-lg" onclick="exportAttendance()">
                                        <i class="fas fa-download mr-2"></i>
                                        Export Data
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Drivers with Attendance -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-users mr-2"></i>
                                Drivers with Latest Attendance
                            </h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                @forelse($driversWithAttendance as $record)
                                    <div class="col-md-6 col-lg-4 mb-4">
                                        <div class="card card-outline card-primary">
                                            <div class="card-header">
                                                <h5 class="card-title mb-0">
                                                    <div class="d-flex align-items-center">
                                                        <div class="mr-3">
                                                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center" 
                                                                style="width: 40px; height: 40px;">
                                                                <span class="text-white font-weight-bold">
                                                                    {{ strtoupper(substr($record->driver->first_name, 0, 1) . substr($record->driver->last_name ?? '', 0, 1)) }}
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div class="font-weight-bold">
                                                                {{ $record->driver->first_name }} {{ $record->driver->last_name }}
                                                            </div>
                                                            <small class="text-muted">{{ $record->driver->mobile }}</small>
                                                        </div>
                                                    </div>
                                                </h5>
                                                <div class="card-tools">
                                                    @if($record->driver->status == 1)
                                                        <span class="badge badge-success">Active</span>
                                                    @else
                                                        <span class="badge badge-danger">Inactive</span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="card-body p-3">
                                                <div class="row text-center">
                                                    <div class="col-6 border-right">
                                                        <strong class="text-success">Check-in</strong><br>
                                                        <small>
                                                            @if($record->check_in_time)
                                                                {{ $record->check_in_time }} <br>
                                                                <span class="text-muted">
                                                                    {{ \Carbon\Carbon::parse($record->check_in_date)->format('M d') }}
                                                                </span>
                                                            @else
                                                                <span class="text-muted">Not checked in</span>
                                                            @endif
                                                        </small>
                                                    </div>

                                                    <div class="col-6">
                                                        <strong class="text-warning">Check-out</strong><br>
                                                        <small>
                                                            @if($record->check_out_time)
                                                                {{ $record->check_out_time }} <br>
                                                                <span class="text-muted">
                                                                    {{ \Carbon\Carbon::parse($record->check_out_date)->format('M d') }}
                                                                </span>
                                                            @else
                                                                <span class="badge badge-warning badge-sm">Pending</span>
                                                            @endif
                                                        </small>
                                                    </div>
                                                </div>

                                                <hr class="my-2">

                                                <div class="text-center">
                                                    <small class="text-muted">
                                                        <i class="fas fa-building mr-1"></i>
                                                        {{ $record->plant_name ?? 'N/A' }}
                                                    </small>
                                                </div>
                                            </div>

                                            <div class="card-footer p-2">
                                                <div class="btn-group btn-group-sm w-100" role="group">
                                                    <a href="{{ route('admin-v1.drivers.show', $record->driver->id) }}" class="btn btn-outline-primary">
                                                        <i class="fas fa-eye"></i> View
                                                    </a>
                                                    <a href="{{ route('admin-v1.drivers.attendance', $record->driver->id) }}" class="btn btn-outline-info">
                                                        <i class="fas fa-calendar-check"></i> History
                                                    </a>
                                                    @if($record->driver->latitude && $record->driver->longitude)
                                                        <a href="{{ route('admin-v1.drivers.location', $record->driver->id) }}" class="btn btn-outline-success">
                                                            <i class="fas fa-map-marker-alt"></i> Location
                                                        </a>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @empty
                                    <div class="col-12">
                                        <div class="alert alert-info text-center">
                                            <i class="fas fa-info-circle mr-2"></i>
                                            No attendance records found.
                                        </div>
                                    </div>
                                @endforelse
                            </div>

                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content -->
@endsection

@push('scripts')
<script>
function exportAttendance() {
    // Get current month and year
    const now = new Date();
    const currentMonth = now.getMonth() + 1; // JavaScript months are 0-indexed
    const currentYear = now.getFullYear();
    
    // Generate month options
    const months = [
        { value: 1, name: 'January' },
        { value: 2, name: 'February' },
        { value: 3, name: 'March' },
        { value: 4, name: 'April' },
        { value: 5, name: 'May' },
        { value: 6, name: 'June' },
        { value: 7, name: 'July' },
        { value: 8, name: 'August' },
        { value: 9, name: 'September' },
        { value: 10, name: 'October' },
        { value: 11, name: 'November' },
        { value: 12, name: 'December' }
    ];
    
    // Generate year options (last 5 years)
    let yearOptions = '';
    for (let i = 0; i < 5; i++) {
        const year = currentYear - i;
        yearOptions += `<option value="${year}" ${year === currentYear ? 'selected' : ''}>${year}</option>`;
    }
    
    // Generate month options
    let monthOptions = '';
    months.forEach(month => {
        monthOptions += `<option value="${month.value}" ${month.value === currentMonth ? 'selected' : ''}>${month.name}</option>`;
    });
    
    Swal.fire({
        title: 'Export Attendance Data',
        html: `
            <div class="form-group text-left mb-3">
                <label for="export_month" class="font-weight-bold">Select Month:</label>
                <select id="export_month" class="form-control">
                    ${monthOptions}
                </select>
            </div>
            <div class="form-group text-left mb-3">
                <label for="export_year" class="font-weight-bold">Select Year:</label>
                <select id="export_year" class="form-control">
                    ${yearOptions}
                </select>
            </div>
            <div class="alert alert-info text-left">
                <i class="fas fa-info-circle mr-2"></i>
                <small>Export will include: Date, Employee ID, Name, Plant Code, Check-In/Out Times, Shift Type, and Overtime Details (if applicable)</small>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: '<i class="fas fa-download mr-2"></i>Export to Excel',
        cancelButtonText: '<i class="fas fa-times mr-2"></i>Cancel',
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        width: '500px',
        preConfirm: () => {
            const month = document.getElementById('export_month').value;
            const year = document.getElementById('export_year').value;
            
            if (!month || !year) {
                Swal.showValidationMessage('Please select both month and year');
                return false;
            }
            
            return { month, year };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Show loading message
            Swal.fire({
                title: 'Generating Excel File...',
                html: 'Please wait while we prepare your attendance report.',
                allowOutsideClick: false,
                allowEscapeKey: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            
            // Redirect to export URL
            const exportUrl = `{{ route('admin-v1.driver-manager.attendance.export') }}?month=${result.value.month}&year=${result.value.year}`;
            window.location.href = exportUrl;
            
            // Close loading after a short delay
            setTimeout(() => {
                Swal.close();
                Swal.fire({
                    icon: 'success',
                    title: 'Export Complete!',
                    text: 'Your attendance report has been downloaded.',
                    timer: 3000,
                    showConfirmButton: false
                });
            }, 2000);
        }
    });
}

// Auto-refresh the page every 5 minutes to show updated data
setInterval(function() {
    location.reload();
}, 300000); // 5 minutes
</script>
@endpush

@push('styles')
<style>
.card-outline {
    border: 1px solid #dee2e6;
}

.card-outline.card-primary {
    border-color: #007bff;
}

.border-right {
    border-right: 1px solid #dee2e6;
}

.badge-sm {
    font-size: 0.75em;
}

.btn-group-sm .btn {
    font-size: 0.75rem;
}

@media (max-width: 768px) {
    .col-lg-4 {
        margin-bottom: 1rem;
    }
    
    .btn-group-sm .btn {
        font-size: 0.7rem;
        padding: 0.25rem 0.5rem;
    }
}
</style>
@endpush
