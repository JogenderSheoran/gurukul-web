@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Statistics Cards Row -->
            <div class="row">
                <!-- Total Drivers -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{ $totalDrivers }}</h3>
                            <p>Total Drivers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <a href="{{ route('admin-v1.drivers') }}" class="small-box-footer">
                            More info <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <!-- Active Drivers -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>{{ $activeDrivers }}</h3>
                            <p>Active Drivers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-user-check"></i>
                        </div>
                        <a href="{{ route('admin-v1.drivers') }}" class="small-box-footer">
                            More info <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <!-- Online Drivers -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>{{ $onlineDrivers }}</h3>
                            <p>Online Drivers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-circle text-success"></i>
                        </div>
                        <a href="{{ route('admin-v1.drivers.locations') }}" class="small-box-footer">
                            More info <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <!-- Blocked Drivers -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3>{{ $blockedDrivers }}</h3>
                            <p>Blocked Drivers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-user-times"></i>
                        </div>
                        <a href="{{ route('admin-v1.drivers') }}" class="small-box-footer">
                            More info <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Today's Statistics -->
            <div class="row">
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-info"><i class="fas fa-calendar-check"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Today's Attendance</span>
                            <span class="info-box-number">{{ $todayAttendance }}</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-success"><i class="fas fa-sign-in-alt"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Today's Check-ins</span>
                            <span class="info-box-number">{{ $todayCheckIns }}</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-warning"><i class="fas fa-sign-out-alt"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Today's Check-outs</span>
                            <span class="info-box-number">{{ $todayCheckOuts }}</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-danger"><i class="fas fa-chart-line"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Weekly Attendance</span>
                            <span class="info-box-number">{{ $weeklyAttendance }}</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts and Recent Data -->
            <div class="row">
                <!-- Attendance Chart -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-chart-line mr-2"></i>
                                Attendance Trend (Last 7 Days)
                            </h3>
                        </div>
                        <div class="card-body">
                            <canvas id="attendanceChart" style="height: 300px;"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-bolt mr-2"></i>
                                Quick Actions
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="{{ route('admin-v1.driver-manager.attendance-overview') }}" class="btn btn-primary btn-block">
                                    <i class="fas fa-calendar-check mr-2"></i>
                                    Attendance Overview
                                </a>
                                <a href="{{ route('admin-v1.driver-manager.check-in-out') }}" class="btn btn-success btn-block">
                                    <i class="fas fa-clock mr-2"></i>
                                    Check-in / Check-out
                                </a>
                                <a href="{{ route('admin-v1.drivers.locations') }}" class="btn btn-info btn-block">
                                    <i class="fas fa-map-marker-alt mr-2"></i>
                                    Driver Locations
                                </a>
                                <a href="{{ route('admin-v1.drivers') }}" class="btn btn-warning btn-block">
                                    <i class="fas fa-users mr-2"></i>
                                    All Drivers
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Data -->
            <div class="row">
                <!-- Recent Drivers -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-users mr-2"></i>
                                Recent Drivers
                            </h3>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Mobile</th>
                                            <th>Status</th>
                                            <th>Joined</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($recentDrivers as $driver)
                                            <tr>
                                                <td>{{ $driver->first_name }} {{ $driver->last_name }}</td>
                                                <td>{{ $driver->mobile }}</td>
                                                <td>
                                                    @if($driver->status == 0)
                                                        <span class="badge badge-success">Active</span>
                                                    @elseif($driver->status == 2)
                                                        <span class="badge badge-danger">Blocked</span>
                                                    @else
                                                        <span class="badge badge-warning">Pending</span>
                                                    @endif
                                                </td>
                                                <td>{{ $driver->created_at->format('M d, Y') }}</td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="4" class="text-center">No recent drivers</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Attendance -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-calendar-check mr-2"></i>
                                Recent Attendance
                            </h3>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Driver</th>
                                            <th>Plant</th>
                                            <th>Check-in</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($recentAttendance as $attendance)
                                            <tr>
                                                <td>
                                                    @if($attendance->driver)
                                                        {{ $attendance->driver->first_name }} {{ $attendance->driver->last_name }}
                                                    @else
                                                        N/A
                                                    @endif
                                                </td>
                                                <td>{{ $attendance->plant_name ?? 'N/A' }}</td>
                                                <td>
                                                    @if($attendance->check_in_time)
                                                        {{ $attendance->check_in_time }}
                                                    @else
                                                        N/A
                                                    @endif
                                                </td>
                                                <td>
                                                    @if($attendance->check_out_time)
                                                        <span class="badge badge-success">Completed</span>
                                                    @else
                                                        <span class="badge badge-warning">Pending</span>
                                                    @endif
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="4" class="text-center">No recent attendance</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content -->
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Attendance Chart
    const ctx = document.getElementById('attendanceChart').getContext('2d');
    const attendanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: @json($attendanceLabels),
            datasets: [{
                label: 'Attendance Records',
                data: @json($attendanceChartData),
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.1,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                }
            }
        }
    });
</script>
@endpush
