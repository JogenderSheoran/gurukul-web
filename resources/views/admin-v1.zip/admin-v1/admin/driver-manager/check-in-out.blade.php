@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Header Row -->
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="card bg-gradient-primary">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-md-8">
                                    <h3 class="text-white mb-2">
                                        <i class="fas fa-clock mr-2"></i>
                                        Check-in / Check-out Management
                                    </h3>
                                    <p class="text-white-50 mb-0">
                                        Monitor and manage driver attendance in real-time
                                    </p>
                                </div>
                                <div class="col-md-4 text-right">
                                    <div class="text-white">
                                        <h4 id="current-time"></h4>
                                        <small id="current-date"></small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Statistics Row -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="info-box">
                        <span class="info-box-icon bg-success"><i class="fas fa-sign-in-alt"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Today's Check-ins</span>
                            <span class="info-box-number">{{ $todayCheckIns->count() }}</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info-box">
                        <span class="info-box-icon bg-warning"><i class="fas fa-sign-out-alt"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Today's Check-outs</span>
                            <span class="info-box-number">{{ $todayCheckOuts->count() }}</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info-box">
                        <span class="info-box-icon bg-danger"><i class="fas fa-clock"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Pending Check-outs</span>
                            <span class="info-box-number">{{ $pendingCheckOuts->count() }}</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabs for different views -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary card-tabs">
                        <div class="card-header p-0 pt-1">
                            <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="pending-tab" data-toggle="pill" href="#pending" role="tab">
                                        <i class="fas fa-clock mr-1"></i>
                                        Pending Check-outs ({{ $pendingCheckOuts->count() }})
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="checkins-tab" data-toggle="pill" href="#checkins" role="tab">
                                        <i class="fas fa-sign-in-alt mr-1"></i>
                                        Today's Check-ins ({{ $todayCheckIns->count() }})
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="checkouts-tab" data-toggle="pill" href="#checkouts" role="tab">
                                        <i class="fas fa-sign-out-alt mr-1"></i>
                                        Today's Check-outs ({{ $todayCheckOuts->count() }})
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-one-tabContent">
                                
                                <!-- Pending Check-outs Tab -->
                                <div class="tab-pane fade show active" id="pending" role="tabpanel">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead class="bg-warning">
                                                <tr>
                                                    <th>Driver</th>
                                                    <th>Plant Name</th>
                                                    <th>Check-in Time</th>
                                                    <th>Duration</th>
                                                    <th>Shift Type</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse($pendingCheckOuts as $record)
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="mr-2">
                                                                    <div class="bg-warning rounded-circle d-flex align-items-center justify-content-center" style="width: 30px; height: 30px;">
                                                                        <span class="text-white font-weight-bold text-sm">
                                                                            @if($record->driver)
                                                                                {{ strtoupper(substr($record->driver->first_name, 0, 1) . substr($record->driver->last_name ?? '', 0, 1)) }}
                                                                            @else
                                                                                ?
                                                                            @endif
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <div>
                                                                    @if($record->driver)
                                                                        <strong>{{ $record->driver->first_name }} {{ $record->driver->last_name }}</strong><br>
                                                                        <small class="text-muted">{{ $record->driver->mobile }}</small>
                                                                    @else
                                                                        <span class="text-muted">Driver not found</span>
                                                                    @endif
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>{{ $record->plant_name ?? 'N/A' }}</td>
                                                        <td>
                                                            @if($record->check_in_time && $record->check_in_date)
                                                                <strong>{{ $record->check_in_time }}</strong><br>
                                                                <small class="text-muted">{{ \Carbon\Carbon::parse($record->check_in_date)->format('M d, Y') }}</small>
                                                            @else
                                                                <span class="text-muted">N/A</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            @if($record->check_in_date && $record->check_in_time)
                                                                @php
                                                                    $checkInDateTime = \Carbon\Carbon::parse($record->check_in_date . ' ' . $record->check_in_time);
                                                                    $duration = $checkInDateTime->diffForHumans(null, true);
                                                                @endphp
                                                                <span class="badge badge-info">{{ $duration }}</span>
                                                            @else
                                                                <span class="text-muted">N/A</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            @if($record->shift_type)
                                                                <span class="badge badge-secondary">{{ ucfirst($record->shift_type) }}</span>
                                                            @else
                                                                <span class="text-muted">N/A</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            <div class="btn-group btn-group-sm" role="group">
                                                                <button class="btn btn-info" onclick="viewDetails({{ $record->id }})" title="View Details">
                                                                    <i class="fas fa-eye"></i>
                                                                </button>
                                                                @if($record->driver && $record->driver->latitude && $record->driver->longitude)
                                                                    <a href="{{ route('admin-v1.drivers.location', $record->driver->id) }}" class="btn btn-success" title="View Location">
                                                                        <i class="fas fa-map-marker-alt"></i>
                                                                    </a>
                                                                @endif
                                                                @if($record->photo)
                                                                    <button class="btn btn-warning" onclick="viewPhoto('{{ $record->photo }}')" title="View Photo">
                                                                        <i class="fas fa-camera"></i>
                                                                    </button>
                                                                @endif
                                                                <button class="btn btn-danger" onclick="checkoutDriver({{ $record->id }})" title="Check Out">
                                                                    <i class="fas fa-sign-out-alt"></i> Check Out
                                                                </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="6" class="text-center">
                                                            <div class="py-4">
                                                                <i class="fas fa-check-circle text-success fa-3x mb-3"></i>
                                                                <h5>All drivers have checked out!</h5>
                                                                <p class="text-muted">No pending check-outs at the moment.</p>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <!-- Today's Check-ins Tab -->
                                <div class="tab-pane fade" id="checkins" role="tabpanel">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead class="bg-success">
                                                <tr>
                                                    <th>Driver</th>
                                                    <th>Plant Name</th>
                                                    <th>Check-in Time</th>
                                                    <th>Shift Type</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse($todayCheckIns as $record)
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="mr-2">
                                                                    <div class="bg-success rounded-circle d-flex align-items-center justify-content-center" style="width: 30px; height: 30px;">
                                                                        <span class="text-white font-weight-bold text-sm">
                                                                            @if($record->driver)
                                                                                {{ strtoupper(substr($record->driver->first_name, 0, 1) . substr($record->driver->last_name ?? '', 0, 1)) }}
                                                                            @else
                                                                                ?
                                                                            @endif
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <div>
                                                                    @if($record->driver)
                                                                        <strong>{{ $record->driver->first_name }} {{ $record->driver->last_name }}</strong><br>
                                                                        <small class="text-muted">{{ $record->driver->mobile }}</small>
                                                                    @else
                                                                        <span class="text-muted">Driver not found</span>
                                                                    @endif
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>{{ $record->plant_name ?? 'N/A' }}</td>
                                                        <td>
                                                            <strong>{{ $record->check_in_time }}</strong><br>
                                                            <small class="text-muted">{{ \Carbon\Carbon::parse($record->check_in_date)->format('M d, Y') }}</small>
                                                        </td>
                                                        <td>
                                                            @if($record->shift_type)
                                                                <span class="badge badge-secondary">{{ ucfirst($record->shift_type) }}</span>
                                                            @else
                                                                <span class="text-muted">N/A</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            @if($record->check_out_time)
                                                                <span class="badge badge-success">Completed</span>
                                                            @else
                                                                <span class="badge badge-warning">In Progress</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            <div class="btn-group btn-group-sm" role="group">
                                                                <button class="btn btn-info" onclick="viewDetails({{ $record->id }})" title="View Details">
                                                                    <i class="fas fa-eye"></i>
                                                                </button>
                                                                @if($record->driver && $record->driver->latitude && $record->driver->longitude)
                                                                    <a href="{{ route('admin-v1.drivers.location', $record->driver->id) }}" class="btn btn-success" title="View Location">
                                                                        <i class="fas fa-map-marker-alt"></i>
                                                                    </a>
                                                                @endif
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="6" class="text-center">
                                                            <div class="py-4">
                                                                <i class="fas fa-calendar-times text-muted fa-3x mb-3"></i>
                                                                <h5>No check-ins today</h5>
                                                                <p class="text-muted">No drivers have checked in today yet.</p>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <!-- Today's Check-outs Tab -->
                                <div class="tab-pane fade" id="checkouts" role="tabpanel">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead class="bg-info">
                                                <tr>
                                                    <th>Driver</th>
                                                    <th>Plant Name</th>
                                                    <th>Check-out Time</th>
                                                    <th>Total Duration</th>
                                                    <th>Shift Type</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse($todayCheckOuts as $record)
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="mr-2">
                                                                    <div class="bg-info rounded-circle d-flex align-items-center justify-content-center" style="width: 30px; height: 30px;">
                                                                        <span class="text-white font-weight-bold text-sm">
                                                                            @if($record->driver)
                                                                                {{ strtoupper(substr($record->driver->first_name, 0, 1) . substr($record->driver->last_name ?? '', 0, 1)) }}
                                                                            @else
                                                                                ?
                                                                            @endif
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <div>
                                                                    @if($record->driver)
                                                                        <strong>{{ $record->driver->first_name }} {{ $record->driver->last_name }}</strong><br>
                                                                        <small class="text-muted">{{ $record->driver->mobile }}</small>
                                                                    @else
                                                                        <span class="text-muted">Driver not found</span>
                                                                    @endif
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>{{ $record->plant_name ?? 'N/A' }}</td>
                                                        <td>
                                                            <strong>{{ $record->check_out_time }}</strong><br>
                                                            <small class="text-muted">{{ \Carbon\Carbon::parse($record->check_out_date)->format('M d, Y') }}</small>
                                                        </td>
                                                        <td>
                                                            @if($record->check_in_time && $record->check_out_time && $record->check_in_date && $record->check_out_date)
                                                                @php
                                                                    $checkIn = \Carbon\Carbon::parse($record->check_in_date . ' ' . $record->check_in_time);
                                                                    $checkOut = \Carbon\Carbon::parse($record->check_out_date . ' ' . $record->check_out_time);
                                                                    $duration = $checkIn->diffForHumans($checkOut, true);
                                                                @endphp
                                                                <span class="badge badge-primary">{{ $duration }}</span>
                                                            @else
                                                                <span class="text-muted">N/A</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            @if($record->shift_type)
                                                                <span class="badge badge-secondary">{{ ucfirst($record->shift_type) }}</span>
                                                            @else
                                                                <span class="text-muted">N/A</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            <div class="btn-group btn-group-sm" role="group">
                                                                <button class="btn btn-info" onclick="viewDetails({{ $record->id }})" title="View Details">
                                                                    <i class="fas fa-eye"></i>
                                                                </button>
                                                                @if($record->driver && $record->driver->latitude && $record->driver->longitude)
                                                                    <a href="{{ route('admin-v1.drivers.location', $record->driver->id) }}" class="btn btn-success" title="View Location">
                                                                        <i class="fas fa-map-marker-alt"></i>
                                                                    </a>
                                                                @endif
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="6" class="text-center">
                                                            <div class="py-4">
                                                                <i class="fas fa-calendar-times text-muted fa-3x mb-3"></i>
                                                                <h5>No check-outs today</h5>
                                                                <p class="text-muted">No drivers have checked out today yet.</p>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content -->
@endsection

@push('scripts')
<script>
// Update current time and date
function updateDateTime() {
    const now = new Date();
    const timeOptions = { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        hour12: true 
    };
    const dateOptions = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    };
    
    document.getElementById('current-time').textContent = now.toLocaleTimeString('en-US', timeOptions);
    document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', dateOptions);
}

// Update time every second
setInterval(updateDateTime, 1000);
updateDateTime(); // Initial call

// View attendance details
function viewDetails(recordId) {
    // You can implement AJAX call to get detailed record information
    Swal.fire({
        title: 'Loading...',
        text: 'Fetching attendance details',
        allowOutsideClick: false,
        showConfirmButton: false,
        willOpen: () => {
            Swal.showLoading();
        }
    });
    
    // Simulate API call - replace with actual AJAX call
    setTimeout(() => {
        Swal.fire({
            title: 'Attendance Details',
            html: `
                <div class="text-left">
                    <h5><i class="fas fa-info-circle text-primary"></i> Record Information</h5>
                    <p><strong>Record ID:</strong> ${recordId}</p>
                    <p><strong>Status:</strong> <span class="badge badge-info">Active</span></p>
                    <hr>
                    <p class="text-muted">Detailed information would be loaded from the server.</p>
                </div>
            `,
            width: '600px',
            showConfirmButton: true,
            confirmButtonText: 'Close'
        });
    }, 1000);
}

// View photo
function viewPhoto(photoPath) {
   
    if (!photoPath) {
        Swal.fire('Error', 'No photo available', 'error');
        return;
    }
    
    // Extract just the filename for display
    const fileName = photoPath.split('/').pop() || 'Photo';
    // Use the full path from the public directory
    const fullPhotoPath = `{{ url('/upload/driver/selfie') }}/${photoPath}`;
    
    Swal.fire({
        title: `Attendance Photo`,
        customClass: {
            title: 'text-left'
        },
        html: `<img src="${fullPhotoPath}" style="max-width: 100%; max-height: 70vh; object-fit: contain;" alt="Attendance Photo" onerror="this.onerror=null; this.src='{{ url('/upload/driver/selfie/no-image.jpeg') }}';">`,
        showConfirmButton: false,
        showCloseButton: true,
        width: '600px',
        backdrop: `
            rgba(0,0,0,0.8)
            url("{{ asset('assets/admin/images/loading.gif') }}")
            center top
            no-repeat
        `,
        showLoaderOnConfirm: false,
        didOpen: () => {
            // Preload the image
            const img = new Image();
            img.src = fullPhotoPath;
            img.onload = function() {
                // Image loaded successfully
                const container = Swal.getHtmlContainer();
                if (container) {
                    container.querySelector('img').style.display = 'block';
                }
            };
            img.onerror = function() {
                // Handle image loading error
                const container = Swal.getHtmlContainer();
                if (container) {
                    container.querySelector('img').src = '{{ url('/upload/driver/selfie/no-image.jpeg') }}';
                }
            };
        }
    });
}

// Handle driver checkout
function checkoutDriver(recordId) {
    Swal.fire({
        title: 'Check Out Driver',
        text: 'Are you sure you want to check out this driver?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, check out',
        cancelButtonText: 'Cancel',
        showLoaderOnConfirm: true,
        preConfirm: () => {
            return fetch(`{{ route('admin-v1.driver-manager.check-out', '') }}/${recordId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ _token: '{{ csrf_token() }}' })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(response.statusText);
                }
                return response.json();
            })
            .catch(error => {
                Swal.showValidationMessage(
                    `Request failed: ${error}`
                )
            });
        },
        allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                title: 'Success!',
                text: 'Driver has been checked out successfully.',
                icon: 'success',
                timer: 2000,
                showConfirmButton: false
            }).then(() => {
                // Refresh the page to update the list
                location.reload();
            });
        }
    });
}

// Handle check-out button click
function checkoutDriver(recordId) {
    // Set current date and time
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().substring(0, 5);
    
    // Set form values
    document.getElementById('checkoutRecordId').value = recordId;
    document.getElementById('check_out_date').value = dateStr;
    document.getElementById('check_out_time').value = timeStr;
    
    // Clear previous values
    document.getElementById('check_out_latitude').value = '';
    document.getElementById('check_out_longitude').value = '';
    
    // Show the modal
    $('#checkoutModal').modal('show');
}

// Get current location
function getCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            function(position) {
                document.getElementById('check_out_latitude').value = position.coords.latitude;
                document.getElementById('check_out_longitude').value = position.coords.longitude;
            },
            function(error) {
                console.error('Error getting location:', error);
                Swal.fire('Error', 'Could not get your location. Please enter it manually.', 'error');
            },
            { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
        );
    } else {
        Swal.fire('Error', 'Geolocation is not supported by your browser', 'error');
    }
}

// Handle form submission
$('#checkoutForm').on('submit', function(e) {
    e.preventDefault();
    
    const recordId = $('#checkoutRecordId').val();
    const formData = $(this).serialize();
    
    Swal.fire({
        title: 'Checking Out',
        text: 'Please wait while we process the check-out...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    // Send AJAX request
    $.ajax({
        url: `{{ route('admin-v1.driver-manager.check-out', '') }}/${recordId}`.replace(/\/$/, ''),
        type: 'POST',
        data: formData,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {
            $('#checkoutModal').modal('hide');
            Swal.fire({
                title: 'Success!',
                text: response.message || 'Driver checked out successfully',
                icon: 'success',
                timer: 2000,
                showConfirmButton: false
            }).then(() => {
                location.reload();
            });
        },
        error: function(xhr) {
            let errorMessage = 'An error occurred while checking out the driver';
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMessage = xhr.responseJSON.message;
            }
            Swal.fire('Error', errorMessage, 'error');
        }
    });
});

// Auto-refresh every 30 seconds for real-time updates
setInterval(function() {
    // Only refresh if user is on the pending tab (most important for real-time monitoring)
    if (document.getElementById('pending-tab') && document.getElementById('pending-tab').classList.contains('active')) {
        location.reload();
    }
}, 30000); // 30 seconds
</script>
@endpush

<!-- Check-out Modal -->
<div class="modal fade" id="checkoutModal" tabindex="-1" role="dialog" aria-labelledby="checkoutModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="checkoutModalLabel">Check Out Driver</h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="checkoutForm">
                @csrf
                <input type="hidden" name="record_id" id="checkoutRecordId">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="check_out_date">Check-out Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="check_out_date" name="check_out_date" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="check_out_time">Check-out Time <span class="text-danger">*</span></label>
                                <input type="time" class="form-control" id="check_out_time" name="check_out_time" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="check_out_latitude">Latitude <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="check_out_latitude" name="check_out_latitude" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="check_out_longitude">Longitude <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="check_out_longitude" name="check_out_longitude" required>
                            </div>
                        </div>
                    </div>
                </div>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Check-out</button>
                </div>
            </form>
        </div>
    </div>
</div>

</div>@push('styles')
<style>
.bg-gradient-primary {
    background: linear-gradient(45deg, #007bff, #0056b3);
}

.nav-tabs .nav-link {
    border: none;
    border-bottom: 3px solid transparent;
}

.nav-tabs .nav-link.active {
    border-bottom-color: #007bff;
    background: none;
}

.table th {
    border-top: none;
    font-weight: 600;
    font-size: 0.9rem;
}

.btn-group-sm .btn {
    padding: 0.25rem 0.5rem;
    font-size: 0.75rem;
}

@media (max-width: 768px) {
    .table-responsive {
        font-size: 0.85rem;
    }
    
    .btn-group-sm .btn {
        padding: 0.2rem 0.4rem;
        font-size: 0.7rem;
    }
    
    .d-flex.align-items-center {
        flex-direction: column;
        align-items: flex-start !important;
    }
    
    .d-flex.align-items-center .mr-2 {
        margin-right: 0 !important;
        margin-bottom: 0.5rem;
    }
}
</style>
@endpush
