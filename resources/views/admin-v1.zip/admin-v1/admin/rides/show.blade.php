@extends('admin-v1.layouts.header')
@section('title', $title)
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Page Header -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-eye text-primary mr-2"></i>
                                Ride Details - #{{ $ride->id }}
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.rides') }}" class="btn btn-secondary btn-sm">
                                    <i class="fas fa-arrow-left mr-1"></i> Back to Rides
                                </a>
                                <a href="{{ route('admin-v1.rides.edit', $ride->id) }}" class="btn btn-warning btn-sm">
                                    <i class="fas fa-edit mr-1"></i> Edit Ride
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Ride Information -->
            <div class="row">
                <!-- Left Column -->
                <div class="col-lg-8">
                    <!-- Ride Details Card -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-info-circle text-info mr-2"></i>
                                Ride Information
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-borderless">
                                        <tr>
                                            <td><strong>Ride ID:</strong></td>
                                            <td>#{{ $ride->id }}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Status:</strong></td>
                                            <td>
                                                @switch(strtolower($ride->status ?? ''))
                                                    @case('pending')
                                                        <span class="badge badge-warning">Pending</span>
                                                        @break
                                                    @case('accepted')
                                                        <span class="badge badge-info">Accepted</span>
                                                        @break
                                                    @case('picked')
                                                        <span class="badge badge-primary">Picked</span>
                                                        @break
                                                    @case('dropped')
                                                        <span class="badge badge-secondary">Dropped</span>
                                                        @break
                                                    @case('complete')
                                                        <span class="badge badge-success">Complete</span>
                                                        @break
                                                    @case('cancel')
                                                    @case('cancelled')
                                                        <span class="badge badge-danger">Cancelled</span>
                                                        @break
                                                    @default
                                                        <span class="badge badge-light">{{ ucfirst($ride->status ?? 'Unknown') }}</span>
                                                @endswitch
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Charges:</strong></td>
                                            <td>₹{{ number_format($ride->charges ?? 0, 2) }}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Distance:</strong></td>
                                            <td>{{ $ride->distance ?? 'N/A' }} km</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Created:</strong></td>
                                            <td>{{ $ride->created_at ? $ride->created_at->format('d M Y, h:i A') : 'N/A' }}</td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-md-6">
                                    <table class="table table-borderless">
                                        <tr>
                                            <td><strong>Vehicle Type:</strong></td>
                                            <td>{{ $ride->vehicle->name ?? 'N/A' }}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Payment Method:</strong></td>
                                            <td>{{ ucfirst($ride->payment_method ?? 'N/A') }}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Booking Type:</strong></td>
                                            <td>{{ ucfirst($ride->booking_type ?? 'N/A') }}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Updated:</strong></td>
                                            <td>{{ $ride->updated_at ? $ride->updated_at->format('d M Y, h:i A') : 'N/A' }}</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Location Details Card -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map-marker-alt text-success mr-2"></i>
                                Location Details
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5><i class="fas fa-arrow-up text-success mr-2"></i>Pickup Location</h5>
                                    <p class="text-muted">{{ $ride->pickup_address ?? 'N/A' }}</p>
                                    @if($ride->pickup_latitude && $ride->pickup_longitude)
                                        <small class="text-info">
                                            <i class="fas fa-map-pin mr-1"></i>
                                            {{ $ride->pickup_latitude }}, {{ $ride->pickup_longitude }}
                                            <a href="https://www.google.com/maps/place/{{ $ride->pickup_latitude }},{{ $ride->pickup_longitude }}" target="_blank" class="ml-2">
                                                <i class="fas fa-external-link-alt"></i> View on Map
                                            </a>
                                        </small>
                                    @endif
                                </div>
                                <div class="col-md-6">
                                    <h5><i class="fas fa-arrow-down text-danger mr-2"></i>Drop Location</h5>
                                    <p class="text-muted">{{ $ride->drop_address ?? 'N/A' }}</p>
                                    @if($ride->drop_latitude && $ride->drop_longitude)
                                        <small class="text-info">
                                            <i class="fas fa-map-pin mr-1"></i>
                                            {{ $ride->drop_latitude }}, {{ $ride->drop_longitude }}
                                            <a href="https://www.google.com/maps/place/{{ $ride->drop_latitude }},{{ $ride->drop_longitude }}" target="_blank" class="ml-2">
                                                <i class="fas fa-external-link-alt"></i> View on Map
                                            </a>
                                        </small>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Column -->
                <div class="col-lg-4">
                    <!-- User Information Card -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-user text-primary mr-2"></i>
                                User Information
                            </h3>
                        </div>
                        <div class="card-body">
                            @if($ride->user)
                                <div class="text-center mb-3">
                                    <div class="avatar-circle mx-auto" style="width: 60px; height: 60px; background: #007bff; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 24px;">
                                        {{ strtoupper(substr($ride->user->username ?? 'U', 0, 1)) }}
                                    </div>
                                    <h5 class="mt-2">{{ $ride->user->username ?? 'N/A' }}</h5>
                                </div>
                                <table class="table table-sm table-borderless">
                                    <tr>
                                        <td><strong>Mobile:</strong></td>
                                        <td>{{ $ride->user->mobile ?? 'N/A' }}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Email:</strong></td>
                                        <td>{{ $ride->user->email ?? 'N/A' }}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Gender:</strong></td>
                                        <td>{{ ucfirst($ride->user->gender ?? 'N/A') }}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Status:</strong></td>
                                        <td>
                                            @if($ride->user->status == 0)
                                                <span class="badge badge-success">Active</span>
                                            @else
                                                <span class="badge badge-danger">Blocked</span>
                                            @endif
                                        </td>
                                    </tr>
                                </table>
                                <div class="text-center">
                                    <a href="{{ route('admin-v1.users.edit', $ride->user->id) }}" class="btn btn-primary btn-sm">
                                        <i class="fas fa-user-edit mr-1"></i> View User
                                    </a>
                                </div>
                            @else
                                <p class="text-muted text-center">No user information available</p>
                            @endif
                        </div>
                    </div>

                    <!-- Driver Information Card -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-user-tie text-warning mr-2"></i>
                                Driver Information
                            </h3>
                        </div>
                        <div class="card-body">
                            @if($ride->driver)
                                <div class="text-center mb-3">
                                    <div class="avatar-circle mx-auto" style="width: 60px; height: 60px; background: #ffc107; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 24px;">
                                        {{ strtoupper(substr($ride->driver->first_name ?? 'D', 0, 1)) }}
                                    </div>
                                    <h5 class="mt-2">{{ $ride->driver->first_name }} {{ $ride->driver->last_name ?? '' }}</h5>
                                </div>
                                <table class="table table-sm table-borderless">
                                    <tr>
                                        <td><strong>Mobile:</strong></td>
                                        <td>{{ $ride->driver->mobile ?? 'N/A' }}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Vehicle:</strong></td>
                                        <td>{{ $ride->driver->vehicle_number ?? 'N/A' }}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Status:</strong></td>
                                        <td>
                                            @if($ride->driver->status == 0)
                                                <span class="badge badge-success">Active</span>
                                            @else
                                                <span class="badge badge-danger">Blocked</span>
                                            @endif
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Profile:</strong></td>
                                        <td>
                                            @if($ride->driver->profile_status == 1)
                                                <span class="badge badge-success">Verified</span>
                                            @else
                                                <span class="badge badge-warning">Pending</span>
                                            @endif
                                        </td>
                                    </tr>
                                </table>
                                <div class="text-center">
                                    <a href="{{ route('admin-v1.drivers.show', $ride->driver->id) }}" class="btn btn-warning btn-sm">
                                        <i class="fas fa-user-tie mr-1"></i> View Driver
                                    </a>
                                </div>
                            @else
                                <p class="text-muted text-center">No driver assigned</p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('styles')
<style>
    .avatar-circle {
        font-size: 24px;
    }

    .table-borderless td {
        border: none;
        padding: 8px 0;
    }

    .card {
        box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    }
</style>
@endpush
