@extends('admin-v1.layouts.header')
@section('title', $title)
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Page Header -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-edit text-warning mr-2"></i>
                                Edit Ride - #{{ $ride->id }}
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.rides') }}" class="btn btn-secondary btn-sm">
                                    <i class="fas fa-arrow-left mr-1"></i> Back to Rides
                                </a>
                                <a href="{{ route('admin-v1.rides.show', $ride->id) }}" class="btn btn-info btn-sm">
                                    <i class="fas fa-eye mr-1"></i> View Details
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Edit Form -->
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-edit text-primary mr-2"></i>
                                Edit Ride Information
                            </h3>
                        </div>
                        <div class="card-body">
                            <form id="editRideForm" method="POST" action="{{ route('admin-v1.rides.update', $ride->id) }}">
                                @csrf
                                @method('PUT')
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="status">Ride Status <span class="text-danger">*</span></label>
                                            <select class="form-control" id="status" name="status" required>
                                                <option value="">Select Status</option>
                                                <option value="pending" {{ $ride->status == 'pending' ? 'selected' : '' }}>Pending</option>
                                                <option value="accepted" {{ $ride->status == 'accepted' ? 'selected' : '' }}>Accepted</option>
                                                <option value="picked" {{ $ride->status == 'picked' ? 'selected' : '' }}>Picked</option>
                                                <option value="dropped" {{ $ride->status == 'dropped' ? 'selected' : '' }}>Dropped</option>
                                                <option value="complete" {{ $ride->status == 'complete' ? 'selected' : '' }}>Complete</option>
                                                <option value="cancelled" {{ in_array($ride->status, ['cancel', 'cancelled']) ? 'selected' : '' }}>Cancelled</option>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="driver_id">Assign Driver</label>
                                            <select class="form-control" id="driver_id" name="driver_id">
                                                <option value="">Select Driver</option>
                                                @foreach($drivers as $driver)
                                                    <option value="{{ $driver->id }}" {{ $ride->driver_id == $driver->id ? 'selected' : '' }}>
                                                        {{ $driver->first_name }} {{ $driver->last_name ?? '' }} - {{ $driver->mobile }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="charges">Ride Charges (₹)</label>
                                            <input type="number" class="form-control" id="charges" name="charges" 
                                                   value="{{ $ride->charges }}" min="0" step="0.01" placeholder="Enter charges">
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="distance">Distance (km)</label>
                                            <input type="number" class="form-control" id="distance" name="distance" 
                                                   value="{{ $ride->distance }}" min="0" step="0.1" placeholder="Enter distance" readonly>
                                            <small class="text-muted">Distance is calculated automatically</small>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Pickup Address</label>
                                    <textarea class="form-control" rows="2" readonly>{{ $ride->pickup_address ?? 'N/A' }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label>Drop Address</label>
                                    <textarea class="form-control" rows="2" readonly>{{ $ride->drop_address ?? 'N/A' }}</textarea>
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary" id="submitBtn">
                                        <i class="fas fa-save mr-1"></i> Update Ride
                                    </button>
                                    <button type="button" class="btn btn-secondary" onclick="resetForm()">
                                        <i class="fas fa-undo mr-1"></i> Reset
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Ride Information Sidebar -->
                <div class="col-lg-4">
                    <!-- Current Ride Info -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-info-circle text-info mr-2"></i>
                                Current Ride Info
                            </h3>
                        </div>
                        <div class="card-body">
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <td><strong>Ride ID:</strong></td>
                                    <td>#{{ $ride->id }}</td>
                                </tr>
                                <tr>
                                    <td><strong>User:</strong></td>
                                    <td>{{ $ride->user->username ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Mobile:</strong></td>
                                    <td>{{ $ride->user->mobile ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Current Status:</strong></td>
                                    <td>
                                        @switch(strtolower($ride->status ?? ''))
                                            @case('pending')
                                                <span class="badge badge-warning">Pending</span>
                                                @break
                                            @case('accepted')
                                                <span class="badge badge-info">Accepted</span>
                                                @break
                                            @case('picked')
                                                <span class="badge badge-primary">Picked</span>
                                                @break
                                            @case('dropped')
                                                <span class="badge badge-secondary">Dropped</span>
                                                @break
                                            @case('complete')
                                                <span class="badge badge-success">Complete</span>
                                                @break
                                            @case('cancel')
                                            @case('cancelled')
                                                <span class="badge badge-danger">Cancelled</span>
                                                @break
                                            @default
                                                <span class="badge badge-light">{{ ucfirst($ride->status ?? 'Unknown') }}</span>
                                        @endswitch
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Created:</strong></td>
                                    <td>{{ $ride->created_at ? $ride->created_at->format('d M Y') : 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Vehicle:</strong></td>
                                    <td>{{ $ride->vehicle->name ?? 'N/A' }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Current Driver Info -->
                    @if($ride->driver)
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-user-tie text-warning mr-2"></i>
                                Current Driver
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="text-center mb-3">
                                <div class="avatar-circle mx-auto" style="width: 50px; height: 50px; background: #ffc107; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 18px;">
                                    {{ strtoupper(substr($ride->driver->first_name ?? 'D', 0, 1)) }}
                                </div>
                                <h6 class="mt-2">{{ $ride->driver->first_name }} {{ $ride->driver->last_name ?? '' }}</h6>
                                <small class="text-muted">{{ $ride->driver->mobile }}</small>
                            </div>
                            <p class="text-center">
                                <span class="badge badge-info">{{ $ride->driver->vehicle_number ?? 'N/A' }}</span>
                            </p>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </section>
@endsection

@push('styles')
<style>
    .table-borderless td {
        border: none;
        padding: 6px 0;
    }

    .avatar-circle {
        font-size: 18px;
    }

    .form-control:focus {
        border-color: #007bff;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .invalid-feedback {
        display: none;
    }

    .is-invalid ~ .invalid-feedback {
        display: block;
    }
</style>
@endpush

@push('scripts')
<script>
$(document).ready(function() {
    // Form submission
    $('#editRideForm').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const submitBtn = $('#submitBtn');
        const originalText = submitBtn.html();
        
        // Clear previous errors
        $('.form-control').removeClass('is-invalid');
        $('.invalid-feedback').text('');
        
        // Show loading state
        submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin mr-1"></i> Updating...');
        
        $.ajax({
            url: form.attr('action'),
            method: 'PUT',
            data: form.serialize(),
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        if (response.redirect) {
                            window.location.href = response.redirect;
                        }
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: response.message || 'Something went wrong'
                    });
                }
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    // Validation errors
                    const errors = xhr.responseJSON.errors;
                    $.each(errors, function(field, messages) {
                        const input = $(`[name="${field}"]`);
                        input.addClass('is-invalid');
                        input.siblings('.invalid-feedback').text(messages[0]);
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: 'Something went wrong. Please try again.'
                    });
                }
            },
            complete: function() {
                submitBtn.prop('disabled', false).html(originalText);
            }
        });
    });
});

function resetForm() {
    $('#editRideForm')[0].reset();
    $('.form-control').removeClass('is-invalid');
    $('.invalid-feedback').text('');
}
</script>
@endpush
