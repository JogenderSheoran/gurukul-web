@extends('admin-v1.layouts.header')
@section('title', $title)
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Statistics Cards Row -->
            <div class="row">
                <div class="col-lg-2 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3 id="totalRides">{{ $totalRides }}</h3>
                            <p>Total Rides</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-car"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3 id="completedRides">{{ $completedRides }}</h3>
                            <p>Completed</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3 id="pendingRides">{{ $pendingRides }}</h3>
                            <p>Pending</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3 id="cancelledRides">{{ $cancelledRides }}</h3>
                            <p>Cancelled</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-times-circle"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="small-box bg-primary">
                        <div class="inner">
                            <h3 id="todayRides">{{ $todayRides }}</h3>
                            <p>Today's Rides</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-calendar-day"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="small-box bg-secondary">
                        <div class="inner">
                            <h3 id="totalRevenue">₹{{ number_format($totalRevenue, 0) }}</h3>
                            <p>Total Revenue</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-rupee-sign"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Rides Table -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-list text-primary mr-2"></i>
                                Rides Management
                            </h3>
                            <div class="card-tools">
                                <div class="input-group input-group-sm" style="width: 250px;">
                                    <input type="text" id="searchInput" class="form-control float-right" placeholder="Search rides...">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="ridesTable" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th style="width: 80px;">Ride ID</th>
                                            <th style="width: 180px;">User Details</th>
                                            <th style="width: 200px;">Pickup Address</th>
                                            <th style="width: 200px;">Drop Address</th>
                                            <th style="width: 100px;">Charges</th>
                                            <th style="width: 180px;">Driver</th>
                                            <th style="width: 120px;">Status</th>
                                            <th style="width: 140px;">Date</th>
                                            <th style="width: 120px;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- DataTable will populate this -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('styles')
<style>
    .small-box .inner h3 {
        font-size: 1.5rem;
        margin-bottom: 5px;
    }

    .table th {
        background-color: #f8f9fa;
        border-top: none;
        font-weight: 600;
        font-size: 14px;
    }

    .table td {
        vertical-align: middle;
        font-size: 13px;
    }

    .badge {
        font-size: 11px;
        padding: 4px 8px;
    }

    .btn-group .btn {
        margin-right: 2px;
    }

    .btn-group .btn:last-child {
        margin-right: 0;
    }
</style>
@endpush

@push('scripts')
<script>
$(document).ready(function() {
    // Initialize DataTable
    var table = $('#ridesTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "{{ route('admin-v1.rides.data') }}",
            type: 'GET',
            data: function(d) {
                // Add any additional parameters if needed
                return d;
            }
        },
        columns: [
            { data: 'ride_id', name: 'ride_id', orderable: false },
            { data: 'user_detail', name: 'user_detail', orderable: false },
            { data: 'pickup_address', name: 'pickup_address' },
            { data: 'drop_address', name: 'drop_address' },
            { data: 'charges', name: 'charges' },
            { data: 'driver', name: 'driver', orderable: false },
            { data: 'status', name: 'status' },
            { data: 'ride_date', name: 'ride_date' },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ],
        order: [[7, 'desc']], // Order by date descending
        pageLength: 10,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        responsive: true,
        language: {
            processing: '<i class="fas fa-spinner fa-spin"></i> Loading rides...',
            emptyTable: 'No rides found',
            zeroRecords: 'No matching rides found'
        },
        drawCallback: function(settings) {
            // Initialize tooltips for action buttons
            $('[data-toggle="tooltip"]').tooltip();
        }
    });

    // Custom search
    $('#searchInput').on('keyup', function() {
        table.search(this.value).draw();
    });

    // Auto refresh every 60 seconds (reduced frequency)
    setInterval(function() {
        table.ajax.reload(null, false);
    }, 60000);
});
</script>
@endpush
