{{-- \resources\views\admin-v1\admin\ivr-leads.blade.php --}}
@extends('admin-v1.layouts.header')
@section('title')
    <title>
        IVR Leads - Admin Dashboard
    </title>
@endsection
@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark"><i class="fa fa-phone-alt"></i> IVR Leads</h1>
                </div><!-- /.col -->
                {{--<div class="col-sm-6 text-right">
                    <a href="#" class="btn btn-primary btn-rounded text-dark"><i class="fa fa-download"></i>
                        Export Leads</a>
                </div>--}}<!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Statistics Cards Row -->
            <div class="row mb-4">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>{{ number_format($openLead) }}</h3>
                            <p>Open Leads Today</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-hourglass-half"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-primary">
                        <div class="inner">
                            <h3>{{ number_format($convertedLead) }}</h3>
                            <p>Converted Today</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>₹{{ number_format($totalRevenue, 0) }}</h3>
                            <p>Revenue Today</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-rupee-sign"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{ number_format($totalLead) }}</h3>
                            <p>Total Leads Today</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-phone-alt"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Advanced Filters Card -->
            <div class="row">
                <div class="col-12">
                    <div class="card collapsed-card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-filter"></i> Advanced Filters</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body" style="display: none;">
                            <form id="filterForm">
                                <div class="row">
                                    <!-- Status Filter -->
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="status_filter">Status</label>
                                            <select class="form-control select2" id="status_filter" name="status" data-placeholder="Search status...">
                                                <option value="">All Status</option>
                                                @foreach($statuses as $status)
                                                    <option value="{{ $status }}">{{ $status }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Lead Source Filter -->
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="lead_from_filter">Lead Source</label>
                                            <select class="form-control select2" id="lead_from_filter" name="lead_from" data-placeholder="Search sources...">
                                                <option value="">All Sources</option>
                                                @foreach($leadSources as $source)
                                                    <option value="{{ $source }}">{{ ucfirst($source) }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Event Name Filter -->
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="event_name_filter">Event Name</label>
                                            <select class="form-control select2" id="event_name_filter" name="event_name" data-placeholder="Search events...">
                                                <option value="">All Events</option>
                                                @foreach($eventNames as $event)
                                                    <option value="{{ $event }}">{{ $event }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Location Filter -->
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="location_filter">Location</label>
                                            <select class="form-control select2" id="location_filter" name="location" data-placeholder="Search locations...">
                                                <option value="">All Locations</option>
                                                @foreach($locationCounts as $location => $count)
                                                    <option value="{{ $location }}">{{ $location }} ({{ $count }})</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <!-- Date Range -->
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="date_from">Date From</label>
                                            <input type="date" class="form-control" id="date_from" name="date_from">
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="date_to">Date To</label>
                                            <input type="date" class="form-control" id="date_to" name="date_to">
                                        </div>
                                    </div>

                                    <!-- Search Fields -->
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="mobile_search">Mobile Number</label>
                                            <input type="text" class="form-control" id="mobile_search" name="mobile_search" placeholder="Search by mobile...">
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="name_search">Name</label>
                                            <input type="text" class="form-control" id="name_search" name="name_search" placeholder="Search by name...">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <!-- Filter Actions -->
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>&nbsp;</label>
                                            <div class="d-flex flex-wrap">
                                                <button type="button" class="btn btn-primary mr-2 mb-2" id="applyFilters">
                                                    <i class="fas fa-search"></i> Apply Filters
                                                </button>
                                                <button type="button" class="btn btn-secondary mr-2 mb-2" id="clearFilters">
                                                    <i class="fas fa-times"></i> Clear
                                                </button>
                                                <button type="button" class="btn btn-success mb-2" id="exportFiltered">
                                                    <i class="fas fa-download"></i> Export
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Quick Filters Row -->
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label>Quick Filters:</label>
                                            <div class="d-flex flex-wrap">
                                                <!-- Status Quick Filters -->
                                                <button type="button" class="btn btn-sm btn-outline-success mr-2 mb-2 quick-filter" data-filter="status" data-value="CONVERTED">
                                                    <i class="fas fa-check"></i> Converted
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-warning mr-2 mb-2 quick-filter" data-filter="status" data-value="OPEN">
                                                    <i class="fas fa-hourglass-half"></i> Open
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-danger mr-2 mb-2 quick-filter" data-filter="status" data-value="LOST">
                                                    <i class="fas fa-times"></i> Lost
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-info mr-2 mb-2 quick-filter" data-filter="status" data-value="Fresh">
                                                    <i class="fas fa-star"></i> Fresh
                                                </button>

                                                <!-- Date Quick Filters -->
                                                <button type="button" class="btn btn-sm btn-outline-primary mr-2 mb-2 date-preset" data-preset="today">
                                                    <i class="fas fa-calendar-day"></i> Today
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-primary mr-2 mb-2 date-preset" data-preset="yesterday">
                                                    <i class="fas fa-calendar-minus"></i> Yesterday
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-primary mr-2 mb-2 date-preset" data-preset="last7days">
                                                    <i class="fas fa-calendar-week"></i> Last 7 Days
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-primary mr-2 mb-2 date-preset" data-preset="last30days">
                                                    <i class="fas fa-calendar-alt"></i> Last 30 Days
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-primary mr-2 mb-2 date-preset" data-preset="thismonth">
                                                    <i class="fas fa-calendar"></i> This Month
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Data Table -->
            <div class="row">
                <div class="col-12">
                    @if( Session::has( 'success' ))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fa fa-check"></i> {{ Session::get( 'success' ) }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif
                    @if( Session::has( 'error' ))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fa fa-times"></i> {{ Session::get( 'error' ) }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif
                    @if( Session::has( 'warning' ))
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <i class="fa fa-exclamation-triangle"></i> {{ Session::get( 'warning' ) }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif
                    <div class="card card-primary">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="ivr-leads-table" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Mobile No</th>
                                        <th>Name</th>
                                        <th>Event Name</th>
                                        <th>Status</th>
                                        <th>Lead From</th>
                                        <th>Location</th>
                                        <th>Price</th>
                                        <th>Date & Time</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <!-- Data will be loaded via AJAX -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection
@push('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- page script -->
    <script>
        var table;
        $(function () {
            // Initialize Select2 for all dropdowns
            $('.select2').each(function() {
                var $this = $(this);
                var placeholder = $this.data('placeholder') || 'Select an option...';
                
                $this.select2({
                    theme: 'bootstrap4',
                    width: '100%',
                    allowClear: true,
                    placeholder: placeholder,
                    escapeMarkup: function (markup) {
                        return markup;
                    },
                    language: {
                        noResults: function() {
                            return "No results found";
                        }
                    }
                });
            });

            // Initialize DataTable using common configuration
            var config = $.extend(true, {}, window.CommonDataTableConfig, {
                "ajax": {
                    "url": "{{ route('admin-v1.ivr-leads.data') }}",
                    "type": "GET",
                    "data": function (d) {
                        // Add filter parameters
                        d.status = $('#status_filter').val();
                        d.lead_from = $('#lead_from_filter').val();
                        d.event_name = $('#event_name_filter').val();
                        d.location = $('#location_filter').val();
                        d.date_from = $('#date_from').val();
                        d.date_to = $('#date_to').val();
                        d.mobile_search = $('#mobile_search').val();
                        d.name_search = $('#name_search').val();
                    },
                    "error": function(xhr, error, thrown) {
                        console.log('DataTables AJAX Error:', error, thrown);
                        console.log('Response:', xhr.responseText);
                    }
                },
                "columns": [
                    { "data": "DT_RowIndex", "name": "DT_RowIndex", "orderable": false, "searchable": false },
                    { "data": "mobile_no", "name": "mobile_no" },
                    { "data": "name", "name": "name" },
                    { "data": "event_name", "name": "event_name" },
                    { "data": "status", "name": "status" },
                    { "data": "lead_from", "name": "lead_from" },
                    { "data": "location", "name": "location", "orderable": false, "searchable": false },
                    { "data": "price", "name": "price" },
                    { "data": "created_at", "name": "created_at" },
                    { "data": "action", "name": "action", "orderable": false, "searchable": false }
                ],
                "order": [[8, 'desc']],
                "initComplete": function(settings, json) {
                    console.log('DataTable initialized successfully');
                    console.log('Total records:', json.recordsTotal);
                    console.log('Filtered records:', json.recordsFiltered);
                }
            });
            
            table = $('#ivr-leads-table').DataTable(config);

            // Filter functionality
            $('#applyFilters').on('click', function() {
                // Clear cache when filters are applied
                leadCache = {};
                table.ajax.reload();
            });

            // Clear filters
            $('#clearFilters').on('click', function() {
                $('#filterForm')[0].reset();
                // Clear Select2 selections
                $('.select2').val(null).trigger('change');
                // Clear cache when filters are cleared
                leadCache = {};
                table.ajax.reload();
            });

            // Export filtered data
            $('#exportFiltered').on('click', function() {
                var filters = {
                    status: $('#status_filter').val(),
                    lead_from: $('#lead_from_filter').val(),
                    event_name: $('#event_name_filter').val(),
                    location: $('#location_filter').val(),
                    date_from: $('#date_from').val(),
                    date_to: $('#date_to').val(),
                    mobile_search: $('#mobile_search').val(),
                    name_search: $('#name_search').val()
                };

                // Create form and submit for export
                var form = $('<form>', {
                    'method': 'GET',
                    'action': '{{ route("admin-v1.ivr-leads.export") }}'
                });

                $.each(filters, function(key, value) {
                    if (value) {
                        form.append($('<input>', {
                            'type': 'hidden',
                            'name': key,
                            'value': value
                        }));
                    }
                });

                $('body').append(form);
                form.submit();
                form.remove();
            });

            // Quick filter buttons
            $('.quick-filter').on('click', function() {
                var filterType = $(this).data('filter');
                var filterValue = $(this).data('value');
                
                $('#' + filterType + '_filter').val(filterValue);
                table.ajax.reload();
            });

            // Real-time search for mobile and name
            $('#mobile_search, #name_search').on('keyup', function() {
                clearTimeout(window.searchTimeout);
                window.searchTimeout = setTimeout(function() {
                    table.ajax.reload();
                }, 500);
            });

            // Date range presets
            $('.date-preset').on('click', function() {
                var preset = $(this).data('preset');
                var today = new Date();
                var fromDate, toDate;

                switch(preset) {
                    case 'today':
                        fromDate = toDate = today.toISOString().split('T')[0];
                        break;
                    case 'yesterday':
                        var yesterday = new Date(today);
                        yesterday.setDate(yesterday.getDate() - 1);
                        fromDate = toDate = yesterday.toISOString().split('T')[0];
                        break;
                    case 'last7days':
                        var last7 = new Date(today);
                        last7.setDate(last7.getDate() - 7);
                        fromDate = last7.toISOString().split('T')[0];
                        toDate = today.toISOString().split('T')[0];
                        break;
                    case 'last30days':
                        var last30 = new Date(today);
                        last30.setDate(last30.getDate() - 30);
                        fromDate = last30.toISOString().split('T')[0];
                        toDate = today.toISOString().split('T')[0];
                        break;
                    case 'thismonth':
                        fromDate = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
                        toDate = today.toISOString().split('T')[0];
                        break;
                }

                $('#date_from').val(fromDate);
                $('#date_to').val(toDate);
                table.ajax.reload();
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            // Cache for lead details to avoid multiple API calls
            var leadCache = {};
            var activeRequests = {};

            // View lead details functionality
            $(document).on('click', '.view-btn', function () {
                var $btn = $(this);
                var id = $btn.data('id');
                
                // Prevent multiple clicks
                if ($btn.hasClass('loading')) {
                    return false;
                }
                
                // Check cache first
                if (leadCache[id]) {
                    showLeadModal(leadCache[id]);
                    return false;
                }
                
                // Check if request is already in progress
                if (activeRequests[id]) {
                    return false;
                }
                
                var URL = "{{ route('admin-v1.ivr-leads.show', ':id') }}";
                URL = URL.replace(':id', id);

                // Add loading state
                $btn.addClass('loading').prop('disabled', true);
                $btn.find('i').removeClass('fa-eye').addClass('fa-spinner fa-spin');
                
                // Mark request as active
                activeRequests[id] = true;

                $.ajax({
                    type: 'GET',
                    url: URL,
                    success: function (response) {
                        // Remove loading state
                        $btn.removeClass('loading').prop('disabled', false);
                        $btn.find('i').removeClass('fa-spinner fa-spin').addClass('fa-eye');
                        delete activeRequests[id];
                        
                        if (response.success) {
                            // Cache the response
                            leadCache[id] = response.data;
                            showLeadModal(response.data);
                        } else {
                            Swal.fire("Error", response.message || "Failed to load lead details", "error");
                        }
                    },
                    error: function (xhr) {
                        // Remove loading state
                        $btn.removeClass('loading').prop('disabled', false);
                        $btn.find('i').removeClass('fa-spinner fa-spin').addClass('fa-eye');
                        delete activeRequests[id];
                        
                        Swal.fire("Error", "Failed to load lead details. Try again!", "error");
                    }
                });
            });

            // Function to display lead modal (reusable for cache and fresh data)
            function showLeadModal(lead) {
                // Prepare address information
                var addressInfo = '';
                if (lead.pickup_address || lead.drop_address) {
                    addressInfo = '<hr><h6><i class="fas fa-map-marker-alt"></i> Address Information:</h6>';
                    
                    if (lead.pickup_address) {
                        var pickupAddress = typeof lead.pickup_address === 'object' ? JSON.stringify(lead.pickup_address) : lead.pickup_address;
                        addressInfo += `
                            <div class="mb-3">
                                <strong><i class="fas fa-arrow-up text-success"></i> Pickup Address:</strong>
                                <div class="bg-light p-2 rounded mt-1">
                                    ${pickupAddress || 'N/A'}
                                    ${lead.pickup_city ? '<br><span class="badge badge-success mt-1">City: ' + lead.pickup_city + '</span>' : ''}
                                </div>
                            </div>
                        `;
                    }
                    
                    if (lead.drop_address) {
                        var dropAddress = typeof lead.drop_address === 'object' ? JSON.stringify(lead.drop_address) : lead.drop_address;
                        addressInfo += `
                            <div class="mb-3">
                                <strong><i class="fas fa-arrow-down text-danger"></i> Drop Address:</strong>
                                <div class="bg-light p-2 rounded mt-1">
                                    ${dropAddress || 'N/A'}
                                    ${lead.drop_city ? '<br><span class="badge badge-danger mt-1">City: ' + lead.drop_city + '</span>' : ''}
                                </div>
                            </div>
                        `;
                    }
                }

                // Helper function to safely display any value
                function safeDisplay(value, fallback = 'N/A') {
                    if (value === null || value === undefined || value === '') {
                        return fallback;
                    }
                    if (typeof value === 'object') {
                        return JSON.stringify(value, null, 2);
                    }
                    return String(value);
                }

                Swal.fire({
                    title: '<i class="fas fa-phone-alt"></i> IVR Lead Details',
                    html: `
                        <div class="text-left">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong><i class="fas fa-mobile-alt"></i> Mobile No:</strong> ${safeDisplay(lead.mobile_no)}</p>
                                    <p><strong><i class="fas fa-user"></i> Name:</strong> ${safeDisplay(lead.name)}</p>
                                    <p><strong><i class="fas fa-envelope"></i> Email:</strong> ${safeDisplay(lead.email)}</p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong><i class="fas fa-calendar"></i> Event Name:</strong> ${safeDisplay(lead.event_name)}</p>
                                    <p><strong><i class="fas fa-info-circle"></i> Status:</strong> <span class="badge badge-info">${safeDisplay(lead.status)}</span></p>
                                    <p><strong><i class="fas fa-source-fork"></i> Lead From:</strong> <span class="badge badge-primary">${safeDisplay(lead.lead_from)}</span></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong><i class="fas fa-rupee-sign"></i> Price:</strong> ${lead.price ? '₹' + safeDisplay(lead.price) : 'N/A'}</p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong><i class="fas fa-clock"></i> Created:</strong> ${safeDisplay(lead.formatted_created_at) || (lead.created_at ? new Date(lead.created_at).toLocaleString() : 'N/A')}</p>
                                </div>
                            </div>
                            ${addressInfo}
                        </div>
                    `,
                    width: '800px',
                    showCloseButton: true,
                    showConfirmButton: false,
                    customClass: {
                        popup: 'swal-wide'
                    }
                });
            }

            // Toggle Status
            $(document).on('click', '.toggleStatusBtn', function () {
                const btn = $(this);
                const id = btn.data('id');
                const currentStatus = btn.data('status');

                $.ajax({
                    url: '#',
                    type: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        id: id,
                        status: currentStatus
                    },
                    success: function (res) {
                        if (res.success) {
                            const newStatus = currentStatus === 1 ? 0 : 1;
                            btn.data('status', newStatus)
                                .toggleClass('btn-success btn-danger')
                                .text(newStatus ? 'Active' : 'Inactive')
                                .attr('title', newStatus ? 'Click to Disable' : 'Click to Enable');
                            Swal.fire('Updated!', 'Lead status has been changed.', 'success');

                        } else {
                            Swal.fire('Error', res.message || 'Could not update status', 'error');
                        }
                    },
                    error: function () {
                        Swal.fire('Error', 'AJAX request failed.', 'error');
                    }
                });
            });
        });


    </script>
@endpush

@push('style')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css" rel="stylesheet" />
<style>
    .small-box {
        border-radius: 10px;
        box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
        transition: all 0.3s ease;
    }
    
    .small-box:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,.2);
    }
    
    .info-box {
        border-radius: 8px;
        box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    }
    
    .card {
        border-radius: 10px;
        box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    }
    
    .swal-wide {
        max-width: 90% !important;
    }
    
    .swal2-html-container .bg-light {
        background-color: #f8f9fa !important;
        border: 1px solid #dee2e6;
    }
    
    .badge {
        font-size: 0.75em;
    }
    
    .swal2-html-container pre {
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 0.25rem;
        padding: 0.75rem;
        font-size: 0.875rem;
        color: #495057;
        white-space: pre-wrap;
        word-wrap: break-word;
    }
    
    .swal2-html-container .bg-light {
        max-height: 200px;
        overflow-y: auto;
        word-break: break-word;
    }
    
    /* Select2 Custom Styling */
    .select2-container--bootstrap4 .select2-selection--single {
        height: calc(2.25rem + 2px) !important;
        border: 1px solid #ced4da !important;
        border-radius: 0.25rem !important;
    }
    
    .select2-container--bootstrap4 .select2-selection--single .select2-selection__rendered {
        padding-left: 0.75rem !important;
        padding-right: 2rem !important;
        color: #495057 !important;
        line-height: 2.25rem !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        white-space: nowrap !important;
    }
    
    .select2-container--bootstrap4 .select2-selection--single .select2-selection__arrow {
        height: calc(2.25rem + 2px) !important;
        right: 0.75rem !important;
        width: 20px !important;
    }
    
    .select2-container--bootstrap4 .select2-selection--single .select2-selection__clear {
        position: absolute !important;
        right: 2rem !important;
        top: 50% !important;
        transform: translateY(-50%) !important;
        font-size: 18px !important;
        color: #6c757d !important;
        cursor: pointer !important;
        z-index: 2 !important;
    }
    
    .select2-container--bootstrap4 .select2-selection--single .select2-selection__clear:hover {
        color: #495057 !important;
    }
    
    .select2-dropdown {
        border: 1px solid #ced4da !important;
        border-radius: 0.25rem !important;
        z-index: 9999 !important;
    }
    
    .select2-container--bootstrap4 .select2-results__option--highlighted[aria-selected] {
        background-color: #007bff !important;
        color: white !important;
    }
    
    .select2-search--dropdown .select2-search__field {
        border: 1px solid #ced4da !important;
        border-radius: 0.25rem !important;
        padding: 0.375rem 0.75rem !important;
    }
    
    /* Fix for allowClear option */
    .select2-container--bootstrap4.select2-container--focus .select2-selection--single,
    .select2-container--bootstrap4.select2-container--open .select2-selection--single {
        border-color: #80bdff !important;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25) !important;
    }

</style>
@endpush
