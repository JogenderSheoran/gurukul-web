{{-- \resources\views\admin-v1\admin\ivr-leads-stats.blade.php --}}
@extends('admin-v1.layouts.header')
@section('title')
    <title>{{ $title }} - Admin Dashboard</title>
@endsection
@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark"><i class="fa fa-chart-line"></i> IVR Leads Statistics</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('admin-v1.dashboard') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active">IVR Leads Stats</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Overview Statistics Cards Row -->
            <div class="row">
                <!-- Total Leads Card -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-primary">
                        <div class="inner">
                            <h3>{{ number_format($stats['total_leads']) }}</h3>
                            <p>Total Leads</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-phone-alt"></i>
                        </div>
                        <a href="{{ route('admin-v1.ivr-leads') }}" class="small-box-footer">View Details <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                <!-- Converted Leads Card -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>{{ number_format($stats['converted_leads']) }}</h3>
                            <p>Converted Leads</p>
                            <small>{{ $stats['conversion_rate'] }}% conversion rate</small>
                        </div>
                        <div class="icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                <!-- Total Revenue Card -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>₹{{ number_format($stats['total_revenue'], 0) }}</h3>
                            <p>Total Revenue</p>
                            <small>Avg: ₹{{ number_format($stats['avg_conversion_value'] ?? 0, 0) }}</small>
                        </div>
                        <div class="icon">
                            <i class="fas fa-rupee-sign"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                <!-- Open Leads Card -->
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{ number_format($stats['open_leads']) }}</h3>
                            <p>Open Leads</p>
                            <small>{{ number_format($stats['fresh_leads']) }} Fresh</small>
                        </div>
                        <div class="icon">
                            <i class="fas fa-hourglass-half"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
            </div>

            <!-- Today's Performance Row -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-calendar-day"></i> Today's Performance</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-primary"><i class="fas fa-phone"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Today's Leads</span>
                                            <span class="info-box-number">{{ number_format($stats['today_leads']) }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-success"><i class="fas fa-check"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Today's Conversions</span>
                                            <span class="info-box-number">{{ number_format($stats['today_converted']) }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-warning"><i class="fas fa-rupee-sign"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Today's Revenue</span>
                                            <span class="info-box-number">₹{{ number_format($stats['today_revenue'], 0) }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-info"><i class="fas fa-percentage"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Today's Conversion Rate</span>
                                            <span class="info-box-number">{{ $stats['today_conversion_rate'] }}%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row mt-4">
                <!-- Daily Leads Trend Chart -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-chart-line"></i> Daily Leads Trend (Last 30 Days)</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="dailyLeadsChart" height="100"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Status Distribution Pie Chart -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-chart-pie"></i> Lead Status Distribution</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="statusPieChart" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Monthly Performance & Lead Sources Row -->
            <div class="row mt-4">
                <!-- Monthly Performance Bar Chart -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-chart-bar"></i> Monthly Performance ({{ date('Y') }})</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="monthlyPerformanceChart" height="100"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Top Lead Sources -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-source-fork"></i> Top Lead Sources</h3>
                        </div>
                        <div class="card-body p-0">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Source</th>
                                        <th>Leads</th>
                                        <th>Converted</th>
                                        <th>Revenue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($topSources as $source)
                                        <tr>
                                            <td>
                                                <span class="badge badge-primary">{{ ucfirst($source->lead_from ?? 'Unknown') }}</span>
                                            </td>
                                            <td>{{ number_format($source->total_leads) }}</td>
                                            <td>{{ number_format($source->converted_leads) }}</td>
                                            <td>₹{{ number_format($source->total_revenue, 0) }}</td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="4" class="text-center">No data available</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent High-Value Conversions -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-trophy"></i> Recent High-Value Conversions</h3>
                        </div>
                        <div class="card-body p-0">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Mobile</th>
                                        <th>Source</th>
                                        <th>Value</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($recentConversions as $conversion)
                                        <tr>
                                            <td>{{ $conversion->name ?? 'N/A' }}</td>
                                            <td>{{ $conversion->mobile_no ?? 'N/A' }}</td>
                                            <td>
                                                <span class="badge badge-info">{{ ucfirst($conversion->lead_from ?? 'Unknown') }}</span>
                                            </td>
                                            <td>
                                                <span class="text-success font-weight-bold">₹{{ number_format($conversion->price, 0) }}</span>
                                            </td>
                                            <td>{{ $conversion->created_at->format('d M Y, h:i A') }}</td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="5" class="text-center">No recent conversions</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('style')
<style>
    .small-box {
        border-radius: 10px;
        box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
        transition: all 0.3s ease;
    }
    
    .small-box:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,.2);
    }
    
    .info-box {
        border-radius: 8px;
        box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    }
    
    .card {
        border-radius: 10px;
        box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    }
    
    .chart-container {
        position: relative;
        height: 300px;
    }
</style>
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Daily Leads Trend Chart
    const dailyLeadsCtx = document.getElementById('dailyLeadsChart').getContext('2d');
    const dailyLeadsChart = new Chart(dailyLeadsCtx, {
        type: 'line',
        data: {
            labels: {!! json_encode(array_keys($dailyLeads)) !!},
            datasets: [{
                label: 'Daily Leads',
                data: {!! json_encode(array_values($dailyLeads)) !!},
                borderColor: 'rgb(54, 162, 235)',
                backgroundColor: 'rgba(54, 162, 235, 0.1)',
                tension: 0.4,
                fill: true
            }, {
                label: 'Daily Revenue (₹)',
                data: {!! json_encode(array_values($dailyRevenue)) !!},
                borderColor: 'rgb(255, 99, 132)',
                backgroundColor: 'rgba(255, 99, 132, 0.1)',
                tension: 0.4,
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    position: 'left',
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    grid: {
                        drawOnChartArea: false,
                    },
                }
            },
            plugins: {
                legend: {
                    display: true
                }
            }
        }
    });

    // Status Distribution Pie Chart
    const statusPieCtx = document.getElementById('statusPieChart').getContext('2d');
    const statusPieChart = new Chart(statusPieCtx, {
        type: 'doughnut',
        data: {
            labels: {!! json_encode(array_keys($statusDistribution)) !!},
            datasets: [{
                data: {!! json_encode(array_values($statusDistribution)) !!},
                backgroundColor: [
                    '#28a745', // Success - Converted
                    '#ffc107', // Warning - Open/Fresh
                    '#dc3545', // Danger - Lost
                    '#17a2b8', // Info - Follow Up
                    '#6c757d', // Secondary - Others
                    '#fd7e14'  // Orange - Additional
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    // Monthly Performance Bar Chart
    const monthlyPerformanceCtx = document.getElementById('monthlyPerformanceChart').getContext('2d');
    const monthlyPerformanceChart = new Chart(monthlyPerformanceCtx, {
        type: 'bar',
        data: {
            labels: {!! json_encode(array_keys($monthlyLeads)) !!},
            datasets: [{
                label: 'Monthly Leads',
                data: {!! json_encode(array_values($monthlyLeads)) !!},
                backgroundColor: 'rgba(54, 162, 235, 0.8)',
                borderColor: 'rgb(54, 162, 235)',
                borderWidth: 1
            }, {
                label: 'Monthly Revenue (₹)',
                data: {!! json_encode(array_values($monthlyRevenue)) !!},
                backgroundColor: 'rgba(255, 99, 132, 0.8)',
                borderColor: 'rgb(255, 99, 132)',
                borderWidth: 1,
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    position: 'left',
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    grid: {
                        drawOnChartArea: false,
                    },
                }
            },
            plugins: {
                legend: {
                    display: true
                }
            }
        }
    });
</script>
@endpush
