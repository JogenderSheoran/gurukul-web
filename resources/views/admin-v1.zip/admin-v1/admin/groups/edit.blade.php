@extends('admin-v1.layouts.header')
@section('title', $title)
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Group Info Card -->
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-edit mr-2"></i>
                                Edit Group - {{ $group->name }}
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.groups') }}" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Groups
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <form id="editGroupForm" method="POST" action="{{ route('admin-v1.groups.update', $group->id) }}">
                                @csrf
                                @method('PUT')
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <h5 class="mb-3">Group Details</h5>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="name">Group Name <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="name" name="name" 
                                                   value="{{ old('name', $group->name) }}" 
                                                   placeholder="Enter group name" required>
                                            @error('name')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="mobile">Mobile Number <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="mobile" name="mobile" 
                                                   value="{{ old('mobile', $group->mobile) }}" 
                                                   placeholder="Enter mobile number" required>
                                            @error('mobile')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="location">Location <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="location" name="location" 
                                                   value="{{ old('location', $group->location) }}" 
                                                   placeholder="Enter location address" required>
                                            @error('location')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <h5 class="mb-3 mt-4">GPS Coordinates (Optional)</h5>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="latitude">Latitude</label>
                                            <input type="number" step="any" class="form-control" id="latitude" name="latitude" 
                                                   value="{{ old('latitude', $group->latitude) }}" 
                                                   placeholder="Enter latitude">
                                            @error('latitude')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="longitude">Longitude</label>
                                            <input type="number" step="any" class="form-control" id="longitude" name="longitude" 
                                                   value="{{ old('longitude', $group->longitude) }}" 
                                                   placeholder="Enter longitude">
                                            @error('longitude')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                @if($group->latitude && $group->longitude)
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="alert alert-success">
                                            <i class="fas fa-map-marker-alt mr-2"></i>
                                            Current Location: {{ number_format($group->latitude, 6) }}, {{ number_format($group->longitude, 6) }}
                                            <a href="https://maps.google.com/?q={{ $group->latitude }},{{ $group->longitude }}" 
                                               target="_blank" class="btn btn-sm btn-outline-success ml-2">
                                                <i class="fas fa-external-link-alt"></i> View on Google Maps
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                @endif

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary" id="submitBtn">
                                                <i class="fas fa-save mr-1"></i> Update Group
                                            </button>
                                            <a href="{{ route('admin-v1.groups') }}" class="btn btn-secondary ml-2">
                                                <i class="fas fa-times mr-1"></i> Cancel
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Group Statistics Sidebar -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-info-circle mr-2"></i>
                                Group Information
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-info"><i class="fas fa-hashtag"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Group ID</span>
                                    <span class="info-box-number">#{{ $group->id }}</span>
                                </div>
                            </div>

                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-success"><i class="fas fa-users"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Drivers Count</span>
                                    <span class="info-box-number">{{ $driversCount }}</span>
                                </div>
                            </div>

                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-warning"><i class="fas fa-calendar"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Created Date</span>
                                    <span class="info-box-number text-sm">{{ $group->created_at->format('M d, Y') }}</span>
                                </div>
                            </div>

                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-danger"><i class="fas fa-clock"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Last Updated</span>
                                    <span class="info-box-number text-sm">{{ $group->updated_at->format('M d, Y') }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection

@push('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        $(document).ready(function() {
            // Handle form submission
            $('#editGroupForm').on('submit', function(e) {
                e.preventDefault();
                
                // Show loading state
                $('#submitBtn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin mr-1"></i> Updating...');

                // Submit via AJAX
                $.ajax({
                    url: $(this).attr('action'),
                    type: 'POST',
                    data: $(this).serialize(),
                    success: function(response) {
                        // Hide loading state
                        $('#submitBtn').prop('disabled', false).html('<i class="fas fa-save mr-1"></i> Update Group');

                        if (response.success) {
                            Swal.fire({
                                title: 'Success!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href = response.redirect;
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: response.message,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    },
                    error: function(xhr) {
                        // Hide loading state
                        $('#submitBtn').prop('disabled', false).html('<i class="fas fa-save mr-1"></i> Update Group');

                        let message = 'An error occurred while updating the group.';
                        
                        if (xhr.status === 422) {
                            // Validation errors
                            const errors = xhr.responseJSON.errors;
                            
                            // Clear previous error messages
                            $('.text-danger').remove();
                            
                            // Display validation errors
                            $.each(errors, function(field, messages) {
                                const input = $('[name="' + field + '"]');
                                const errorSpan = $('<span class="text-danger">' + messages[0] + '</span>');
                                input.after(errorSpan);
                            });
                            
                            message = 'Please fix the validation errors.';
                        } else if (xhr.responseJSON && xhr.responseJSON.message) {
                            message = xhr.responseJSON.message;
                        }

                        Swal.fire({
                            title: 'Error!',
                            text: message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            });

            // Input validation - clear errors on input
            $('input').on('input', function() {
                $(this).next('.text-danger').remove();
            });

            // Mobile number formatting
            $('input[name="mobile"]').on('input', function() {
                // Allow only numbers and basic formatting
                this.value = this.value.replace(/[^0-9+\-\s()]/g, '');
            });
        });
    </script>
@endpush
