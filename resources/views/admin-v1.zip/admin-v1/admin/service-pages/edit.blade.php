@extends('admin.layouts.main')
@section('content')
<!--begin::Content wrapper-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Toolbar-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <div id="kt_content_container" class="container-xxl">
            <div class="card mb-5 mb-xl-10">
                <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse" data-bs-target="#kt_account_profile_details" aria-expanded="true" aria-controls="kt_account_profile_details">
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">Add Service</h3>
                    </div>
                </div>
                <div id="kt_account_profile_details" class="collapse show">
                <form action="{{ route('service-pages.update', $servicePage->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <div class="card-body border-top p-9">

        <!-- Title -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label required fw-bold fs-6">Title</label>
            <div class="col-lg-8">
                <input type="text" name="title" class="form-control form-control-lg form-control-solid"
                       placeholder="Enter title" value="{{ $servicePage->title ?? '' }}" required />
            </div>
        </div>

        <!-- Location -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label required fw-bold fs-6">Select Location</label>
            <div class="col-lg-8">
                <select name="location_id" class="form-control form-control-lg form-control-solid" required>
                    <option value="">-- Select Location --</option>
                    @foreach($locations as $location)
                        <option value="{{ $location->unique_id }}" {{ $servicePage->location_id == $location->unique_id ? 'selected' : '' }}>
                            {{ $location->city_name }}
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <!-- Service -->
        <div class="row mb-6">
            <label class="col-lg-4 col-form-label required fw-bold fs-6">Select Service</label>
            <div class="col-lg-8">
                <select name="service_id" class="form-control form-control-lg form-control-solid" required>
                    <option value="">-- Select Service --</option>
                    @foreach($services as $service)
                        <option value="{{ $service->unique_id }}" {{ $servicePage->service_id == $service->unique_id ? 'selected' : '' }}>
                            {{ $service->title }}
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <!-- Dynamic Content Fields -->
        @foreach($contents as $index => $content)
            @php
                $key = strtolower($content->key);
                $isImageKey = Str::contains($key, ['image', 'logo', 'banner']);
                $isHtmlValue = Str::contains($content->value ?? '', '<') && Str::contains($content->value, '>');
                $textareaId = 'editor_' . $index;
            @endphp

            <div class="row mb-6">
                <label class="col-lg-4 col-form-label fw-bold fs-6 text-capitalize">{{ str_replace('_', ' ', $content->key) }}</label>
                <div class="col-lg-8">
                    @if($isImageKey)
                        {{-- Show current image --}}
                        @php
                            $imagePath = $content->value;

                            // Agar path me "storage/" missing hai, to jodo
                            if (!Str::startsWith($imagePath, 'storage/')) {
                                $imagePath = 'storage/' . ltrim($imagePath, '/');
                            }
                        @endphp

                        @if(!empty($content->value))
                            <div class="mb-2">
                                <img src="{{ asset($imagePath) }}" alt="{{ $content->key }}" style="max-height: 100px;">
                            </div>
                        @endif

                        <input type="file" name="content[{{ $content->key }}]" class="form-control" accept="image/*">
                    @elseif($isHtmlValue)
                        <textarea id="{{ $textareaId }}" name="content[{{ $content->key }}]"
                                  class="form-control ckeditor" rows="5">{{ $content->value }}</textarea>
                    @else
                        <input type="text" name="content[{{ $content->key }}]" class="form-control"
                               value="{{ $content->value }}">
                    @endif

                    <!-- Hidden mapping for update -->
                    <input type="hidden" name="content_keys[]" value="{{ $content->key }}">
                    <input type="hidden" name="content_ids[{{ $content->key }}]" value="{{ $content->id }}">
                </div>
            </div>
        @endforeach

        <!-- Submit Button -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card-footer d-flex justify-content-end py-6 px-9">
                    <button type="submit" class="btn btn-primary">Update Service Page</button>
                </div>
            </div>
        </div>

    </div>
</form>

<!-- CKEditor script -->
<script src="https://cdn.ckeditor.com/4.25.1-lts/standard/ckeditor.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll('textarea.ckeditor').forEach(function (textarea) {
            CKEDITOR.replace(textarea.id);
        });
    });
</script>

                </div>
                <!--end::Content-->
            </div>
            <!--end::Basic info-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
</div>
<!--end::Content wrapper-->

<script>
    var i = 1;

    function addField() {
        html = '<div class="row" id="field' + i + '"><div class="col-lg-4"><input type="file" class="md-input" name="card_img[]" style="margin-top:20px;"></div><div class="col-lg-4"><label>Link</label><input type="text" class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" name="link[]"></div><div class="col-lg-4"><label>Description</label><input type="text" class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" name="description[]"></div><div class="col-lg-4"><i class="fa fa-minus best_remove_button" id="remove-field' + i + '" onclick="removeField(' + i + ')"></i></div></div>';

        $("#input-fields").append(html);
        i++;
    }

    function removeField(count) {
        $("#field" + count).remove();
    }
</script>
<script>
    document.getElementById("keyField").addEventListener("input", function () {
        const key = this.value.toLowerCase();
        const container = document.getElementById("valueInputContainer");

        if (key.includes("image") || key.includes("logo") || key.includes("banner") || key.includes("hero_image") || key.includes("background_image")) {
            container.innerHTML = `<input type="file" name="value" class="form-control" accept="image/*" required>`;
        } else if (key.includes("description") || key.includes("text") || key.includes("html")) {
            container.innerHTML = `<textarea name="value" class="form-control form-control-lg form-control-solid" rows="5" placeholder="Enter content..." required></textarea>`;
        } else {
            container.innerHTML = `<input type="text" name="value" class="form-control form-control-lg form-control-solid" placeholder="Enter value..." required>`;
        }
    });
</script>
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

@section('js')

<script>
    function setloader() {
        $('.indicator-label').hide();
        $('.indicator-progress').show();
    }

    $(document).ready(function() {

        var checkedValue = $("input[name='type']:checked").val();

        if (checkedValue == 'link') {
            $('#my_link').prop('required', true);
        } else if (checkedValue == 'course') {
            $('#my_course').prop('required', true);
        } else if (checkedValue == 'video') {
            $('#my_video').prop('required', true);
        } else if (checkedValue == 'pdf') {
            $('#my_pdf').prop('required', true);
        } else if (radioValue == 'category') {
            $('#my_category').prop('required', true);
        } else if (radioValue == 'deal') {
            $('#my_deal').prop('required', true);
        }

    });
</script>
<script src="https://cdn.ckeditor.com/4.21.0/standard/ckeditor.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll('.ckeditor').forEach(function (textarea) {
            CKEDITOR.replace(textarea);
        });
    });
</script>


@endsection