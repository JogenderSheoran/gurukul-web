@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Driver Transactions Card -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-money-bill mr-2"></i>
                                Driver Transactions - {{ $driver->first_name }} {{ $driver->last_name }}
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.drivers') }}" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Drivers
                                </a>
                                <a href="{{ route('admin-v1.drivers.show', $driver->id) }}" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> View Details
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="alert alert-warning">
                                <i class="fas fa-money-bill mr-2"></i>
                                Driver financial transactions will be displayed here. This will include earnings, payments, commissions, deductions, and complete financial history with detailed breakdowns.
                            </div>
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <h5>Driver Information:</h5>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="info-box">
                                                <span class="info-box-icon bg-info"><i class="fas fa-user"></i></span>
                                                <div class="info-box-content">
                                                    <span class="info-box-text">Driver</span>
                                                    <span class="info-box-number">{{ $driver->first_name }} {{ $driver->last_name }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="info-box">
                                                <span class="info-box-icon bg-success"><i class="fas fa-rupee-sign"></i></span>
                                                <div class="info-box-content">
                                                    <span class="info-box-text">Total Earnings</span>
                                                    <span class="info-box-number">₹0.00</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="info-box">
                                                <span class="info-box-icon bg-warning"><i class="fas fa-credit-card"></i></span>
                                                <div class="info-box-content">
                                                    <span class="info-box-text">Pending Amount</span>
                                                    <span class="info-box-number">₹0.00</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="info-box">
                                                <span class="info-box-icon bg-danger"><i class="fas fa-calendar"></i></span>
                                                <div class="info-box-content">
                                                    <span class="info-box-text">Member Since</span>
                                                    <span class="info-box-number">{{ $driver->created_at->format('M Y') }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection
