@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Edit Attendance Card -->
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-edit mr-2"></i>
                                Edit Attendance Record
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.drivers.attendance', $driver->id) }}" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Attendance
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <form id="editAttendanceForm" method="POST" action="{{ route('admin-v1.drivers.attendance.update', [$driver->id, $attendance->id]) }}">
                                @csrf
                                @method('PUT')
                                
                                <div class="row">
                                    <!-- Check-In Information -->
                                    <div class="col-md-6">
                                        <h5 class="text-primary mb-3">
                                            <i class="fas fa-sign-in-alt mr-2"></i>Check-In Information
                                        </h5>
                                        
                                        <div class="form-group">
                                            <label for="check_in_date">Check-In Date <span class="text-danger">*</span></label>
                                            <input type="date" class="form-control" id="check_in_date" name="check_in_date" 
                                                   value="{{ $attendance->check_in_date }}" required>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="check_in_time">Check-In Time <span class="text-danger">*</span></label>
                                            <input type="time" class="form-control" id="check_in_time" name="check_in_time" 
                                                   value="{{ $attendance->check_in_time }}" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="checkout_latitude">Checkout Latitude</label>
                                            <input type="text" class="form-control" id="checkout_latitude" name="checkout_latitude" 
                                                   value="{{ $attendance->checkout_latitude }}">
                                        </div>
                                    </div>
                                    
                                    <!-- Check-Out Information -->
                                    <div class="col-md-6">
                                        <h5 class="text-success mb-3">
                                            <i class="fas fa-sign-out-alt mr-2"></i>Check-Out Information
                                        </h5>
                                        
                                        <div class="form-group">
                                            <label for="check_out_date">Check-Out Date</label>
                                            <input type="date" class="form-control" id="check_out_date" name="check_out_date" 
                                                   value="{{ $attendance->check_out_date }}">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="check_out_time">Check-Out Time</label>
                                            <input type="time" class="form-control" id="check_out_time" name="check_out_time" 
                                                   value="{{ $attendance->check_out_time }}">
                                        </div>
                                        <div class="form-group">
                                            <label for="checkout_longitude">Checkout Longitude</label>
                                            <input type="text" class="form-control" id="checkout_longitude" name="checkout_longitude" 
                                                   value="{{ $attendance->checkout_longitude }}">
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Total Hours Display -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="alert alert-info" id="totalHoursDisplay" style="display: none;">
                                            <i class="fas fa-clock mr-2"></i>
                                            <strong>Total Working Hours: </strong>
                                            <span id="totalHoursText">0 hours 0 minutes</span>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                <!-- Submit Button -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary" id="submitBtn">
                                            <i class="fas fa-save mr-2"></i>Update Attendance
                                        </button>
                                        <a href="{{ route('admin-v1.drivers.attendance', $driver->id) }}" class="btn btn-secondary">
                                            <i class="fas fa-times mr-2"></i>Cancel
                                        </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Driver Information Sidebar -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-user mr-2"></i>Driver Information
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="text-center mb-3">
                                <div class="user-avatar bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center" 
                                     style="width: 80px; height: 80px; font-size: 2rem;">
                                    {{ strtoupper(substr($driver->first_name, 0, 1)) }}{{ strtoupper(substr($driver->last_name, 0, 1)) }}
                                </div>
                                <h5 class="mt-2 mb-0">{{ $driver->first_name }} {{ $driver->last_name }}</h5>
                                <small class="text-muted">Driver ID: #{{ $driver->id }}</small>
                            </div>
                            
                            <div class="info-list">
                                <div class="info-item d-flex justify-content-between mb-2">
                                    <span><i class="fas fa-phone text-primary mr-2"></i>Mobile:</span>
                                    <span>{{ $driver->mobile }}</span>
                                </div>
                                <div class="info-item d-flex justify-content-between mb-2">
                                    <span><i class="fas fa-map-marker-alt text-danger mr-2"></i>City:</span>
                                    <span>{{ $driver->city ?? 'N/A' }}</span>
                                </div>
                                <div class="info-item d-flex justify-content-between mb-2">
                                    <span><i class="fas fa-calendar text-success mr-2"></i>Joined:</span>
                                    <span>{{ $driver->created_at->format('M Y') }}</span>
                                </div>
                                <div class="info-item d-flex justify-content-between mb-2">
                                    <span><i class="fas fa-circle text-{{ $driver->status == 0 ? 'success' : 'danger' }} mr-2"></i>Status:</span>
                                    <span class="badge badge-{{ $driver->status == 0 ? 'success' : 'danger' }}">
                                        {{ $driver->status == 0 ? 'Active' : 'Blocked' }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Attendance Record Details -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-info-circle mr-2"></i>Record Details
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="info-list">
                                <div class="info-item d-flex justify-content-between mb-2">
                                    <span><i class="fas fa-hashtag text-primary mr-2"></i>Record ID:</span>
                                    <span>#{{ $attendance->id }}</span>
                                </div>
                                <div class="info-item d-flex justify-content-between mb-2">
                                    <span><i class="fas fa-building text-info mr-2"></i>Plant:</span>
                                    <span>{{ $attendance->plant_name ?? 'N/A' }}</span>
                                </div>
                                <div class="info-item d-flex justify-content-between mb-2">
                                    <span><i class="fas fa-clock text-warning mr-2"></i>Shift:</span>
                                    <span>{{ ucfirst($attendance->shift_type ?? 'N/A') }}</span>
                                </div>
                                <div class="info-item d-flex justify-content-between mb-2">
                                    <span><i class="fas fa-calendar-plus text-success mr-2"></i>Created:</span>
                                    <span>{{ $attendance->created_at->format('d M Y') }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection

@push('scripts')
<script>
$(document).ready(function() {
    // Calculate total hours when times change
    function calculateTotalHours() {
        const checkInDate = $('#check_in_date').val();
        const checkInTime = $('#check_in_time').val();
        const checkOutDate = $('#check_out_date').val();
        const checkOutTime = $('#check_out_time').val();
        
        if (checkInDate && checkInTime && checkOutDate && checkOutTime) {
            const checkIn = new Date(checkInDate + ' ' + checkInTime);
            const checkOut = new Date(checkOutDate + ' ' + checkOutTime);
            
            if (checkOut > checkIn) {
                const diffMs = checkOut - checkIn;
                const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
                const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                
                $('#totalHoursText').text(diffHours + ' hours ' + diffMinutes + ' minutes');
                $('#totalHoursDisplay').show();
            } else {
                $('#totalHoursDisplay').hide();
            }
        } else {
            $('#totalHoursDisplay').hide();
        }
    }
    
    // Bind events to calculate hours
    $('#check_in_date, #check_in_time, #check_out_date, #check_out_time').on('change', calculateTotalHours);
    
    // Calculate on page load
    calculateTotalHours();
    
    // Form submission
    $('#editAttendanceForm').on('submit', function(e) {
        e.preventDefault();
        
        const submitBtn = $('#submitBtn');
        const originalText = submitBtn.html();
        
        // Show loading state
        submitBtn.html('<i class="fas fa-spinner fa-spin mr-2"></i>Updating...').prop('disabled', true);
        
        $.ajax({
            url: $(this).attr('action'),
            method: 'PUT',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        title: 'Success!',
                        text: response.message,
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.href = "{{ route('admin-v1.drivers.attendance', $driver->id) }}";
                    });
                }
            },
            error: function(xhr) {
                let errorMessage = 'An error occurred while updating attendance.';
                
                if (xhr.responseJSON && xhr.responseJSON.errors) {
                    const errors = xhr.responseJSON.errors;
                    errorMessage = Object.values(errors).flat().join('\n');
                }
                
                Swal.fire({
                    title: 'Error!',
                    text: errorMessage,
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            },
            complete: function() {
                // Restore button state
                submitBtn.html(originalText).prop('disabled', false);
            }
        });
    });
});
</script>

<style>
.user-avatar {
    font-weight: bold;
}

.info-list .info-item {
    padding: 0.5rem 0;
    border-bottom: 1px solid #f0f0f0;
}

.info-list .info-item:last-child {
    border-bottom: none;
}

.card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #dee2e6;
}

.form-group label {
    font-weight: 600;
    color: #495057;
}

.alert-info {
    background-color: #e3f2fd;
    border-color: #2196f3;
    color: #1976d2;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .col-md-8, .col-md-4 {
        margin-bottom: 1rem;
    }
    
    .user-avatar {
        width: 60px !important;
        height: 60px !important;
        font-size: 1.5rem !important;
    }
}
</style>
@endpush
