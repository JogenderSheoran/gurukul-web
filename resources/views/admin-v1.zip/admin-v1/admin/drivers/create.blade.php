@extends('admin-v1.layouts.header')

@push('style')
<style>
.select2-container .select2-selection--single {
    height: calc(2.25rem + 2px) !important;
    padding: 0.375rem 0.75rem;
    border: 1px solid #ced4da;
}

.select2-container .select2-selection--multiple {
    min-height: calc(2.25rem + 2px) !important;
    border: 1px solid #ced4da;
}

.section-header {
    background: #f8f9fa;
    color: #495057;
    padding: 0.5rem 1rem;
    border-radius: 0.25rem;
    margin-bottom: 1rem;
    font-weight: 500;
    text-align: left;
    border-left: 4px solid #007bff;
    font-size: 1.1rem;
}
</style>
@endpush

@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Driver Create Card -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-plus mr-2"></i>
                                Add New Driver
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.drivers') }}" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Drivers
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <form id="createDriverForm" method="POST" action="{{ route('admin-v1.drivers.store') }}" enctype="multipart/form-data">
                                @csrf
                                
                                <!-- Personal Information -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="section-header">
                                            <i class="fas fa-user mr-2"></i>Personal Information
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="first_name">First Name <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="first_name" name="first_name" 
                                                   value="{{ old('first_name') }}" 
                                                   placeholder="Enter first name" required>
                                            @error('first_name')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="last_name">Last Name <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="last_name" name="last_name" 
                                                   value="{{ old('last_name') }}" 
                                                   placeholder="Enter last name" required>
                                            @error('last_name')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="mobile_number">Mobile Number <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="mobile_number" name="mobile_number" 
                                                   value="{{ old('mobile_number') }}" 
                                                   placeholder="Enter mobile number" required>
                                            @error('mobile_number')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="pin">PIN <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="pin" name="pin" 
                                                   value="{{ old('pin') }}" 
                                                   placeholder="Enter 4-6 digit PIN" required>
                                            @error('pin')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <!-- Location Information -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="section-header">
                                            <i class="fas fa-map-marker-alt mr-2"></i>Location Information
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="state">State <span class="text-danger">*</span></label>
                                            <select class="form-control select2" id="state" name="state" required>
                                                <option value="">Select State</option>
                                                <option value="Andhra Pradesh">Andhra Pradesh</option>
                                                <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                                <option value="Assam">Assam</option>
                                                <option value="Bihar">Bihar</option>
                                                <option value="Chhattisgarh">Chhattisgarh</option>
                                                <option value="Goa">Goa</option>
                                                <option value="Gujarat">Gujarat</option>
                                                <option value="Haryana">Haryana</option>
                                                <option value="Himachal Pradesh">Himachal Pradesh</option>
                                                <option value="Jharkhand">Jharkhand</option>
                                                <option value="Karnataka">Karnataka</option>
                                                <option value="Kerala">Kerala</option>
                                                <option value="Madhya Pradesh">Madhya Pradesh</option>
                                                <option value="Maharashtra">Maharashtra</option>
                                                <option value="Manipur">Manipur</option>
                                                <option value="Meghalaya">Meghalaya</option>
                                                <option value="Mizoram">Mizoram</option>
                                                <option value="Nagaland">Nagaland</option>
                                                <option value="Odisha">Odisha</option>
                                                <option value="Punjab">Punjab</option>
                                                <option value="Rajasthan">Rajasthan</option>
                                                <option value="Sikkim">Sikkim</option>
                                                <option value="Tamil Nadu">Tamil Nadu</option>
                                                <option value="Telangana">Telangana</option>
                                                <option value="Tripura">Tripura</option>
                                                <option value="Uttar Pradesh">Uttar Pradesh</option>
                                                <option value="Uttarakhand">Uttarakhand</option>
                                                <option value="West Bengal">West Bengal</option>
                                                <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                                <option value="Chandigarh">Chandigarh</option>
                                                <option value="Dadra and Nagar Haveli and Daman and Diu">Dadra and Nagar Haveli and Daman and Diu</option>
                                                <option value="Delhi">Delhi</option>
                                                <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                                <option value="Ladakh">Ladakh</option>
                                                <option value="Lakshadweep">Lakshadweep</option>
                                                <option value="Puducherry">Puducherry</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="city">City <span class="text-danger">*</span></label>
                                            <select class="form-control select2" id="city" name="city" required>
                                                <option value="">Select City</option>
                                                @foreach($cities as $city)
                                                    <option value="{{ $city->id }}" {{ old('city') == $city->id ? 'selected' : '' }}>
                                                        {{ $city->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('city')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="employee_id">Employee ID</label>
                                            <input type="text" class="form-control" id="employee_id" name="employee_id" 
                                                   value="{{ old('employee_id') }}" 
                                                   placeholder="Enter employee ID">
                                            <small class="form-text text-muted">Optional field</small>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="plant_code">Plant Code</label>
                                            <input type="text" class="form-control" id="plant_code" name="plant_code" 
                                                   value="{{ old('plant_code') }}" 
                                                   placeholder="Enter plant code">
                                            <small class="form-text text-muted">Optional field</small>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="serving_area">Serving Area</label>
                                            <textarea class="form-control" id="serving_area" name="serving_area" 
                                                      rows="3" placeholder="Enter serving area">{{ old('serving_area') }}</textarea>
                                        </div>
                                    </div>
                                </div>

                                <!-- Driver Configuration -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="section-header">
                                            <i class="fas fa-cogs mr-2"></i>Driver Configuration
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="type">Driver Type <span class="text-danger">*</span></label>
                                            <select class="form-control select2" id="type" name="type" required>
                                                <option value="">Select Type</option>
                                                <option value="individual" {{ old('type') == 'individual' ? 'selected' : '' }}>Individual</option>
                                                <option value="group" {{ old('type') == 'group' ? 'selected' : '' }}>Group</option>
                                            </select>
                                            @error('type')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="site_type">Site Type <span class="text-danger">*</span></label>
                                            <select class="form-control select2" id="site_type" name="site_type" required>
                                                <option value="">Select Site Type</option>
                                                <option value="1" {{ old('site_type') == '1' ? 'selected' : '' }}>On Site</option>
                                                <option value="2" {{ old('site_type') == '2' ? 'selected' : '' }}>Off Site</option>
                                                <option value="3" {{ old('site_type') == '3' ? 'selected' : '' }}>On-Site Callers</option>
                                            </select>
                                            @error('site_type')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="shift_time">Shift Time <span class="text-danger">*</span></label>
                                            <select class="form-control select2" id="shift_time" name="shift_time" required>
                                                <option value="">Select Shift Time</option>
                                                <option value="8 Hour" {{ old('shift_time') == '8 Hour' ? 'selected' : '' }}>8 Hour</option>
                                                <option value="12 Hours" {{ old('shift_time') == '12 Hours' ? 'selected' : '' }}>12 Hours</option>
                                                <option value="No Restrictions" {{ old('shift_time') == 'No Restrictions' ? 'selected' : '' }}>No Restrictions</option>
                                            </select>
                                            @error('shift_time')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row" id="group_selection" style="display: none;">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="group_id">Select Group</label>
                                            <select class="form-control select2" id="group_id" name="group_id">
                                                <option value="">Select Group</option>
                                                @foreach($groups as $group)
                                                    <option value="{{ $group->id }}" {{ old('group_id') == $group->id ? 'selected' : '' }}>
                                                        {{ $group->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="priority">Priority</label>
                                            <input type="number" class="form-control" id="priority" name="priority" 
                                                   value="{{ old('priority', 1) }}" min="1" max="10">
                                        </div>
                                    </div>
                                </div>

                                <!-- Vehicle Information -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="section-header">
                                            <i class="fas fa-car mr-2"></i>Vehicle Information
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="vehicle_category_id">Vehicle Categories <span class="text-danger">*</span></label>
                                            <select class="form-control select2-multi" id="vehicle_category_id" name="vehicle_category_id[]" multiple required>
                                                @foreach($vehicleCategories as $category)
                                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                                @endforeach
                                            </select>
                                            @error('vehicle_category_id')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="vehicle_type">Vehicle Types <span class="text-danger">*</span></label>
                                            <select class="form-control select2-multi" id="vehicle_type" name="vehicle_type[]" multiple required>
                                                <option value="Echo" {{ is_array(old('vehicle_type')) && in_array('Echo', old('vehicle_type')) ? 'selected' : '' }}>Echo</option>
                                                <option value="Bolero" {{ is_array(old('vehicle_type')) && in_array('Bolero', old('vehicle_type')) ? 'selected' : '' }}>Bolero</option>
                                                <option value="Tempo" {{ is_array(old('vehicle_type')) && in_array('Tempo', old('vehicle_type')) ? 'selected' : '' }}>Tempo</option>
                                            </select>
                                            @error('vehicle_type')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="images">Vehicle Images</label>
                                            <input type="file" class="form-control-file" id="images" name="images[]" multiple accept="image/*">
                                            <small class="form-text text-muted">You can select multiple images for the vehicle.</small>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary" id="submitBtn">
                                                <i class="fas fa-save mr-1"></i> Create Driver
                                            </button>
                                            <a href="{{ route('admin-v1.drivers') }}" class="btn btn-secondary ml-2">
                                                <i class="fas fa-times mr-1"></i> Cancel
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection


@push('scripts')
    <script>
        $(document).ready(function() {
            // Initialize Select2 for single select elements
            $('.select2').select2({
                width: '100%',
                placeholder: 'Select an option...',
                allowClear: true
            });

            // Initialize Select2 for multi-select elements
            $('.select2-multi').select2({
                width: '100%',
                placeholder: 'Select options...',
                allowClear: true,
                closeOnSelect: false
            });

            // Show/hide group selection based on driver type
            $('#type').on('change', function() {
                if ($(this).val() === 'group') {
                    $('#group_selection').show();
                } else {
                    $('#group_selection').hide();
                    $('#group_id').val('').trigger('change');
                }
            });

            // Handle form submission
            $('#createDriverForm').on('submit', function(e) {
                e.preventDefault();
                
                // Show loading state
                $('#submitBtn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin mr-1"></i> Creating...');

                // Create FormData object for file upload
                var formData = new FormData(this);

                // Submit via AJAX
                $.ajax({
                    url: $(this).attr('action'),
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        // Hide loading state
                        $('#submitBtn').prop('disabled', false).html('<i class="fas fa-save mr-1"></i> Create Driver');

                        if (response.success) {
                            Swal.fire({
                                title: 'Success!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href = response.redirect;
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: response.message,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    },
                    error: function(xhr) {
                        // Hide loading state
                        $('#submitBtn').prop('disabled', false).html('<i class="fas fa-save mr-1"></i> Create Driver');

                        let message = 'An error occurred while creating the driver.';
                        
                        if (xhr.status === 422) {
                            // Validation errors
                            const errors = xhr.responseJSON.errors;
                            
                            // Clear previous error messages
                            $('.text-danger').remove();
                            
                            // Display validation errors
                            $.each(errors, function(field, messages) {
                                const input = $('[name="' + field + '"]');
                                const errorSpan = $('<span class="text-danger">' + messages[0] + '</span>');
                                input.after(errorSpan);
                            });
                            
                            message = 'Please fix the validation errors.';
                        } else if (xhr.responseJSON && xhr.responseJSON.message) {
                            message = xhr.responseJSON.message;
                        }

                        Swal.fire({
                            title: 'Error!',
                            text: message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            });

            // Input validation - clear errors on input
            $('input, select').on('input change', function() {
                $(this).next('.text-danger').remove();
            });

            // Mobile number formatting
            $('input[name="mobile_number"]').on('input', function() {
                // Allow only numbers and basic formatting
                this.value = this.value.replace(/[^0-9+\-\s()]/g, '');
            });

            // PIN validation
            $('input[name="pin"]').on('input', function() {
                // Allow only numbers
                this.value = this.value.replace(/[^0-9]/g, '');
            });
        });
    </script>
@endpush
