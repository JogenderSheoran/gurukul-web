@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Page Header -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map-marker-alt text-primary mr-2"></i>
                                Driver Check-In/Out Locations - {{ $location['name'] }}
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.drivers') }}" class="btn btn-secondary btn-sm">
                                    <i class="fas fa-arrow-left mr-1"></i> Back to Drivers
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Driver Info Cards -->
            <div class="row mb-4">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{ $location['name'] }}</h3>
                            <p>Driver Name</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-user"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>{{ $location['checkin_time'] }}</h3>
                            <p>Check-In Time</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-sign-in-alt"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3>{{ $location['checkout_time'] ?? 'Not Yet' }}</h3>
                            <p>Check-Out Time</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-sign-out-alt"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-secondary">
                        <div class="inner">
                            <h3>{{ $location['last_updated'] }}</h3>
                            <p>Last Updated</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Map Container -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map text-primary mr-2"></i>
                                Check-In & Check-Out Locations
                            </h3>
                            <div class="card-tools">
                                <span class="badge badge-success mr-2">
                                    <i class="fas fa-circle text-success mr-1"></i>
                                    Check-In
                                </span>
                                @if($location['checkout_latitude'] && $location['checkout_longitude'])
                                <span class="badge badge-danger">
                                    <i class="fas fa-circle text-danger mr-1"></i>
                                    Check-Out
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div id="map" style="height: 600px; width: 100%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Location Details -->
            <div class="row mt-4">
                <div class="col-lg-6 col-12">
                    <div class="card">
                        <div class="card-header bg-success">
                            <h3 class="card-title text-white">
                                <i class="fas fa-sign-in-alt mr-2"></i>
                                Check-In Details
                            </h3>
                        </div>
                        <div class="card-body">
                            <p><strong>Date:</strong> {{ $location['checkin_date'] }}</p>
                            <p><strong>Time:</strong> {{ $location['checkin_time'] }}</p>
                            <p><strong>Coordinates:</strong> {{ $location['checkin_latitude'] }}, {{ $location['checkin_longitude'] }}</p>
                            <a href="https://www.google.com/maps?q={{ $location['checkin_latitude'] }},{{ $location['checkin_longitude'] }}" 
                               target="_blank" class="btn btn-success btn-block">
                                <i class="fas fa-map-marker-alt mr-2"></i> View on Google Maps
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="card">
                        <div class="card-header bg-danger">
                            <h3 class="card-title text-white">
                                <i class="fas fa-sign-out-alt mr-2"></i>
                                Check-Out Details
                            </h3>
                        </div>
                        <div class="card-body">
                            @if($location['checkout_latitude'] && $location['checkout_longitude'])
                                <p><strong>Date:</strong> {{ $location['checkout_date'] ?? 'N/A' }}</p>
                                <p><strong>Time:</strong> {{ $location['checkout_time'] ?? 'N/A' }}</p>
                                <p><strong>Coordinates:</strong> {{ $location['checkout_latitude'] }}, {{ $location['checkout_longitude'] }}</p>
                                <a href="https://www.google.com/maps?q={{ $location['checkout_latitude'] }},{{ $location['checkout_longitude'] }}" 
                                   target="_blank" class="btn btn-danger btn-block">
                                    <i class="fas fa-map-marker-alt mr-2"></i> View on Google Maps
                                </a>
                            @else
                                <p class="text-muted text-center py-4">
                                    <i class="fas fa-info-circle fa-2x mb-2"></i><br>
                                    Driver has not checked out yet
                                </p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('styles')
<style>
    #map {
        border-radius: 0 0 0.375rem 0.375rem;
    }

    .small-box .inner h3 {
        font-size: 1.2rem;
        margin-bottom: 5px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>
@endpush

@push('scripts')
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC7bw_LEDJztaV68tYo-PbJfIdS_tBVyQ&libraries=maps,marker&v=beta&callback=initMap" async defer></script>
<script>
    let map;
    let checkinMarker;
    let checkoutMarker;

    function initMap() {
        // Check-In location (green marker)
        const checkinLocation = {
            lat: {{ $location['checkin_latitude'] }},
            lng: {{ $location['checkin_longitude'] }}
        };

        // Check-Out location (red marker) - may be null
        @if($location['checkout_latitude'] && $location['checkout_longitude'])
        const checkoutLocation = {
            lat: {{ $location['checkout_latitude'] }},
            lng: {{ $location['checkout_longitude'] }}
        };
        const hasCheckout = true;
        @else
        const hasCheckout = false;
        @endif

        // Create map
        map = new google.maps.Map(document.getElementById("map"), {
            zoom: 14,
            center: checkinLocation,
            mapTypeId: 'roadmap',
            disableDefaultUI: true,
            zoomControl: true,
            zoomControlOptions: {
                position: google.maps.ControlPosition.RIGHT_BOTTOM
            },
            styles: [
                {
                    "featureType": "all",
                    "elementType": "geometry",
                    "stylers": [{"color": "#f5f5f5"}]
                },
                {
                    "featureType": "road",
                    "elementType": "geometry",
                    "stylers": [{"color": "#ffffff"}]
                },
                {
                    "featureType": "road",
                    "elementType": "geometry.stroke",
                    "stylers": [{"color": "#e0e0e0"}]
                },
                {
                    "featureType": "water",
                    "elementType": "geometry",
                    "stylers": [{"color": "#c9d6e8"}]
                },
                {
                    "featureType": "landscape",
                    "elementType": "geometry",
                    "stylers": [{"color": "#f0f0f0"}]
                }
            ]
        });

        // Green marker icon for Check-In
        const checkinIcon = {
            path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
            fillColor: '#28a745',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
            scale: 2,
            anchor: new google.maps.Point(12, 24)
        };

        // Red marker icon for Check-Out
        const checkoutIcon = {
            path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
            fillColor: '#dc3545',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
            scale: 2,
            anchor: new google.maps.Point(12, 24)
        };

        // Add Check-In marker (green)
        checkinMarker = new google.maps.Marker({
            position: checkinLocation,
            map: map,
            title: 'Check-In Location',
            icon: checkinIcon,
            animation: google.maps.Animation.DROP
        });

        // Check-In info window
        const checkinInfoWindow = new google.maps.InfoWindow({
            content: `
                <div style="font-family: 'Inter', sans-serif; padding: 10px; max-width: 250px;">
                    <h6 style="margin: 0 0 8px 0; color: #28a745;"><i class="fas fa-sign-in-alt"></i> Check-In Location</h6>
                    <p style="margin: 0; color: #666; font-size: 14px;">
                        <strong>Driver:</strong> {{ addslashes($location['name']) }}<br>
                        <strong>Date:</strong> {{ $location['checkin_date'] }}<br>
                        <strong>Time:</strong> {{ $location['checkin_time'] }}<br>
                        <strong>Mobile:</strong> {{ $location['mobile'] }}
                    </p>
                </div>
            `
        });

        checkinMarker.addListener('click', () => {
            checkinInfoWindow.open(map, checkinMarker);
        });

        // Add Check-Out marker (red) if exists
        if (hasCheckout) {
            checkoutMarker = new google.maps.Marker({
                position: checkoutLocation,
                map: map,
                title: 'Check-Out Location',
                icon: checkoutIcon,
                animation: google.maps.Animation.DROP
            });

            // Check-Out info window
            const checkoutInfoWindow = new google.maps.InfoWindow({
                content: `
                    <div style="font-family: 'Inter', sans-serif; padding: 10px; max-width: 250px;">
                        <h6 style="margin: 0 0 8px 0; color: #dc3545;"><i class="fas fa-sign-out-alt"></i> Check-Out Location</h6>
                        <p style="margin: 0; color: #666; font-size: 14px;">
                            <strong>Driver:</strong> {{ addslashes($location['name']) }}<br>
                            <strong>Date:</strong> {{ $location['checkout_date'] ?? 'N/A' }}<br>
                            <strong>Time:</strong> {{ $location['checkout_time'] ?? 'N/A' }}<br>
                            <strong>Mobile:</strong> {{ $location['mobile'] }}
                        </p>
                    </div>
                `
            });

            checkoutMarker.addListener('click', () => {
                checkoutInfoWindow.open(map, checkoutMarker);
            });

            // Fit map bounds to show both markers
            const bounds = new google.maps.LatLngBounds();
            bounds.extend(checkinLocation);
            bounds.extend(checkoutLocation);
            map.fitBounds(bounds);
        }
    }

    // Handle window resize
    window.addEventListener('resize', function() {
        if (map) {
            google.maps.event.trigger(map, 'resize');
        }
    });
</script>
@endpush
