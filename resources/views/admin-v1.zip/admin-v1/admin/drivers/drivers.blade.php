@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Statistics Cards Row -->
            <div class="row">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3 id="totalDrivers">{{ $totalDrivers }}</h3>
                            <p>Total Drivers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3 id="activeDrivers">{{ $activeDrivers }}</h3>
                            <p>Active Drivers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-user-check"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3 id="blockedDrivers">{{ $blockedDrivers }}</h3>
                            <p>Blocked Drivers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-user-times"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3 id="todayDrivers">{{ $todayDrivers }}</h3>
                            <p>Today's Registrations</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-user-plus"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Additional Statistics Row -->
            <div class="row">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-primary">
                        <div class="inner">
                            <h3 id="onSiteDrivers">{{ $onSiteDrivers }}</h3>
                            <p>On Site Drivers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-secondary">
                        <div class="inner">
                            <h3 id="offSiteDrivers">{{ $offSiteDrivers }}</h3>
                            <p>Off Site Drivers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-home"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-dark">
                        <div class="inner">
                            <h3 id="onSiteCallersDrivers">{{ $onSiteCallersDrivers }}</h3>
                            <p>On-Site Callers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-phone"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-indigo">
                        <div class="inner">
                            <h3 id="groupDrivers">{{ $groupDrivers }}</h3>
                            <p>Group Drivers</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-layer-group"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Drivers Table -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-users mr-2"></i>
                                Drivers Management
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.drivers.create') }}" class="btn btn-primary btn-sm">
                                    <i class="fas fa-plus"></i> Add New Driver
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="drivers-table" class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Photo</th>
                                    <th>Personal Details</th>
                                    <th>City</th>
                                    <th>Vehicle Info</th>
                                    <th>Group</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Site</th>
                                    <th>Registered</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <!-- Data will be loaded via AJAX -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection

@push('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- page script -->
    <script>
        var table;
        $(function () {
            // Initialize DataTable
            table = $('#drivers-table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "{{ route('admin-v1.drivers.data') }}",
                    "type": "GET"
                },
                "columns": [
                    { "data": "DT_RowIndex", "name": "DT_RowIndex", "orderable": false, "searchable": false },
                    { "data": "profile_pic", "name": "profile_pic", "orderable": false, "searchable": false },
                    { "data": "personal_detail", "name": "personal_detail" },
                    { "data": "city_name", "name": "city_name" },
                    { "data": "vehicle_info", "name": "vehicle_info" },
                    { "data": "group_name", "name": "group_name" },
                    { "data": "type_badge", "name": "type_badge" },
                    { "data": "status_badge", "name": "status_badge" },
                    { "data": "site_badge", "name": "site_badge" },
                    { "data": "date_formatted", "name": "date_formatted" },
                    { "data": "action", "name": "action", "orderable": false, "searchable": false }
                ],
                "order": [[10, 'desc']],
                "pageLength": 25,
                "responsive": true,
                "autoWidth": false,
                "scrollX": true
            });
        });

        // Toggle driver status function
        function toggleStatus(id, currentStatus) {
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to change the status of this driver?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, change it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "{{ route('admin-v1.drivers.toggle-status') }}",
                        type: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}',
                            id: id
                        },
                        success: function (response) {
                            if (response.success) {
                                Swal.fire(
                                    'Updated!',
                                    'Driver status has been changed.',
                                    'success'
                                );
                                table.ajax.reload();
                            } else {
                                Swal.fire('Error', response.message || 'Could not update status', 'error');
                            }
                        },
                        error: function () {
                            Swal.fire('Error', 'AJAX request failed.', 'error');
                        }
                    });
                }
            });
        }


        // Show vehicle details in modal
        function showVehicleDetails(fullDetails) {
            Swal.fire({
                title: 'Complete Vehicle Information',
                html: '<div class="text-left">' + 
                      fullDetails.split(', ').map(function(item) {
                          return '<span class="badge badge-primary mr-1 mb-2" style="font-size: 0.9em; padding: 5px 10px;">' + item + '</span>';
                      }).join('') + '</div>',
                icon: 'info',
                confirmButtonText: 'Close',
                width: '600px',
                customClass: {
                    htmlContainer: 'text-left'
                }
            });
        }

        // Initialize tooltips
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
@endpush

@push('style')
<style>
    .swal-html-container {
        max-height: 300px;
        overflow-y: auto;
        border-radius: 10px;
        box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
        transition: all 0.3s ease;
    }
    
    .small-box:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,.2);
    }
    
    .card {
        border-radius: 10px;
        box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    }
    
    .badge {
        cursor: pointer;
        font-size: 0.875em;
        font-weight: bold !important;
        padding: 6px 12px !important;
    }
    
    /* Fix green badge visibility */
    .badge-success {
        background-color: #28a745 !important;
        color: white !important;
        border: 1px solid #1e7e34 !important;
    }
    
    .badge-success:hover {
        background-color: #218838 !important;
        color: white !important;
    }
    
    .table th {
        white-space: nowrap;
    }
    
    .btn-group .btn {
        margin-right: 2px;
    }
    
    /* DataTable column width control */
    #drivers-table th:nth-child(1) { width: 5%; }  /* # */
    #drivers-table th:nth-child(2) { width: 8%; }  /* Photo */
    #drivers-table th:nth-child(3) { width: 25%; } /* Personal Details */
    #drivers-table th:nth-child(4) { width: 12%; } /* City */
    #drivers-table th:nth-child(5) { width: 20%; } /* Vehicle Info */
    #drivers-table th:nth-child(6) { width: 10%; } /* Group */
    #drivers-table th:nth-child(7) { width: 8%; }  /* Type */
    #drivers-table th:nth-child(8) { width: 10%; } /* Status */
    #drivers-table th:nth-child(9) { width: 10%; } /* Site */
    #drivers-table th:nth-child(10) { width: 12%; } /* Registered */
    #drivers-table th:nth-child(11) { width: 18%; } /* Actions */
    
    /* Vehicle info badge styling */
    .badge-info {
        max-width: 120px !important;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        display: inline-block;
    }
    
    .vehicle-info-badge:hover {
        background-color: #17a2b8 !important;
        transform: scale(1.05);
        transition: all 0.2s ease;
    }
    
    /* SweetAlert custom styling */
    .swal2-html-container .badge {
        margin: 2px;
        font-size: 0.9em !important;
        padding: 6px 12px !important;
    }
</style>
@endpush
