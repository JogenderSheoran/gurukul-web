@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Calendar Header -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-calendar-alt mr-2"></i>
                                Attendance Calendar - {{ $driver->first_name }} {{ $driver->last_name }}
                            </h3>
                            <div class="card-tools">
                                <form method="GET" class="d-inline-flex align-items-center mr-3">
                                    <label for="month" class="mr-2 mb-0">Month:</label>
                                    <input type="month" name="month" id="month" class="form-control form-control-sm" 
                                           value="{{ $month }}" onchange="this.form.submit()">
                                </form>
                                <a href="{{ route('admin-v1.drivers.attendance.monthly-report', $driver->id) }}?month={{ $month }}" class="btn btn-sm btn-success">
                                    <i class="fas fa-chart-bar"></i> Monthly Report
                                </a>
                                <a href="{{ route('admin-v1.drivers.attendance', $driver->id) }}" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Attendance
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Legend -->
                            <div class="row mb-4">
                                <div class="col-md-12">
                                    <div class="alert alert-info">
                                        <h5><i class="fas fa-info-circle mr-2"></i>Color Legend</h5>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <span class="badge badge-success mr-2" style="width: 20px; height: 20px; border-radius: 50%;"></span>
                                                <strong>GREEN:</strong> Proper Check-In & Check-Out done
                                            </div>
                                            <div class="col-md-4">
                                                <span class="badge badge-warning mr-2" style="width: 20px; height: 20px; border-radius: 50%;"></span>
                                                <strong>YELLOW:</strong> Only Check-In done (Checkout Missing)
                                            </div>
                                            <div class="col-md-4">
                                                <span class="badge badge-danger mr-2" style="width: 20px; height: 20px; border-radius: 50%;"></span>
                                                <strong>RED:</strong> No Check-In (Absent)
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Calendar -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="calendar-container">
                                        <div class="calendar-header text-center mb-3">
                                            <h4>{{ $monthStart->format('F Y') }}</h4>
                                        </div>
                                        
                                        <div class="calendar-grid">
                                            <!-- Days of week header -->
                                            <div class="calendar-row calendar-header-row">
                                                <div class="calendar-day-header">Sun</div>
                                                <div class="calendar-day-header">Mon</div>
                                                <div class="calendar-day-header">Tue</div>
                                                <div class="calendar-day-header">Wed</div>
                                                <div class="calendar-day-header">Thu</div>
                                                <div class="calendar-day-header">Fri</div>
                                                <div class="calendar-day-header">Sat</div>
                                            </div>
                                            
                                            <!-- Calendar days -->
                                            @php
                                                $startOfWeek = $monthStart->copy()->startOfWeek();
                                                $endOfMonth = $monthStart->copy()->endOfMonth();
                                                $endOfWeek = $endOfMonth->copy()->endOfWeek();
                                                $currentDate = $startOfWeek->copy();
                                                $calendarDataByDate = collect($calendarData)->keyBy('date');
                                            @endphp
                                            
                                            @while($currentDate <= $endOfWeek)
                                                <div class="calendar-row">
                                                    @for($i = 0; $i < 7; $i++)
                                                        @php
                                                            $dateStr = $currentDate->format('Y-m-d');
                                                            $dayData = $calendarDataByDate->get($dateStr);
                                                            $isCurrentMonth = $currentDate->month == $monthStart->month;
                                                            $isToday = $currentDate->isToday();
                                                        @endphp
                                                        
                                                        <div class="calendar-day {{ !$isCurrentMonth ? 'other-month' : '' }} {{ $isToday ? 'today' : '' }}"
                                                             data-date="{{ $dateStr }}"
                                                             @if($dayData && $isCurrentMonth)
                                                                onclick="showDayDetails('{{ $dateStr }}', {{ json_encode($dayData) }})"
                                                                style="cursor: pointer;"
                                                             @endif>
                                                            
                                                            <div class="day-number">{{ $currentDate->day }}</div>
                                                            
                                                            @if($dayData && $isCurrentMonth)
                                                                <div class="attendance-indicator attendance-{{ $dayData['status'] }}">
                                                                    @if($dayData['status'] == 'complete')
                                                                        <i class="fas fa-check"></i>
                                                                    @elseif($dayData['status'] == 'incomplete')
                                                                        <i class="fas fa-exclamation"></i>
                                                                    @else
                                                                        <i class="fas fa-times"></i>
                                                                    @endif
                                                                </div>
                                                                
                                                                @if($dayData['attendance'])
                                                                    <div class="time-info">
                                                                        @if($dayData['attendance']['check_in_time'])
                                                                            <small class="check-in-time">{{ substr($dayData['attendance']['check_in_time'], 0, 5) }}</small>
                                                                        @endif
                                                                        @if($dayData['attendance']['check_out_time'])
                                                                            <small class="check-out-time">{{ substr($dayData['attendance']['check_out_time'], 0, 5) }}</small>
                                                                        @endif
                                                                    </div>
                                                                @endif
                                                            @elseif($isCurrentMonth)
                                                                <div class="attendance-indicator attendance-absent">
                                                                    <i class="fas fa-times"></i>
                                                                </div>
                                                            @endif
                                                        </div>
                                                        
                                                        @php $currentDate->addDay(); @endphp
                                                    @endfor
                                                </div>
                                            @endwhile
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection

@push('scripts')
<script>
function showDayDetails(date, dayData) {
    if (!dayData.attendance) {
        Swal.fire({
            title: 'No Attendance Record',
            text: 'No attendance record found for ' + formatDate(date),
            icon: 'info',
            confirmButtonText: 'OK'
        });
        return;
    }
    
    const attendance = dayData.attendance;
    const formattedDate = formatDate(date);
    
    let statusBadge = '';
    let statusText = '';
    
    if (dayData.status === 'complete') {
        statusBadge = '<span class="badge badge-success">Complete</span>';
        statusText = 'Proper Check-In & Check-Out done';
    } else if (dayData.status === 'incomplete') {
        statusBadge = '<span class="badge badge-warning">Incomplete</span>';
        statusText = 'Only Check-In done (Checkout Missing)';
    } else {
        statusBadge = '<span class="badge badge-danger">Absent</span>';
        statusText = 'No Check-In (Absent)';
    }
    
    let totalHours = '-';
    if (attendance.check_in_date && attendance.check_in_time && attendance.check_out_date && attendance.check_out_time) {
        const checkIn = new Date(attendance.check_in_date + ' ' + attendance.check_in_time);
        const checkOut = new Date(attendance.check_out_date + ' ' + attendance.check_out_time);
        const diffMs = checkOut - checkIn;
        const hours = Math.floor(diffMs / (1000 * 60 * 60));
        const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        totalHours = hours + 'h ' + minutes + 'm';
    }
    
    const html = `
        <div style="text-align: left;">
            <div class="row mb-3">
                <div class="col-12 text-center">
                    <h5>${formattedDate}</h5>
                    ${statusBadge}
                    <p class="text-muted mt-2">${statusText}</p>
                </div>
            </div>
            
            <div class="row">
                <div class="col-6">
                    <h6><i class="fas fa-sign-in-alt text-success mr-2"></i>Check-In</h6>
                    <p><strong>Time:</strong> ${attendance.check_in_time || 'N/A'}</p>
                    <p><strong>Date:</strong> ${attendance.check_in_date || 'N/A'}</p>
                </div>
                <div class="col-6">
                    <h6><i class="fas fa-sign-out-alt text-danger mr-2"></i>Check-Out</h6>
                    <p><strong>Time:</strong> ${attendance.check_out_time || 'N/A'}</p>
                    <p><strong>Date:</strong> ${attendance.check_out_date || 'N/A'}</p>
                </div>
            </div>
            
            <div class="row mt-3">
                <div class="col-6">
                    <h6><i class="fas fa-clock text-primary mr-2"></i>Total Hours</h6>
                    <p><strong>${totalHours}</strong></p>
                </div>
                <div class="col-6">
                    <h6><i class="fas fa-building text-info mr-2"></i>Plant</h6>
                    <p><strong>${attendance.plant_name || 'N/A'}</strong></p>
                </div>
            </div>
            
            ${attendance.shift_type ? `
                <div class="row mt-2">
                    <div class="col-12">
                        <h6><i class="fas fa-clock text-warning mr-2"></i>Shift Type</h6>
                        <p><span class="badge badge-info">${attendance.shift_type}</span></p>
                    </div>
                </div>
            ` : ''}
        </div>
    `;
    
    Swal.fire({
        title: 'Attendance Details',
        html: html,
        icon: 'info',
        showConfirmButton: false,
        showCloseButton: true,
        width: '600px',
        customClass: {
            popup: 'swal-wide'
        }
    });
}

function formatDate(dateStr) {
    const date = new Date(dateStr);
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    };
    return date.toLocaleDateString('en-US', options);
}
</script>

<style>
.calendar-container {
    max-width: 100%;
    margin: 0 auto;
}

.calendar-grid {
    display: flex;
    flex-direction: column;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    overflow: hidden;
}

.calendar-row {
    display: flex;
    border-bottom: 1px solid #dee2e6;
}

.calendar-row:last-child {
    border-bottom: none;
}

.calendar-header-row {
    background-color: #f8f9fa;
}

.calendar-day-header {
    flex: 1;
    padding: 12px 8px;
    text-align: center;
    font-weight: bold;
    color: #495057;
    border-right: 1px solid #dee2e6;
    font-size: 14px;
}

.calendar-day-header:last-child {
    border-right: none;
}

.calendar-day {
    flex: 1;
    min-height: 100px;
    padding: 8px;
    border-right: 1px solid #dee2e6;
    position: relative;
    background-color: #fff;
    transition: background-color 0.2s ease;
}

.calendar-day:last-child {
    border-right: none;
}

.calendar-day:hover {
    background-color: #f8f9fa;
}

.calendar-day.other-month {
    background-color: #f8f9fa;
    color: #6c757d;
}

.calendar-day.today {
    background-color: #e3f2fd;
    border: 2px solid #2196f3;
}

.day-number {
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 4px;
    color: #495057;
}

.attendance-indicator {
    position: absolute;
    top: 8px;
    right: 8px;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    color: white;
}

.attendance-complete {
    background-color: #28a745;
}

.attendance-incomplete {
    background-color: #ffc107;
}

.attendance-absent {
    background-color: #dc3545;
}

.time-info {
    position: absolute;
    bottom: 4px;
    left: 4px;
    right: 4px;
    font-size: 10px;
    line-height: 1.2;
}

.check-in-time {
    display: block;
    color: #28a745;
    font-weight: bold;
}

.check-out-time {
    display: block;
    color: #dc3545;
    font-weight: bold;
}

/* Responsive Design */
@media (max-width: 768px) {
    .calendar-day {
        min-height: 80px;
        padding: 4px;
    }
    
    .day-number {
        font-size: 14px;
    }
    
    .attendance-indicator {
        width: 20px;
        height: 20px;
        font-size: 10px;
    }
    
    .time-info {
        font-size: 9px;
    }
    
    .calendar-day-header {
        padding: 8px 4px;
        font-size: 12px;
    }
}

@media (max-width: 576px) {
    .calendar-day {
        min-height: 60px;
        padding: 2px;
    }
    
    .day-number {
        font-size: 12px;
    }
    
    .attendance-indicator {
        width: 16px;
        height: 16px;
        font-size: 8px;
    }
    
    .time-info {
        display: none; /* Hide time info on very small screens */
    }
    
    .calendar-day-header {
        padding: 6px 2px;
        font-size: 11px;
    }
}

/* SweetAlert2 custom styles */
.swal-wide {
    max-width: 90% !important;
}

.swal2-popup {
    font-size: 14px !important;
}

.swal2-html-container {
    text-align: left !important;
}
</style>
@endpush
