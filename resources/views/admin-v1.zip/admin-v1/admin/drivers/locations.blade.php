@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <div class="card mb-5 mb-xl-10">
                <div class="card-header border-0 cursor-pointer">
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">
                            <i class="fas fa-map-marker-alt text-primary mr-2"></i>
                            Driver Locations
                        </h3>
                    </div>
                    <div class="card-tools">
                        <a href="{{ route('admin-v1.drivers') }}" class="btn btn-secondary btn-sm">
                            <i class="fas fa-arrow-left mr-1"></i> Back to Drivers
                        </a>
                    </div>
                </div>

                <div class="card-body border-top p-9">
                    <div class="row mb-6">
                        <!-- Map Container -->
                        <div id="map" style="height: 500px; width: 100%;"></div>
                    </div>
                </div>

                <div class="card-body py-3">
                    <!-- Table container -->
                    <div>
                        <!-- Table -->
                        <table id="kt_datatable_example_1" class="table align-middle table-row-dashed fs-6 gy-5">
                            <thead>
                                <tr class="fw-bold text-dark bg-light">
                                    <th class="ps-4" style="width: 80px;"><b>Sr.No</b></th>
                                    <th class="ps-4" style="width: 250px;"><b>Name</b></th>
                                    <th style="width: 180px;"><b>Mobile</b></th>
                                    <th style="width: 300px;"><b>Serving Area</b></th>
                                </tr>
                            </thead>
                            <tbody class="text-gray-600 fw-semibold">
                                <!-- DataTable will populate this -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('scripts')
<script>
    window.onload = function () {
        initMap();
    };

    function initMap() {
        const locations = <?php echo json_encode($location) ?>;

        if (!locations || locations.length === 0) {
            return;
        }

        const mapElement = document.getElementById("map");

        if (!mapElement) {
            return;
        }

        const map = new google.maps.Map(mapElement, {
            zoom: 10,
            center: {
                lat: parseFloat(locations[0].latitude),
                lng: parseFloat(locations[0].longitude),
            },
            mapId: "475512f07c8e6cee",
        });

        const bounds = new google.maps.LatLngBounds();

        locations.forEach(value => {
            let lat = parseFloat(value.latitude);
            let lng = parseFloat(value.longitude);

            if (isNaN(lat) || isNaN(lng)) return;

            // Create custom content for marker
            const iconImg = document.createElement("img");
            iconImg.src = "https://www.goaid.in/goaid/images/ambulance.png";
            iconImg.style.width = "32px";
            iconImg.style.height = "32px";

            // Create tooltip div for hover (driver name & phone)
            const tooltip = document.createElement("div");
            tooltip.style.padding = "4px 8px";
            tooltip.style.background = "white";
            tooltip.style.border = "1px solid #ccc";
            tooltip.style.borderRadius = "4px";
            tooltip.style.boxShadow = "0 2px 6px rgba(0,0,0,0.3)";
            tooltip.style.whiteSpace = "nowrap";
            tooltip.innerHTML = `<strong>${value.first_name}</strong><br/>📞 ${value.mobile}`;

            // Combine icon and tooltip (hidden by default)
            const container = document.createElement("div");
            container.appendChild(iconImg);
            container.appendChild(tooltip);
            tooltip.style.display = "none"; // hide tooltip initially

            // Show tooltip on hover
            container.addEventListener("mouseenter", () => {
                tooltip.style.display = "block";
            });
            container.addEventListener("mouseleave", () => {
                tooltip.style.display = "none";
            });

            const marker = new google.maps.marker.AdvancedMarkerElement({
                position: { lat, lng },
                content: container,
                title: "Driver Location",
            });

            marker.map = map;

            bounds.extend(new google.maps.LatLng(lat, lng));

            // Click to open in Google Maps
            marker.addEventListener("click", () => {
                window.open(`https://www.google.com/maps/place/${lat},${lng}`, "_blank");
            });
        });

        map.fitBounds(bounds);
        google.maps.event.addListenerOnce(map, 'bounds_changed', function () {
            const maxZoom = 14; 
            if (map.getZoom() > maxZoom) {
                map.setZoom(maxZoom);
            }
        });
    }
</script>

<!-- Google Maps API -->
<script async src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC7bw_LEDJztaV68tYo-PbJfIdS_tBVyQ&libraries=maps,marker&v=beta"></script>

<script type="text/javascript">
    $(document).ready(function () {
        var dt = $("#kt_datatable_example_1").DataTable({
            "fixedHeader": {
                "header": true,
            },
            processing: true,
            serverSide: true,
            order: false,
            ajax: "{{ route('mapped.driver') }}",
            columns: [
                { 
                    data: null, 
                    name: 'serial_no', 
                    orderable: false, 
                    searchable: false,
                    render: function (data, type, row, meta) {
                        return meta.row + 1; // Indexing starts from 1
                    }
                },
                {data: 'first_name', name: 'first_name'},
                {data: 'mobile', name: 'mobile'},
                {data: 'serving_area', name: 'serving_area'},
            ]
        });

        $('[data-kt-docs-table-filter="search"]').on('keyup', function () {
            console.log("Search input changed");
            console.log("Search value:", $(this).val());
            dt.search($(this).val()).draw();
        });
    });
</script>
@endpush
