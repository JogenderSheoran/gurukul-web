@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Driver Rides Card -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-car mr-2"></i>
                                Driver Rides - {{ $driver->first_name }} {{ $driver->last_name }}
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.drivers') }}" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Drivers
                                </a>
                                <a href="{{ route('admin-v1.drivers.show', $driver->id) }}" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> View Details
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Driver Information Row -->
                            <div class="row mb-4">
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-info"><i class="fas fa-user"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Driver</span>
                                            <span class="info-box-number">{{ $driver->first_name }} {{ $driver->last_name }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-success"><i class="fas fa-phone"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Mobile</span>
                                            <span class="info-box-number">{{ $driver->mobile }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-warning"><i class="fas fa-layer-group"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Group</span>
                                            <span class="info-box-number">{{ $driver->group ? $driver->group->name : 'N/A' }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-danger"><i class="fas fa-calendar"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Member Since</span>
                                            <span class="info-box-number">{{ $driver->created_at->format('M Y') }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Rides DataTable -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table id="ridesTable" class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Ride ID</th>
                                                    <th>User</th>
                                                    <th>Locations</th>
                                                    <th>Vehicle</th>
                                                    <th>Distance</th>
                                                    <th>Amount</th>
                                                    <th>Status</th>
                                                    <th>Date</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!-- DataTables will populate this -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->

    <!-- Ride Details Modal -->
    <div class="modal fade" id="rideDetailsModal" tabindex="-1" role="dialog" aria-labelledby="rideDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="rideDetailsModalLabel">Ride Details</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="rideDetailsContent">
                    <div class="text-center py-5">
                        <div class="spinner-border text-primary" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                        <p class="mt-2">Loading ride details...</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
<script>
$(document).ready(function() {
    // Wait for DataTables to be available
    if (typeof $.fn.DataTable === 'undefined') {
        console.error('DataTables not loaded!');
        return;
    }
    
    console.log('Initializing DataTable...');
    console.log('AJAX URL:', '{{ route("admin-v1.drivers.rides.data", $driver->id) }}');
    
    var table = $('#ridesTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '{{ route("admin-v1.drivers.rides.data", $driver->id) }}',
            type: 'GET',
            error: function(xhr, error, thrown) {
                console.error('AJAX Error:', error, thrown);
                console.error('Response:', xhr.responseText);
                
                // Show user-friendly error
                $('#ridesTable_wrapper').prepend(
                    '<div class="alert alert-danger alert-dismissible">' +
                    '<button type="button" class="close" data-dismiss="alert">&times;</button>' +
                    '<strong>Error!</strong> Failed to load rides data: ' + error +
                    '</div>'
                );
            }
        },
        columns: [
            { data: 'ride_id', name: 'id' },
            { data: 'user_info', name: 'user_info', orderable: false, searchable: false },
            { data: 'locations', name: 'locations', orderable: false, searchable: false },
            { data: 'vehicle_info', name: 'vehicle_info' },
            { data: 'distance', name: 'distance' },
            { data: 'amount', name: 'charges' },
            { data: 'status_badge', name: 'status' },
            { data: 'ride_date', name: 'created_at' },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ],
        order: [[7, 'desc']], // Order by date descending
        pageLength: 25,
        responsive: true,
        language: {
            processing: '<i class="fas fa-spinner fa-spin"></i> Loading rides...',
            emptyTable: 'No rides found for this driver',
            zeroRecords: 'No matching rides found',
            loadingRecords: 'Loading...',
            info: 'Showing _START_ to _END_ of _TOTAL_ rides',
            infoEmpty: 'Showing 0 to 0 of 0 rides',
            infoFiltered: '(filtered from _MAX_ total rides)'
        }
    });
    
    // Log when table is initialized
    table.on('init.dt', function() {
        console.log('DataTable initialized successfully');
    });
    
    // Log draw events
    table.on('draw.dt', function() {
        console.log('DataTable redrawn');
    });

    // Handle click on view ride details button
    $(document).on('click', '.view-ride-details', function() {
        const rideId = $(this).data('ride-id');
        const modal = $('#rideDetailsModal');
        const modalContent = $('#rideDetailsContent');
        
        // Show loading state
        modalContent.html(`
            <div class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
                <p class="mt-2">Loading ride details...</p>
            </div>
        `);
        
        // Show the modal
        modal.modal('show');
        
        // Fetch ride details via AJAX
        $.ajax({
            url: `/admin-v1/rides/${rideId}/details`,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response) {
                    // Format the ride details
                    const ride = response.ride;
                    const user = response.user || {};
                    const driver = response.driver || {};
                    const vehicle = response.vehicle || {};
                    
                    // Format the ride details HTML
                    const rideDetailsHtml = `
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card mb-3">
                                    <div class="card-header bg-light">
                                        <h5 class="card-title mb-0">Ride Information</h5>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-sm table-borderless">
                                            <tr>
                                                <th width="40%">Ride ID:</th>
                                                <td>#${ride.id}</td>
                                            </tr>
                                            <tr>
                                                <th>Status:</th>
                                                <td>${ride.status_badge || '<span class="badge badge-secondary">' + (ride.status || 'N/A') + '</span>'}</td>
                                            </tr>
                                            <tr>
                                                <th>Booking Date:</th>
                                                <td>${ride.created_at || 'N/A'}</td>
                                            </tr>
                                            ${ride.distance ? `
                                            <tr>
                                                <th>Distance:</th>
                                                <td>${ride.distance} km</td>
                                            </tr>
                                            ` : ''}
                                            ${ride.charges ? `
                                            <tr>
                                                <th>Amount:</th>
                                                <td>₹${parseFloat(ride.charges).toFixed(2)}</td>
                                            </tr>
                                            ` : ''}
                                            ${ride.payment_status ? `
                                            <tr>
                                                <th>Payment Status:</th>
                                                <td>${ride.payment_status === 'completed' ? '<span class="badge badge-success">Paid</span>' : '<span class="badge badge-warning">' + ride.payment_status + '</span>'}</td>
                                            </tr>
                                            ` : ''}
                                        </table>
                                    </div>
                                </div>
                            </div>
                            ${(ride.pickup_address || ride.drop_address) ? `
                            <div class="col-md-6">
                                <div class="card mb-3">
                                    <div class="card-header bg-light">
                                        <h5 class="card-title mb-0">Location Details</h5>
                                    </div>
                                    <div class="card-body">
                                        ${ride.pickup_address ? `
                                        <div class="mb-3">
                                            <h6 class="text-muted">Pickup Location</h6>
                                            <p class="mb-1"><i class="fas fa-map-marker-alt text-success mr-2"></i> ${ride.pickup_address}</p>
                                            ${ride.pickup_latitude && ride.pickup_longitude ? 
                                                `<small class="text-muted">
                                                    <i class="fas fa-map-marked-alt mr-1"></i> 
                                                    <a href="https://www.google.com/maps?q=${ride.pickup_latitude},${ride.pickup_longitude}" target="_blank">
                                                        View on Map
                                                    </a>
                                                </small>` 
                                                : ''
                                            }
                                        </div>
                                        ` : ''}
                                        ${ride.drop_address ? `
                                        <div class="mb-3">
                                            <h6 class="text-muted">Drop Location</h6>
                                            <p class="mb-1"><i class="fas fa-flag-checkered text-danger mr-2"></i> ${ride.drop_address}</p>
                                            ${ride.drop_latitude && ride.drop_longitude ? 
                                                `<small class="text-muted">
                                                    <i class="fas fa-map-marked-alt mr-1"></i> 
                                                    <a href="https://www.google.com/maps?q=${ride.drop_latitude},${ride.drop_longitude}" target="_blank">
                                                        View on Map
                                                    </a>
                                                </small>` 
                                                : ''
                                            }
                                        </div>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                            ` : ''}
                        </div>
                        ${(user || driver || vehicle) ? `
                        <div class="row">
                            ${user ? `
                            <div class="col-md-6">
                                <div class="card mb-3">
                                    <div class="card-header bg-light">
                                        <h5 class="card-title mb-0">User Details</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex align-items-center">
                                            <div class="mr-3">
                                                <div class="avatar bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                                    <i class="fas fa-user"></i>
                                                </div>
                                            </div>
                                            <div>
                                                <h6 class="mb-0">${user.name}</h6>
                                                <small class="text-muted">${user.mobile}</small>
                                                ${user.email ? `<br><small class="text-muted">${user.email}</small>` : ''}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            ` : ''}
                            ${(driver || vehicle) ? `
                            <div class="col-md-6">
                                <div class="card mb-3">
                                    <div class="card-header bg-light">
                                        <h5 class="card-title mb-0">${vehicle ? 'Vehicle' : 'Driver'} Details</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex align-items-center">
                                            <div class="mr-3">
                                                <div class="avatar bg-info text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                                    <i class="fas fa-${vehicle ? 'car' : 'user-tie'}"></i>
                                                </div>
                                            </div>
                                            <div>
                                                ${vehicle ? `
                                                    <h6 class="mb-0">${vehicle.name}</h6>
                                                    <small class="text-muted">${vehicle.vehicle_number || 'N/A'}</small>
                                                    ${vehicle.vehicle_type ? `<br><small class="text-muted">${vehicle.vehicle_type}</small>` : ''}
                                                ` : ''}
                                                ${driver ? `
                                                    <h6 class="mb-0">${driver.name}</h6>
                                                    <small class="text-muted">${driver.mobile || 'N/A'}</small>
                                                ` : ''}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            ` : ''}
                        </div>
                        ` : ''}
                        ${(ride.ride_type || ride.ride_time || ride.estimated_duration || ride.payment_method || ride.base_fare || ride.notes) ? `
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header bg-light">
                                        <h5 class="card-title mb-0">Additional Information</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                ${ride.ride_type ? `<p><strong>Ride Type:</strong> ${ride.ride_type}</p>` : ''}
                                                ${ride.ride_time ? `<p><strong>Ride Date & Time:</strong> ${ride.ride_time}</p>` : ''}
                                                ${ride.estimated_duration ? `<p><strong>Estimated Duration:</strong> ${ride.estimated_duration}</p>` : ''}
                                            </div>
                                            <div class="col-md-6">
                                                ${ride.payment_method ? `<p><strong>Payment Method:</strong> ${ride.payment_method}</p>` : ''}
                                                ${ride.base_fare ? `<p><strong>Base Fare:</strong> ₹${parseFloat(ride.base_fare).toFixed(2)}</p>` : ''}
                                                ${ride.charges ? `<p><strong>Total Amount:</strong> <span class="font-weight-bold">₹${parseFloat(ride.charges).toFixed(2)}</span></p>` : ''}
                                            </div>
                                        </div>
                                        ${ride.notes ? `
                                            <div class="mt-3">
                                                <h6>Special Instructions:</h6>
                                                <p class="text-muted">${ride.notes}</p>
                                            </div>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                        </div>
                        ` : ''}
                    `;
                    
                    // Update the modal content
                    modalContent.html(rideDetailsHtml);
                } else {
                    modalContent.html(`
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle mr-2"></i>
                            Unable to load ride details. Please try again.
                        </div>
                    `);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching ride details:', error);
                modalContent.html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        Error loading ride details. Please try again later.
                    </div>
                `);
            }
        });
    });
});
</script>
@endpush
