@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-edit mr-2"></i>
                                Edit Driver - {{ $driver->first_name }} {{ $driver->last_name }}
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.drivers') }}" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Drivers
                                </a>
                                <a href="{{ route('admin-v1.drivers.show', $driver->id) }}" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> View Details
                                </a>
                                <button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete({{ $driver->id }})">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                                <form id="delete-form-{{ $driver->id }}" action="{{ route('admin-v1.drivers.destroy', $driver->id) }}" method="POST" style="display: none;">
                                    @csrf
                                    @method('DELETE')
                                </form>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Quick Actions Row -->
                            <div class="row mb-4">
                                <div class="col-md-12">
                                    <h5>Quick Actions:</h5>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="{{ route('admin-v1.drivers.show', $driver->id) }}" class="btn btn-info">
                                            <i class="fas fa-eye mr-1"></i> Details
                                        </a>
                                        <a href="{{ route('admin-v1.drivers.rides', $driver->id) }}" class="btn btn-primary">
                                            <i class="fas fa-car mr-1"></i> Rides
                                        </a>
                                        <a href="{{ route('admin-v1.drivers.attendance', $driver->id) }}" class="btn btn-success">
                                            <i class="fas fa-calendar-check mr-1"></i> Attendance
                                        </a>
                                        <a href="{{ route('admin-v1.drivers.transactions', $driver->id) }}" class="btn btn-warning">
                                            <i class="fas fa-money-bill mr-1"></i> Transactions
                                        </a>
                                        <button type="button" class="btn btn-danger" onclick="confirmDelete({{ $driver->id }})">
                                            <i class="fas fa-trash mr-1"></i> Delete
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <form id="editDriverForm" method="POST" action="{{ route('admin-v1.drivers.update', $driver->id) }}" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')
                                
                                <!-- Personal Information -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="section-header">
                                            <i class="fas fa-user mr-2"></i>Personal Information
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="first_name">First Name <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="first_name" name="first_name" 
                                                   value="{{ old('first_name', $driver->first_name) }}" 
                                                   placeholder="Enter first name" required>
                                            @error('first_name')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="last_name">Last Name <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="last_name" name="last_name" 
                                                   value="{{ old('last_name', $driver->last_name) }}" 
                                                   placeholder="Enter last name" required>
                                            @error('last_name')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="mobile_number">Mobile Number <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="mobile_number" name="mobile_number" 
                                                   value="{{ old('mobile_number', $driver->mobile) }}" 
                                                   placeholder="Enter mobile number" required>
                                            @error('mobile_number')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="pin">PIN</label>
                                            <input type="text" class="form-control" id="pin" name="pin" 
                                                   value="{{ old('pin', $driver->pin) }}" 
                                                   placeholder="Enter 4-6 digit PIN">
                                        </div>
                                    </div>
                                </div>

                                <!-- Location Information -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="section-header">
                                            <i class="fas fa-map-marker-alt mr-2"></i>Location Information
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="city">City <span class="text-danger">*</span></label>
                                            <select class="form-control select2" id="city" name="city" required>
                                                <option value="">Select City</option>
                                                @foreach($cities as $city)
                                                    <option value="{{ $city->id }}" {{ old('city', $driver->city) == $city->id ? 'selected' : '' }}>
                                                        {{ $city->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('city')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="state">State <span class="text-danger">*</span></label>
                                            <select class="form-control select2" id="state" name="state" required>
                                                <option value="">Select State</option>
                                                <option value="Andhra Pradesh" {{ old('state', $driver->state) == 'Andhra Pradesh' ? 'selected' : '' }}>Andhra Pradesh</option>
                                                <option value="Arunachal Pradesh" {{ old('state', $driver->state) == 'Arunachal Pradesh' ? 'selected' : '' }}>Arunachal Pradesh</option>
                                                <option value="Assam" {{ old('state', $driver->state) == 'Assam' ? 'selected' : '' }}>Assam</option>
                                                <option value="Bihar" {{ old('state', $driver->state) == 'Bihar' ? 'selected' : '' }}>Bihar</option>
                                                <option value="Chhattisgarh" {{ old('state', $driver->state) == 'Chhattisgarh' ? 'selected' : '' }}>Chhattisgarh</option>
                                                <option value="Goa" {{ old('state', $driver->state) == 'Goa' ? 'selected' : '' }}>Goa</option>
                                                <option value="Gujarat" {{ old('state', $driver->state) == 'Gujarat' ? 'selected' : '' }}>Gujarat</option>
                                                <option value="Haryana" {{ old('state', $driver->state) == 'Haryana' ? 'selected' : '' }}>Haryana</option>
                                                <option value="Himachal Pradesh" {{ old('state', $driver->state) == 'Himachal Pradesh' ? 'selected' : '' }}>Himachal Pradesh</option>
                                                <option value="Jharkhand" {{ old('state', $driver->state) == 'Jharkhand' ? 'selected' : '' }}>Jharkhand</option>
                                                <option value="Karnataka" {{ old('state', $driver->state) == 'Karnataka' ? 'selected' : '' }}>Karnataka</option>
                                                <option value="Kerala" {{ old('state', $driver->state) == 'Kerala' ? 'selected' : '' }}>Kerala</option>
                                                <option value="Madhya Pradesh" {{ old('state', $driver->state) == 'Madhya Pradesh' ? 'selected' : '' }}>Madhya Pradesh</option>
                                                <option value="Maharashtra" {{ old('state', $driver->state) == 'Maharashtra' ? 'selected' : '' }}>Maharashtra</option>
                                                <option value="Manipur" {{ old('state', $driver->state) == 'Manipur' ? 'selected' : '' }}>Manipur</option>
                                                <option value="Meghalaya" {{ old('state', $driver->state) == 'Meghalaya' ? 'selected' : '' }}>Meghalaya</option>
                                                <option value="Mizoram" {{ old('state', $driver->state) == 'Mizoram' ? 'selected' : '' }}>Mizoram</option>
                                                <option value="Nagaland" {{ old('state', $driver->state) == 'Nagaland' ? 'selected' : '' }}>Nagaland</option>
                                                <option value="Odisha" {{ old('state', $driver->state) == 'Odisha' ? 'selected' : '' }}>Odisha</option>
                                                <option value="Punjab" {{ old('state', $driver->state) == 'Punjab' ? 'selected' : '' }}>Punjab</option>
                                                <option value="Rajasthan" {{ old('state', $driver->state) == 'Rajasthan' ? 'selected' : '' }}>Rajasthan</option>
                                                <option value="Sikkim" {{ old('state', $driver->state) == 'Sikkim' ? 'selected' : '' }}>Sikkim</option>
                                                <option value="Tamil Nadu" {{ old('state', $driver->state) == 'Tamil Nadu' ? 'selected' : '' }}>Tamil Nadu</option>
                                                <option value="Telangana" {{ old('state', $driver->state) == 'Telangana' ? 'selected' : '' }}>Telangana</option>
                                                <option value="Tripura" {{ old('state', $driver->state) == 'Tripura' ? 'selected' : '' }}>Tripura</option>
                                                <option value="Uttar Pradesh" {{ old('state', $driver->state) == 'Uttar Pradesh' ? 'selected' : '' }}>Uttar Pradesh</option>
                                                <option value="Uttarakhand" {{ old('state', $driver->state) == 'Uttarakhand' ? 'selected' : '' }}>Uttarakhand</option>
                                                <option value="West Bengal" {{ old('state', $driver->state) == 'West Bengal' ? 'selected' : '' }}>West Bengal</option>
                                                <option value="Andaman and Nicobar Islands" {{ old('state', $driver->state) == 'Andaman and Nicobar Islands' ? 'selected' : '' }}>Andaman and Nicobar Islands</option>
                                                <option value="Chandigarh" {{ old('state', $driver->state) == 'Chandigarh' ? 'selected' : '' }}>Chandigarh</option>
                                                <option value="Dadra and Nagar Haveli and Daman and Diu" {{ old('state', $driver->state) == 'Dadra and Nagar Haveli and Daman and Diu' ? 'selected' : '' }}>Dadra and Nagar Haveli and Daman and Diu</option>
                                                <option value="Delhi" {{ old('state', $driver->state) == 'Delhi' ? 'selected' : '' }}>Delhi</option>
                                                <option value="Jammu and Kashmir" {{ old('state', $driver->state) == 'Jammu and Kashmir' ? 'selected' : '' }}>Jammu and Kashmir</option>
                                                <option value="Ladakh" {{ old('state', $driver->state) == 'Ladakh' ? 'selected' : '' }}>Ladakh</option>
                                                <option value="Lakshadweep" {{ old('state', $driver->state) == 'Lakshadweep' ? 'selected' : '' }}>Lakshadweep</option>
                                                <option value="Puducherry" {{ old('state', $driver->state) == 'Puducherry' ? 'selected' : '' }}>Puducherry</option>
                                            </select>
                                            @error('state')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="employee_id">Employee ID</label>
                                            <input type="text" class="form-control" id="employee_id" name="employee_id" 
                                                   value="{{ old('employee_id', $driver->employee_id) }}" 
                                                   placeholder="Enter employee ID">
                                            <small class="form-text text-muted">Optional field</small>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="plant_code">Plant Code</label>
                                            <input type="text" class="form-control" id="plant_code" name="plant_code" 
                                                   value="{{ old('plant_code', $driver->plant_code) }}" 
                                                   placeholder="Enter plant code">
                                            <small class="form-text text-muted">Optional field</small>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="serving_area">Serving Area</label>
                                            <textarea class="form-control" id="serving_area" name="serving_area" 
                                                      rows="3" placeholder="Enter serving area">{{ old('serving_area', $driver->serving_area) }}</textarea>
                                        </div>
                                    </div>
                                </div>

                                <!-- Driver Configuration -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="section-header">
                                            <i class="fas fa-cogs mr-2"></i>Driver Configuration
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="type">Driver Type <span class="text-danger">*</span></label>
                                            <select class="form-control select2" id="type" name="type" required>
                                                <option value="">Select Type</option>
                                                <option value="individual" {{ old('type', $driver->type) == 'individual' ? 'selected' : '' }}>Individual</option>
                                                <option value="group" {{ old('type', $driver->type) == 'group' ? 'selected' : '' }}>Group</option>
                                            </select>
                                            @error('type')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="site_type">Site Type <span class="text-danger">*</span></label>
                                            <select class="form-control select2" id="site_type" name="site_type" required>
                                                <option value="">Select Site Type</option>
                                                <option value="1" {{ old('site_type', $driver->site_type) == '1' ? 'selected' : '' }}>On Site</option>
                                                <option value="2" {{ old('site_type', $driver->site_type) == '2' ? 'selected' : '' }}>Off Site</option>
                                                <option value="3" {{ old('site_type', $driver->site_type) == '3' ? 'selected' : '' }}>On-Site Callers</option>
                                            </select>
                                            @error('site_type')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="shift_time">Shift Time <span class="text-danger">*</span></label>
                                            <select class="form-control select2" id="shift_time" name="shift_time" required>
                                                <option value="">Select Shift Time</option>
                                                <option value="8 Hour" {{ old('shift_time', $driver->shift_time) == '8 Hour' ? 'selected' : '' }}>8 Hour</option>
                                                <option value="12 Hours" {{ old('shift_time', $driver->shift_time) == '12 Hours' ? 'selected' : '' }}>12 Hours</option>
                                                <option value="No Restrictions" {{ old('shift_time', $driver->shift_time) == 'No Restrictions' ? 'selected' : '' }}>No Restrictions</option>
                                            </select>
                                            @error('shift_time')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row" id="group_selection" style="{{ $driver->type == 'group' ? 'display: block;' : 'display: none;' }}">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="group_id">Select Group</label>
                                            <select class="form-control select2" id="group_id" name="group_id">
                                                <option value="">Select Group</option>
                                                @foreach($groups as $group)
                                                    <option value="{{ $group->id }}" {{ old('group_id', $driver->group_id) == $group->id ? 'selected' : '' }}>
                                                        {{ $group->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="priority">Priority</label>
                                            <input type="number" class="form-control" id="priority" name="priority" 
                                                   value="{{ old('priority', $driver->priority ?? 1) }}" min="1" max="10">
                                        </div>
                                    </div>
                                </div>

                                <!-- Vehicle Information -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="section-header">
                                            <i class="fas fa-car mr-2"></i>Vehicle Information
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="vehicle_category_id">Vehicle Categories <span class="text-danger">*</span></label>
                                            <select class="form-control select2-multi" id="vehicle_category_id" name="vehicle_category_id[]" multiple required>
                                                @foreach($vehicleCategories as $category)
                                                    @php
                                                        $selectedCategories = $driver->vehicle_category_id ?? [];
                                                    @endphp
                                                    <option value="{{ $category->id }}" {{ in_array($category->id, $selectedCategories) ? 'selected' : '' }}>
                                                        {{ $category->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('vehicle_category_id')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="vehicle_type">Vehicle Types <span class="text-danger">*</span></label>
                                            <select class="form-control select2-multi" id="vehicle_type" name="vehicle_type[]" multiple required>
                                                @php
                                                    $selectedVehicles = old('vehicle_type', $driver->vehicle_type ?? []);
                                                    if (!is_array($selectedVehicles)) {
                                                        $selectedVehicles = [];
                                                    }
                                                @endphp
                                                <option value="Echo" {{ in_array('Echo', $selectedVehicles) ? 'selected' : '' }}>Echo</option>
                                                <option value="Bolero" {{ in_array('Bolero', $selectedVehicles) ? 'selected' : '' }}>Bolero</option>
                                                <option value="Tempo" {{ in_array('Tempo', $selectedVehicles) ? 'selected' : '' }}>Tempo</option>
                                            </select>
                                            @error('vehicle_type')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary" id="submitBtn">
                                                <i class="fas fa-save mr-1"></i> Update Driver
                                            </button>
                                            <a href="{{ route('admin-v1.drivers') }}" class="btn btn-secondary ml-2">
                                                <i class="fas fa-times mr-1"></i> Cancel
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection

@push('style')
<style>
.select2-container .select2-selection--single {
    height: calc(2.25rem + 2px) !important;
    padding: 0.375rem 0.75rem;
    border: 1px solid #ced4da;
}

.select2-container .select2-selection--multiple {
    min-height: calc(2.25rem + 2px) !important;
    border: 1px solid #ced4da;
}

.section-header {
    background: #f8f9fa;
    color: #495057;
    padding: 0.5rem 1rem;
    border-radius: 0.25rem;
    margin-bottom: 1rem;
    font-weight: 500;
    text-align: left;
    border-left: 4px solid #007bff;
    font-size: 1.1rem;
}
</style>
@endpush

@push('scripts')
    <script>
        $(document).ready(function() {
            // Initialize Select2 for single select elements
            $('.select2').select2({
                width: '100%',
                placeholder: 'Select an option...',
                allowClear: true
            });

            // Initialize Select2 for multi-select elements
            $('.select2-multi').select2({
                width: '100%',
                placeholder: 'Select options...',
                allowClear: true,
                closeOnSelect: false
            });

            // Show/hide group selection based on driver type
            $('#type').on('change', function() {
                if ($(this).val() === 'group') {
                    $('#group_selection').show();
                } else {
                    $('#group_selection').hide();
                    $('#group_id').val('').trigger('change');
                }
            });

            // Handle form submission
            $('#editDriverForm').on('submit', function(e) {
                e.preventDefault();
                
                // Show loading state
                $('#submitBtn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin mr-1"></i> Updating...');

                // Create FormData object for file upload
                var formData = new FormData(this);

                // Submit via AJAX
                $.ajax({
                    url: $(this).attr('action'),
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        // Hide loading state
                        $('#submitBtn').prop('disabled', false).html('<i class="fas fa-save mr-1"></i> Update Driver');

                        if (response.success) {
                            Swal.fire({
                                title: 'Success!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href = response.redirect;
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: response.message,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    },
                    error: function(xhr) {
                        // Hide loading state
                        $('#submitBtn').prop('disabled', false).html('<i class="fas fa-save mr-1"></i> Update Driver');

                        let message = 'An error occurred while updating the driver.';
                        
                        if (xhr.status === 422) {
                            // Validation errors
                            const errors = xhr.responseJSON.errors;
                            
                            // Clear previous error messages
                            $('.text-danger').remove();
                            
                            // Display validation errors
                            $.each(errors, function(field, messages) {
                                const input = $('[name="' + field + '"]');
                                const errorSpan = $('<span class="text-danger">' + messages[0] + '</span>');
                                input.after(errorSpan);
                            });
                            
                            message = 'Please fix the validation errors.';
                        } else if (xhr.responseJSON && xhr.responseJSON.message) {
                            message = xhr.responseJSON.message;
                        }

                        Swal.fire({
                            title: 'Error!',
                            text: message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            });

            // Input validation - clear errors on input
            $('input, select').on('input change', function() {
                $(this).next('.text-danger').remove();
            });

            // Mobile number formatting
            $('input[name="mobile_number"]').on('input', function() {
                // Allow only numbers and basic formatting
                this.value = this.value.replace(/[^0-9+\-\s()]/g, '');
            });

            // PIN validation
            $('input[name="pin"]').on('input', function() {
                // Allow only numbers
                this.value = this.value.replace(/[^0-9]/g, '');
            });
        });

        // Handle delete confirmation
        function confirmDelete(driverId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    // Show loading state
                    Swal.fire({
                        title: 'Deleting...',
                        text: 'Please wait while we delete the driver.',
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    // Submit the delete form
                    const form = document.getElementById('delete-form-' + driverId);
                    fetch(form.action, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                            'X-Requested-With': 'XMLHttpRequest',
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ _method: 'DELETE' })
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            // Show success message and redirect
                            Swal.fire({
                                title: 'Deleted!',
                                text: data.message || 'Driver has been deleted successfully.',
                                icon: 'success',
                                timer: 2000,
                                showConfirmButton: false
                            }).then(() => {
                                window.location.href = '{{ route("admin-v1.drivers") }}';
                            });
                        } else {
                            throw new Error(data.message || 'Failed to delete driver');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire(
                            'Error!',
                            error.message || 'An error occurred while deleting the driver.',
                            'error'
                        );
                    });
                }
            });
        }
    </script>
@endpush
