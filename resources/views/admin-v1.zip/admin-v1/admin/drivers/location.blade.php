@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Page Header -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map-marker-alt text-primary mr-2"></i>
                                Driver Location - {{ $location['name'] }}
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.drivers') }}" class="btn btn-secondary btn-sm">
                                    <i class="fas fa-arrow-left mr-1"></i> Back to Drivers
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Driver Info Cards -->
            <div class="row mb-4">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{ $location['name'] }}</h3>
                            <p>Driver Name</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-user"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>{{ $location['mobile'] }}</h3>
                            <p>Mobile Number</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-phone"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>{{ $location['vehicle_number'] }}</h3>
                            <p>Vehicle Number</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-ambulance"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-secondary">
                        <div class="inner">
                            <h3>{{ $location['last_updated'] }}</h3>
                            <p>Last Updated</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Map Container -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map text-primary mr-2"></i>
                                Live Location Tracking
                            </h3>
                            <div class="card-tools">
                                <span class="badge badge-success">
                                    <i class="fas fa-circle text-success mr-1"></i>
                                    Live Tracking Active
                                </span>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div id="map" style="height: 600px; width: 100%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Driver Status Info -->
            <div class="row mt-4">
                <div class="col-lg-6 col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-info-circle text-info mr-2"></i>
                                Driver Status
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <strong>Status:</strong>
                                    @if($location['status'] == 0)
                                        <span class="badge badge-success ml-2">Active</span>
                                    @else
                                        <span class="badge badge-danger ml-2">Blocked</span>
                                    @endif
                                </div>
                                <div class="col-6">
                                    <strong>Profile:</strong>
                                    @if($location['profile_status'] == 1)
                                        <span class="badge badge-success ml-2">Verified</span>
                                    @else
                                        <span class="badge badge-warning ml-2">Pending</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-phone text-success mr-2"></i>
                                Contact Information
                            </h3>
                        </div>
                        <div class="card-body">
                            <p><strong>Mobile:</strong> {{ $location['mobile'] }}</p>
                            <p><strong>Vehicle Model:</strong> {{ $location['vehicle_model'] }}</p>
                            <a href="tel:{{ $location['mobile'] }}" class="btn btn-success btn-block">
                                <i class="fas fa-phone mr-2"></i> Call Driver
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('styles')
<style>
    #map {
        border-radius: 0 0 0.375rem 0.375rem;
    }

    .small-box .inner h3 {
        font-size: 1.2rem;
        margin-bottom: 5px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>
@endpush

@push('scripts')
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC7bw_LEDJztaV68tYo-PbJfIdS_tBVyQ&libraries=maps,marker&v=beta&callback=initMap" async defer></script>
<script>
    let map;
    let driverMarker;

    function initMap() {
        // Driver's location
        const driverLocation = {
            lat: {{ $location['latitude'] }},
            lng: {{ $location['longitude'] }}
        };

        // Create map
        map = new google.maps.Map(document.getElementById("map"), {
            zoom: 16,
            center: driverLocation,
            mapTypeId: 'roadmap',
            disableDefaultUI: true,
            zoomControl: true,
            zoomControlOptions: {
                position: google.maps.ControlPosition.RIGHT_BOTTOM
            },
            styles: [
                {
                    "featureType": "all",
                    "elementType": "geometry",
                    "stylers": [{"color": "#f5f5f5"}]
                },
                {
                    "featureType": "road",
                    "elementType": "geometry",
                    "stylers": [{"color": "#ffffff"}]
                },
                {
                    "featureType": "road",
                    "elementType": "geometry.stroke",
                    "stylers": [{"color": "#e0e0e0"}]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "geometry",
                    "stylers": [{"color": "#ffffff"}]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "geometry.stroke",
                    "stylers": [{"color": "#d0d0d0"}]
                },
                {
                    "featureType": "water",
                    "elementType": "geometry",
                    "stylers": [{"color": "#c9d6e8"}]
                },
                {
                    "featureType": "landscape",
                    "elementType": "geometry",
                    "stylers": [{"color": "#f0f0f0"}]
                },
                {
                    "featureType": "poi",
                    "elementType": "geometry",
                    "stylers": [{"color": "#e8e8e8"}]
                },
                {
                    "featureType": "poi.park",
                    "elementType": "geometry",
                    "stylers": [{"color": "#c8e6c8"}]
                }
            ]
        });

        // Custom ambulance marker
        const ambulanceIcon = {
            path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
            fillColor: '#007bff',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
            scale: 2,
            anchor: new google.maps.Point(12, 24)
        };

        // Add driver marker
        driverMarker = new google.maps.Marker({
            position: driverLocation,
            map: map,
            title: '{{ addslashes($location['name']) }}',
            icon: ambulanceIcon,
            animation: google.maps.Animation.DROP
        });

        // Add subtle pulsing circle around driver
        const pulseCircle = new google.maps.Circle({
            strokeColor: '#007bff',
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: '#007bff',
            fillOpacity: 0.1,
            map: map,
            center: driverLocation,
            radius: 100
        });

        // Info window for marker click
        const infoWindow = new google.maps.InfoWindow({
            content: `
                <div style="font-family: 'Inter', sans-serif; padding: 10px; max-width: 250px;">
                    <h6 style="margin: 0 0 8px 0; color: #223543;">{{ addslashes($location['name']) }}</h6>
                    <p style="margin: 0; color: #666; font-size: 14px;">
                        <i class="fas fa-phone text-success"></i> <strong>{{ $location['mobile'] }}</strong><br>
                        <i class="fas fa-ambulance text-primary"></i> {{ $location['vehicle_number'] }}<br>
                        <i class="fas fa-clock text-muted"></i> Updated {{ $location['last_updated'] }}
                    </p>
                </div>
            `
        });

        // Add click listener to marker
        driverMarker.addListener('click', () => {
            infoWindow.open(map, driverMarker);
        });

        // Auto-refresh location every 60 seconds
        setInterval(() => {
            window.location.reload();
        }, 60000);
    }

    // Handle window resize
    window.addEventListener('resize', function() {
        if (map) {
            google.maps.event.trigger(map, 'resize');
        }
    });

    // Prevent zoom on double tap (mobile)
    document.addEventListener('touchstart', function(e) {
        if (e.touches.length > 1) {
            e.preventDefault();
        }
    });

    let lastTouchEnd = 0;
    document.addEventListener('touchend', function(e) {
        const now = (new Date()).getTime();
        if (now - lastTouchEnd <= 300) {
            e.preventDefault();
        }
        lastTouchEnd = now;
    }, false);
</script>
@endpush
