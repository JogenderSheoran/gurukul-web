@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Driver Info Card -->
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-user mr-2"></i>
                                Driver Details - {{ $driver->first_name }} {{ $driver->last_name }}
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.drivers') }}" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Drivers
                                </a>
                                <a href="{{ route('admin-v1.drivers.edit', $driver->id) }}" class="btn btn-sm btn-primary">
                                    <i class="fas fa-edit"></i> Edit Driver
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 text-center">
                                    @if($driver->profile_pic && $driver->profile_pic != '')
                                        @php
                                            $imagePath = public_path('images/driver/' . $driver->profile_pic);
                                        @endphp
                                        @if(file_exists($imagePath))
                                            <img src="{{ asset('images/driver/' . $driver->profile_pic) }}" 
                                                 class="img-fluid rounded-circle" 
                                                 style="width: 150px; height: 150px; object-fit: cover;" 
                                                 alt="Driver Photo">
                                        @else
                                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center mx-auto" 
                                                 style="width: 150px; height: 150px; color: white; font-weight: bold; font-size: 48px;">
                                                {{ strtoupper(substr($driver->first_name, 0, 1) . substr($driver->last_name, 0, 1)) }}
                                            </div>
                                        @endif
                                    @else
                                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center mx-auto" 
                                             style="width: 150px; height: 150px; color: white; font-weight: bold; font-size: 48px;">
                                            {{ strtoupper(substr($driver->first_name, 0, 1) . substr($driver->last_name, 0, 1)) }}
                                        </div>
                                    @endif
                                </div>
                                <div class="col-md-8">
                                    <h4>{{ $driver->first_name }} {{ $driver->last_name }}</h4>
                                    <p class="text-muted">{{ $driver->email }}</p>
                                    
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <strong>Mobile:</strong> {{ $driver->mobile }}<br>
                                            <strong>City:</strong> 
                                            @php
                                                $city = \App\Models\City::find($driver->city);
                                            @endphp
                                            {{ $city ? $city->name : 'N/A' }}<br>
                                            <strong>Type:</strong> 
                                            @if($driver->type == 'group')
                                                <span class="badge badge-warning">Group</span>
                                            @else
                                                <span class="badge badge-success">Individual</span>
                                            @endif
                                            <br>
                                            <strong>Status:</strong>
                                            @if($driver->status == 0)
                                                <span class="badge badge-success">Active</span>
                                            @else
                                                <span class="badge badge-danger">Blocked</span>
                                            @endif
                                        </div>
                                        <div class="col-sm-6">
                                            <strong>Site Type:</strong>
                                            @switch($driver->site_type)
                                                @case(1)
                                                    <span class="badge badge-danger">On Site</span>
                                                    @break
                                                @case(2)
                                                    <span class="badge badge-success">Off Site</span>
                                                    @break
                                                @case(3)
                                                    <span class="badge badge-warning">On-Site Callers</span>
                                                    @break
                                                @default
                                                    <span class="badge badge-secondary">Unknown</span>
                                            @endswitch
                                            <br>
                                            <strong>Shift Time:</strong> 
                                            @if($driver->shift_time)
                                                <span class="badge badge-info">{{ $driver->shift_time }}</span>
                                            @else
                                                <span class="text-muted">N/A</span>
                                            @endif
                                            <br>
                                            <strong>Group:</strong> {{ $driver->group ? $driver->group->name : 'N/A' }}<br>
                                            <strong>Registered:</strong> {{ $driver->created_at->format('M d, Y h:i A') }}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            @if($driver->vehicle_category_id)
                                <hr>
                                <h5>Vehicle Information</h5>
                                <div class="row">
                                    <div class="col-md-12">
                                        @php
                                            $vehicle_category_ids = $driver->vehicle_category_id;
                                            if (is_array($vehicle_category_ids)) {
                                                $vehicle_types = \App\Models\Vehicle::whereIn('id', $vehicle_category_ids)->pluck('name')->toArray();
                                            } else {
                                                $vehicle_types = [];
                                            }
                                        @endphp
                                        @if(!empty($vehicle_types))
                                            @foreach($vehicle_types as $vehicle)
                                                <span class="badge badge-info mr-2 mb-2">{{ $vehicle }}</span>
                                            @endforeach
                                        @else
                                            <span class="text-muted">No vehicle information available</span>
                                        @endif
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Driver Statistics Sidebar -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-chart-bar mr-2"></i>
                                Quick Actions
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="{{ route('admin-v1.drivers.rides', $driver->id) }}" class="btn btn-primary btn-block">
                                    <i class="fas fa-car mr-2"></i> View Rides
                                </a>
                                <a href="{{ route('admin-v1.drivers.attendance', $driver->id) }}" class="btn btn-success btn-block">
                                    <i class="fas fa-calendar-check mr-2"></i> View Attendance
                                </a>
                                <a href="{{ route('admin-v1.drivers.transactions', $driver->id) }}" class="btn btn-info btn-block">
                                    <i class="fas fa-money-bill mr-2"></i> View Transactions
                                </a>
                                <a href="{{ route('admin-v1.drivers.edit', $driver->id) }}" class="btn btn-warning btn-block">
                                    <i class="fas fa-edit mr-2"></i> Edit Driver
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="card mt-3">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-info-circle mr-2"></i>
                                Driver Statistics
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-info"><i class="fas fa-hashtag"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Driver ID</span>
                                    <span class="info-box-number">#{{ $driver->id }}</span>
                                </div>
                            </div>

                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-success"><i class="fas fa-calendar"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Member Since</span>
                                    <span class="info-box-number text-sm">{{ $driver->created_at->format('M Y') }}</span>
                                </div>
                            </div>

                            <div class="info-box mb-3">
                                <span class="info-box-icon bg-warning"><i class="fas fa-clock"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Last Updated</span>
                                    <span class="info-box-number text-sm">{{ $driver->updated_at->diffForHumans() }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection
