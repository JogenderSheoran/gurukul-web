@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Driver Attendance Card -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-calendar-check mr-2"></i>
                                Driver Attendance - {{ $driver->first_name }} {{ $driver->last_name }}
                            </h3>
                            <div class="card-tools">
                                <a href="{{ route('admin-v1.drivers.attendance.calendar', $driver->id) }}" class="btn btn-sm btn-warning">
                                    <i class="fas fa-calendar-alt"></i> Calendar View
                                </a>
                                <a href="{{ route('admin-v1.drivers.attendance.monthly-report', $driver->id) }}" class="btn btn-sm btn-success">
                                    <i class="fas fa-chart-bar"></i> Monthly Report
                                </a>
                                <a href="{{ route('admin-v1.drivers') }}" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Drivers
                                </a>
                                <a href="{{ route('admin-v1.drivers.show', $driver->id) }}" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> View Details
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Driver Information Row -->
                            <div class="row mb-4">
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-info"><i class="fas fa-user"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Driver</span>
                                            <span class="info-box-number">{{ $driver->first_name }} {{ $driver->last_name }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-success"><i class="fas fa-calendar-check"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Total Records</span>
                                            <span class="info-box-number">{{ $attendanceData->total() }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-warning"><i class="fas fa-clock"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">This Month</span>
                                            <span class="info-box-number">{{ $attendanceData->where('created_at', '>=', now()->startOfMonth())->count() }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-danger"><i class="fas fa-calendar"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Member Since</span>
                                            <span class="info-box-number">{{ $driver->created_at->format('M Y') }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Attendance Records -->
                            <div class="row">
                                <div class="col-md-12">
                                    <h5 class="mb-3">Attendance Records</h5>
                                    
                                    @if($attendanceData->count() > 0)
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped table-sm">
                                                <thead>
                                                    <tr>
                                                        <th>Plant Name</th>
                                                        <th>Date</th>
                                                        <th>Shift Type</th>
                                                        <th>Check In</th>
                                                        <th>Check Out</th>
                                                        <th>Total Hours</th>
                                                        <th>Meter Reading</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($attendanceData as $record)
                                                        <tr>
                                                            <!-- Plant Name -->
                                                            <td>
                                                                <span style="font-size: 0.9rem; word-wrap: break-word;">{{ $record->plant_name ?? 'N/A' }}</span>
                                                            </td>
                                                            
                                                            <!-- Date -->
                                                            <td>
                                                                <strong>{{ $record->date ? \Carbon\Carbon::parse($record->date)->format('d M Y') : 'N/A' }}</strong>
                                                            </td>
                                                            
                                                            <!-- Shift Type -->
                                                            <td>
                                                                @if($record->shift_type)
                                                                    <span class="badge badge-info badge-sm">{{ ucfirst($record->shift_type) }}</span>
                                                                @else
                                                                    <span class="text-muted">N/A</span>
                                                                @endif
                                                            </td>
                                                            
                                                            <!-- Check In -->
                                                            <td>
                                                                @if($record->check_in_date && $record->check_in_time)
                                                                    <div style="font-size: 0.85rem;">
                                                                        <div><strong>{{ $record->check_in_time }}</strong></div>
                                                                        <small class="text-muted">{{ \Carbon\Carbon::parse($record->check_in_date)->format('d M') }}</small>
                                                                    </div>
                                                                @else
                                                                    <span class="text-muted">N/A</span>
                                                                @endif
                                                            </td>
                                                            
                                                            <!-- Check Out -->
                                                            <td>
                                                                @if($record->check_out_date && $record->check_out_time)
                                                                    <div style="font-size: 0.85rem;">
                                                                        <div><strong>{{ $record->check_out_time }}</strong></div>
                                                                        <small class="text-muted">{{ \Carbon\Carbon::parse($record->check_out_date)->format('d M') }}</small>
                                                                    </div>
                                                                @else
                                                                    <span class="badge badge-warning badge-sm">Pending</span>
                                                                @endif
                                                            </td>
                                                            
                                                            <!-- Total Hours -->
                                                            <td>
                                                                @if($record->check_in_date && $record->check_in_time && $record->check_out_date && $record->check_out_time)
                                                                    @php
                                                                        $checkIn = \Carbon\Carbon::parse($record->check_in_date . ' ' . $record->check_in_time);
                                                                        $checkOut = \Carbon\Carbon::parse($record->check_out_date . ' ' . $record->check_out_time);
                                                                        $totalHours = $checkOut->diffInHours($checkIn);
                                                                        $totalMinutes = $checkOut->diffInMinutes($checkIn) % 60;
                                                                    @endphp
                                                                    <span class="badge badge-success">{{ $totalHours }}h {{ $totalMinutes }}m</span>
                                                                @else
                                                                    <span class="text-muted">-</span>
                                                                @endif
                                                            </td>
                                                            
                                                            <!-- Meter Reading -->
                                                            <td>{{ $record->meter_reading ?? 'N/A' }}</td>
                                                            
                                                            <!-- Actions -->
                                                            <td>
                                                                <div class="btn-group btn-group-sm" role="group">
                                                                    <a href="{{ route('admin-v1.drivers.attendance.edit', [$driver->id, $record->id]) }}" class="btn btn-xs btn-primary" title="Edit Attendance" style="font-size: 0.7rem; padding: 2px 6px;">
                                                                        <i class="fas fa-edit"></i>
                                                                    </a>
                                                                    <button class="btn btn-xs btn-outline-info" onclick="viewFullDetails({{ $record->id }})" title="View Details" style="font-size: 0.7rem; padding: 2px 6px;">
                                                                        <i class="fas fa-eye"></i>
                                                                    </button>
                                                                    @if($record->photo)
                                                                        <button class="btn btn-xs btn-outline-success" onclick="viewPhoto('{{ $record->photo }}')" title="View Photo" style="font-size: 0.7rem; padding: 2px 6px;">
                                                                            <i class="fas fa-camera"></i>
                                                                        </button>
                                                                    @endif
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                        
                                        <!-- Pagination -->
                                        <div class="d-flex justify-content-center">
                                            {{ $attendanceData->links() }}
                                        </div>
                                    @else
                                        <div class="alert alert-info">
                                            <i class="fas fa-info-circle mr-2"></i>
                                            No attendance records found for this driver.
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection

@push('styles')
<style>
    /* Custom styles for the map container */
    #attendanceMap {
        min-height: 300px;
        transition: all 0.3s ease;
    }
    #mapLoading {
        text-align: center;
        color: #6c757d;
        font-size: 1.1rem;
    }
    #mapLoading i {
        color: #6c757d;
        margin-bottom: 10px;
    }
    #attendanceMap {
        border: 1px solid #dee2e6;
    }
    /* Ensure proper scrolling in the popup */
    .swal2-container {
        overflow-y: auto !important;
    }
    .swal2-popup {
        padding-bottom: 20px !important;
    }
</style>
@endpush

@push('scripts')
<!-- Add Leaflet CSS and JS for maps -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>

<script>
// Show details in SweetAlert popup
function showDetails(title, content) {
    Swal.fire({
        title: title,
        html: '<div style="text-align: left; max-height: 400px; overflow-y: auto;">' + content + '</div>',
        icon: 'info',
        confirmButtonText: 'Close',
        width: '600px',
        customClass: {
            popup: 'swal-wide'
        }
    });
}

// Show full attendance record details
function viewFullDetails(recordId) {
    // Get record data from the page (you can also make an AJAX call)
    const recordData = @json($attendanceData->keyBy('id'));
    const record = recordData[recordId];
    
    if (!record) {
        Swal.fire('Error', 'Record not found', 'error');
        return;
    }
    
    let html = '<div style="text-align: left;">';
    
    // Basic Information
    html += '<h5><i class="fas fa-info-circle text-primary"></i> Basic Information</h5>';
    html += '<div class="row mb-3">';
    html += '<div class="col-6"><strong>Date:</strong> ' + (record.date || 'N/A') + '</div>';
    html += '<div class="col-6"><strong>Plant Name:</strong> ' + (record.plant_name || 'N/A') + '</div>';
    html += '<div class="col-6"><strong>Shift Type:</strong> ' + (record.shift_type || 'N/A') + '</div>';
    html += '<div class="col-6"><strong>Meter Reading:</strong> ' + (record.meter_reading || 'N/A') + '</div>';
    html += '</div>';
    
    // Check In/Out Information
    html += '<h5><i class="fas fa-clock text-success"></i> Check In/Out Information</h5>';
    html += '<div class="row mb-3">';
    html += '<div class="col-6"><strong>Check In Date:</strong> ' + (record.check_in_date || 'N/A') + '</div>';
    html += '<div class="col-6"><strong>Check In Time:</strong> ' + (record.check_in_time || 'N/A') + '</div>';
    html += '<div class="col-6"><strong>Check Out Date:</strong> ' + (record.check_out_date || 'N/A') + '</div>';
    html += '<div class="col-6"><strong>Check Out Time:</strong> ' + (record.check_out_time || 'N/A') + '</div>';
    html += '</div>';
    
    // Inspection Details
    html += '<h5><i class="fas fa-clipboard-check text-warning"></i> Inspection Details</h5>';
    
    // Function to create a checklist section with proper list formatting
    const createChecklistSection = (title, items, icon = 'check-circle') => {
        if (!items || (typeof items !== 'object' && !Array.isArray(items))) return '';
        
        // Convert object to array of key-value pairs if needed
        const itemsArray = Array.isArray(items) ? items : Object.entries(items);
        if (itemsArray.length === 0) return '';
        
        let section = `
        <div class="card mb-3 border-0 shadow-sm">
            <div class="card-header bg-light d-flex align-items-center">
                <i class="fas fa-${icon} text-primary mr-2"></i>
                <h6 class="mb-0 font-weight-bold">${title}</h6>
            </div>
            <div class="card-body p-3">
                <ul class="list-unstyled mb-0">`;
        
        itemsArray.forEach((item, index) => {
            // Handle both array and object formats
            const displayText = Array.isArray(item) ? item[1] : (item.value || item);
            const status = item.status || 'completed'; // Default to completed if status not specified
            
            section += `
                    <li class="mb-2 d-flex align-items-start">
                        <i class="fas fa-${status === 'completed' ? 'check-circle text-success' : 'times-circle text-danger'} mt-1 mr-2" style="min-width: 20px;"></i>
                        <span>${displayText}</span>
                    </li>`;
            
            // Add divider except for the last item
            if (index < itemsArray.length - 1) {
                section += `
                    <div class="dropdown-divider my-2"></div>`;
            }
        });
        
        section += `
                </ul>
            </div>
        </div>`;
        
        return section;
    };
    
    // Add inspection sections based on the record data
    const inspectionSections = [
        { key: 'inspection_items', title: 'Inspection Items', icon: 'clipboard-check' },
        { key: 'external_inspection', title: 'External Inspection', icon: 'car-side' },
        { key: 'engine_mechanical_check', title: 'Engine Mechanical Check', icon: 'cog' },
        { key: 'emergency_medical_supply', title: 'Emergency Medical Supply', icon: 'first-aid' },
        { key: 'cleanliness_hygiene', title: 'Cleanliness & Hygiene', icon: 'broom' },
        { key: 'communication_documentation', title: 'Communication & Documentation', icon: 'file-alt' },
        { key: 'additional_checks', title: 'Additional Checks', icon: 'tasks' }
    ];
    
    // Add each inspection section that has data
    inspectionSections.forEach(section => {
        if (record[section.key]) {
            // Check if the data is a string that might be JSON
            let items = record[section.key];
            
            try {
                // Try to parse if it's a JSON string
                if (typeof items === 'string') {
                    items = JSON.parse(items);
                }
                
                // Only add section if there are items to display
                if (items && (Array.isArray(items) || typeof items === 'object')) {
                    html += createChecklistSection(section.title, items, section.icon);
                }
            } catch (e) {
                console.error(`Error processing ${section.key}:`, e);
                // If parsing fails but there's data, display it as is
                if (items && items.length > 0) {
                    html += createChecklistSection(section.title, {value: items}, section.icon);
                }
            }
        }
    });
    
    // Check if we have valid coordinates for the map
    const hasValidCoords = record.latitude && record.longitude && 
                         !isNaN(parseFloat(record.latitude)) && 
                         !isNaN(parseFloat(record.longitude));
    
    // Only show location section if we have either coordinates or address information
    if (hasValidCoords || record.check_in_address || record.check_out_address) {
        html += '<h5><i class="fas fa-map-marker-alt text-danger"></i> Location Information</h5>';
        
        // Only add the map container if we have valid coordinates
        if (hasValidCoords) {
            html += '<div id="attendanceMap" style="height: 300px; width: 100%; margin-bottom: 20px; border: 1px solid #dee2e6; border-radius: 8px; overflow: hidden; background-color: #f8f9fa; display: flex; align-items: center; justify-content: center; position: relative;">';
            html += '  <div id="mapLoading" class="text-muted"><i class="fas fa-map-marked-alt fa-2x mb-2"></i><div>Loading map...</div></div>';
            html += '  <div id="mapError" class="alert alert-warning m-0 d-none" style="position: absolute; top: 10px; left: 10px; right: 10px; z-index: 1000;"></div>';
            html += '</div>';
        } else {
            html += '<div class="alert alert-info mb-3">No map available - location coordinates are missing or invalid.</div>';
        }
    }
    
    // Add location details in a responsive grid
    html += '<div class="row mb-3">';
    html += '  <div class="col-md-6 mb-2">';
    html += '    <div class="d-flex align-items-center">';
    html += '      <div class="mr-2" style="width: 12px; height: 12px; background-color: #28a745; border-radius: 50%;"></div>';
    html += '      <div><strong>Check-in Location</strong></div>';
    html += '    </div>';
    html += '    <div class="pl-4 text-muted">';
    html += '      <small>Lat: ' + (record.latitude || 'N/A') + ', Lng: ' + (record.longitude || 'N/A') + '</small>';
    html += '    </div>';
    html += '  </div>';
    html += '  <div class="col-md-6 mb-2">';
    html += '    <div class="d-flex align-items-center">';
    html += '      <div class="mr-2" style="width: 12px; height: 12px; background-color: #dc3545; border-radius: 50%;"></div>';
    html += '      <div><strong>Check-out Location</strong></div>';
    html += '    </div>';
    html += '    <div class="pl-4 text-muted">';
    html += '      <small>Lat: ' + (record.checkout_latitude || 'N/A') + ', Lng: ' + (record.checkout_longitude || 'N/A') + '</small>';
    html += '    </div>';
    html += '  </div>';
    html += '</div>';
    
    html += '</div>';
    
    Swal.fire({
        title: 'Attendance Record Details',
        html: html,
        icon: 'info',
        showConfirmButton: false,
        showCloseButton: true,
        width: window.innerWidth > 768 ? '800px' : '95%',
        padding: '1rem',
        customClass: {
            popup: 'swal-responsive',
            htmlContainer: 'swal-html-responsive',
            closeButton: 'swal-close-button'
        },
        didOpen: () => {
            // Ensure modal stays within viewport
            const modal = document.querySelector('.swal2-popup');
            if (modal) {
                modal.style.maxHeight = '90vh';
                modal.style.overflowY = 'auto';
                modal.style.paddingBottom = '20px'; // Add padding at bottom
            }
            
            // Initialize map if container exists
            const mapElement = document.getElementById('attendanceMap');
            if (mapElement) {
                // Add a small delay to ensure the map container is visible
                setTimeout(() => {
                    initAttendanceMap(record);
                }, 100);
            }
            
            // Style the close button
            const closeBtn = document.querySelector('.swal2-close');
            if (closeBtn) {
                closeBtn.innerHTML = '×';
                closeBtn.style.fontSize = '2rem';
                closeBtn.style.fontWeight = 'bold';
                closeBtn.style.color = '#999';
                closeBtn.style.background = 'none';
                closeBtn.style.border = 'none';
                closeBtn.style.position = 'absolute';
                closeBtn.style.top = '10px';
                closeBtn.style.right = '15px';
                closeBtn.style.cursor = 'pointer';
                closeBtn.style.zIndex = '9999';
                closeBtn.title = 'Close';
            }
        }
    });
}

// Initialize the attendance map with location data
function initAttendanceMap(record) {
    try {
        // Hide loading message and clear any previous errors
        document.getElementById('mapLoading').style.display = 'none';
        const mapError = document.getElementById('mapError');
        mapError.classList.add('d-none');
        
        // Check for valid Check-In coordinates (latitude and longitude)
        const hasCheckinLocation = record.latitude && record.longitude && 
                          !isNaN(parseFloat(record.latitude)) && 
                          !isNaN(parseFloat(record.longitude));
        
        // Check for valid Check-Out coordinates (checkout_latitude and checkout_longitude)
        const hasCheckoutLocation = record.checkout_latitude && record.checkout_longitude && 
                          !isNaN(parseFloat(record.checkout_latitude)) && 
                          !isNaN(parseFloat(record.checkout_longitude));
        
        // If no valid location, show error and return
        if (!hasCheckinLocation) {
            mapError.textContent = 'No check-in location data available for this record';
            mapError.classList.remove('d-none');
            document.getElementById('attendanceMap').style.display = 'none';
            return;
        }
        
        // Set the map center to the check-in coordinates
        const checkinCoords = [parseFloat(record.latitude), parseFloat(record.longitude)];
        const zoom = 14; // Closer zoom level to show location name clearly
        
        // Initialize map
        const map = L.map('attendanceMap').setView(checkinCoords, zoom);
        
        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);
        
        // Add Check-In marker (green)
        L.circleMarker(checkinCoords, {
            color: '#28a745',
            fillColor: '#28a745',
            fillOpacity: 0.8,
            radius: 10,
            weight: 3
        }).addTo(map)
        .bindPopup('<b style="color: #28a745;"><i class="fas fa-sign-in-alt"></i> Check-In Location</b><br>' + 
                   'Date: ' + (record.check_in_date || 'N/A') + '<br>' +
                   'Time: ' + (record.check_in_time || 'N/A') + '<br>' +
                   'Coords: ' + record.latitude + ', ' + record.longitude);
        
        // Prepare bounds to fit both markers
        const bounds = L.latLngBounds([checkinCoords]);
        
        // Add Check-Out marker (red) if exists
        if (hasCheckoutLocation) {
            const checkoutCoords = [parseFloat(record.checkout_latitude), parseFloat(record.checkout_longitude)];
            
            L.circleMarker(checkoutCoords, {
                color: '#dc3545',
                fillColor: '#dc3545',
                fillOpacity: 0.8,
                radius: 10,
                weight: 3
            }).addTo(map)
            .bindPopup('<b style="color: #dc3545;"><i class="fas fa-sign-out-alt"></i> Check-Out Location</b><br>' + 
                       'Date: ' + (record.check_out_date || 'N/A') + '<br>' +
                       'Time: ' + (record.check_out_time || 'N/A') + '<br>' +
                       'Coords: ' + record.checkout_latitude + ', ' + record.checkout_longitude);
            
            // Extend bounds to include checkout location
            bounds.extend(checkoutCoords);
        }
        
        // Fit bounds to show all markers with padding
        map.fitBounds(bounds.pad(0.1));
        
        // Add a legend
        const legend = L.control({ position: 'bottomright' });
        legend.onAdd = function() {
            const div = L.DomUtil.create('div', 'info legend');
            div.style.backgroundColor = 'white';
            div.style.padding = '10px';
            div.style.borderRadius = '4px';
            div.style.boxShadow = '0 0 15px rgba(0,0,0,0.1)';
            div.style.fontSize = '13px';
            div.style.lineHeight = '1.6';
            
            let legendHTML = '<i style="background: #28a745; width: 12px; height: 12px; display: inline-block; border-radius: 50%; margin-right: 5px;"></i> <strong>Check-In</strong><br>';
            
            if (hasCheckoutLocation) {
                legendHTML += '<i style="background: #dc3545; width: 12px; height: 12px; display: inline-block; border-radius: 50%; margin-right: 5px;"></i> <strong>Check-Out</strong>';
            }
            
            div.innerHTML = legendHTML;
            return div;
        };
        legend.addTo(map);
        
    } catch (error) {
        console.error('Error initializing map:', error);
        const mapError = document.getElementById('mapError');
        mapError.textContent = 'Error loading map: ' + (error.message || 'Unknown error');
        mapError.classList.remove('d-none');
        document.getElementById('mapLoading').style.display = 'none';
    }
}

// Show photo in popup
function viewPhoto(photoPath) {
    if (!photoPath) {
        Swal.fire('Error', 'No photo available', 'error');
        return;
    }
    
    Swal.fire({
        title: '<i class="fas fa-camera me-2"></i> Driver Selfie',
        html: `
            <div class="text-center">
                <div class="position-relative d-inline-block mb-3">
                    <img src="{{ url('upload/driver/selfie/') }}/${photoPath}" 
                         class="img-fluid rounded shadow" 
                         style="max-width: 100%; max-height: 70vh;" 
                         alt="Driver Selfie"
                         onerror="this.onerror=null; this.src='{{ asset('images/default-avatar.png') }}'"
                    >
                    <span class="position-absolute top-0 end-0 bg-primary text-white rounded-circle p-2" 
                          style="transform: translate(30%, -30%); box-shadow: 0 2px 5px rgba(0,0,0,0.2);">
                        <i class="fas fa-camera"></i>
                    </span>
                </div>
                <div class="text-muted small mt-2">
                    <i class="far fa-clock me-1"></i> ${new Date().toLocaleString()}
                </div>
            </div>
        `,
        showConfirmButton: false,
        showCloseButton: true,
        width: window.innerWidth > 768 ? '600px' : '95%',
        customClass: {
            popup: 'swal-responsive',
            closeButton: 'swal-close-button',
            title: 'd-flex align-items-center'
        },
        didOpen: () => {
            // Style the close button
            const closeBtn = document.querySelector('.swal2-close');
            if (closeBtn) {
                closeBtn.innerHTML = '×';
                closeBtn.style.fontSize = '2rem';
                closeBtn.style.fontWeight = 'bold';
                closeBtn.style.color = '#999';
                closeBtn.style.background = 'none';
                closeBtn.style.border = 'none';
                closeBtn.style.position = 'absolute';
                closeBtn.style.top = '10px';
                closeBtn.style.right = '15px';
                closeBtn.style.cursor = 'pointer';
                closeBtn.style.zIndex = '9999';
                closeBtn.title = 'Close';
            }
        }
    });
}
</script>

<style>
/* Responsive Modal Styles */
.swal-responsive {
    max-height: 90vh !important;
    margin: 1rem !important;
}

/* Close Button Styles */
.swal2-close {
    position: absolute !important;
    top: 10px !important;
    right: 15px !important;
    width: 30px !important;
    height: 30px !important;
    font-size: 2rem !important;
    font-weight: bold !important;
    color: #999 !important;
    background: none !important;
    border: none !important;
    cursor: pointer !important;
    z-index: 9999 !important;
    line-height: 1 !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    border-radius: 50% !important;
    transition: all 0.2s ease !important;
}

.swal2-close:hover {
    background: #f0f0f0 !important;
    color: #333 !important;
    transform: scale(1.1) !important;
}

.swal2-close:focus {
    outline: none !important;
    box-shadow: 0 0 0 2px rgba(0,123,255,0.25) !important;
}

.swal-html-responsive {
    max-height: 65vh !important;
    overflow-y: auto !important;
    text-align: left !important;
}

/* Mobile Responsive */
@media (max-width: 768px) {
    .swal-responsive {
        width: 95% !important;
        margin: 0.5rem !important;
        font-size: 0.9rem !important;
    }
    
    .swal-html-responsive {
        max-height: 60vh !important;
        padding: 0.5rem !important;
    }
    
    .swal-html-responsive .row {
        margin: 0 !important;
    }
    
    .swal-html-responsive .col-6 {
        padding: 0.25rem !important;
        font-size: 0.85rem !important;
    }
}

/* Table Styles */
.table-sm th,
.table-sm td {
    padding: 0.3rem !important;
    font-size: 0.875rem;
    vertical-align: middle !important;
}

.badge-sm {
    font-size: 0.75rem !important;
}

/* Button Styles */
.btn-xs {
    padding: 0.15rem 0.4rem !important;
    font-size: 0.7rem !important;
    line-height: 1.2 !important;
}

/* Responsive Table */
@media (max-width: 768px) {
    .table-responsive {
        font-size: 0.8rem !important;
    }
    
    .table-sm th,
    .table-sm td {
        padding: 0.2rem !important;
        font-size: 0.8rem !important;
    }
}
</style>
@endpush
