@extends('admin-v1.layouts.header')
@section('content')
    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Monthly Report Header -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-chart-bar mr-2"></i>
                                Monthly Attendance Report - {{ $driver->first_name }} {{ $driver->last_name }}
                            </h3>
                            <div class="card-tools">
                                <form method="GET" class="d-inline-flex align-items-center mr-3">
                                    <label for="month" class="mr-2 mb-0">Month:</label>
                                    <input type="month" name="month" id="month" class="form-control form-control-sm" 
                                           value="{{ $month }}" onchange="this.form.submit()">
                                </form>
                                <a href="{{ route('admin-v1.drivers.attendance.calendar', $driver->id) }}?month={{ $month }}" class="btn btn-sm btn-warning">
                                    <i class="fas fa-calendar-alt"></i> Calendar View
                                </a>
                                <a href="{{ route('admin-v1.drivers.attendance', $driver->id) }}" class="btn btn-sm btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Attendance
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Driver Information -->
                            <div class="row mb-4">
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-primary"><i class="fas fa-user"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Driver</span>
                                            <span class="info-box-number">{{ $driver->first_name }} {{ $driver->last_name }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-info"><i class="fas fa-phone"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Mobile</span>
                                            <span class="info-box-number">{{ $driver->mobile }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-success"><i class="fas fa-calendar"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Report Month</span>
                                            <span class="info-box-number">{{ \Carbon\Carbon::parse($month)->format('M Y') }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-warning"><i class="fas fa-building"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">City</span>
                                            <span class="info-box-number">{{ $driver->city ?? 'N/A' }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Statistics Cards -->
            <div class="row">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>{{ $totalCheckIns }}</h3>
                            <p>Total Check-Ins</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-sign-in-alt"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{ $totalCheckOuts }}</h3>
                            <p>Total Check-Outs</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-sign-out-alt"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>{{ $totalWorkingHours }}h</h3>
                            <p>Total Working Hours</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3>{{ $averageDailyHours }}h</h3>
                            <p>Average Daily Hours</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Attendance Summary -->
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-calendar-check mr-2"></i>Attendance Summary
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <div class="description-block border-right">
                                        <span class="description-percentage text-success">
                                            <i class="fas fa-check"></i> {{ $daysPresent }}
                                        </span>
                                        <h5 class="description-header">Days Present</h5>
                                        <span class="description-text">Out of {{ $totalDaysInMonth }} days</span>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="description-block">
                                        <span class="description-percentage text-danger">
                                            <i class="fas fa-times"></i> {{ $daysAbsent }}
                                        </span>
                                        <h5 class="description-header">Days Absent</h5>
                                        <span class="description-text">{{ round(($daysAbsent / $totalDaysInMonth) * 100, 1) }}% of month</span>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Attendance Rate Progress Bar -->
                            <div class="mt-3">
                                <div class="progress-group">
                                    <span class="float-right"><b>{{ $daysPresent }}</b>/{{ $totalDaysInMonth }}</span>
                                    <span class="progress-text">Attendance Rate</span>
                                    <div class="progress progress-sm">
                                        <div class="progress-bar bg-success" style="width: {{ ($daysPresent / $totalDaysInMonth) * 100 }}%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-clock mr-2"></i>Working Hours Analysis
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <div class="description-block border-right">
                                        <span class="description-percentage text-primary">
                                            <i class="fas fa-clock"></i> {{ $totalWorkingHours }}h
                                        </span>
                                        <h5 class="description-header">Total Hours</h5>
                                        <span class="description-text">This month</span>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="description-block">
                                        <span class="description-percentage text-info">
                                            <i class="fas fa-chart-line"></i> {{ $averageDailyHours }}h
                                        </span>
                                        <h5 class="description-header">Average Daily</h5>
                                        <span class="description-text">Per working day</span>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Working Hours Progress -->
                            <div class="mt-3">
                                @php
                                    $expectedHours = $daysPresent * 8; // Assuming 8 hours per day
                                    $hoursPercentage = $expectedHours > 0 ? min(($totalWorkingHours / $expectedHours) * 100, 100) : 0;
                                @endphp
                                <div class="progress-group">
                                    <span class="float-right"><b>{{ $totalWorkingHours }}</b>/{{ $expectedHours }}h</span>
                                    <span class="progress-text">Expected Hours (8h/day)</span>
                                    <div class="progress progress-sm">
                                        <div class="progress-bar bg-{{ $hoursPercentage >= 80 ? 'success' : ($hoursPercentage >= 60 ? 'warning' : 'danger') }}" 
                                             style="width: {{ $hoursPercentage }}%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Detailed Records -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-list mr-2"></i>Detailed Attendance Records
                            </h3>
                        </div>
                        <div class="card-body">
                            @if($attendanceRecords->count() > 0)
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-sm">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Day</th>
                                                <th>Plant Name</th>
                                                <th>Shift Type</th>
                                                <th>Check In</th>
                                                <th>Check Out</th>
                                                <th>Total Hours</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($attendanceRecords as $record)
                                                <tr>
                                                    <td>
                                                        <strong>{{ \Carbon\Carbon::parse($record->check_in_date)->format('d M Y') }}</strong>
                                                    </td>
                                                    <td>
                                                        <span class="badge badge-light">{{ \Carbon\Carbon::parse($record->check_in_date)->format('D') }}</span>
                                                    </td>
                                                    <td>{{ $record->plant_name ?? 'N/A' }}</td>
                                                    <td>
                                                        @if($record->shift_type)
                                                            <span class="badge badge-info">{{ ucfirst($record->shift_type) }}</span>
                                                        @else
                                                            <span class="text-muted">N/A</span>
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if($record->check_in_time)
                                                            <strong class="text-success">{{ $record->check_in_time }}</strong>
                                                        @else
                                                            <span class="text-muted">N/A</span>
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if($record->check_out_time)
                                                            <strong class="text-danger">{{ $record->check_out_time }}</strong>
                                                        @else
                                                            <span class="badge badge-warning">Pending</span>
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if($record->check_in_date && $record->check_in_time && $record->check_out_date && $record->check_out_time)
                                                            @php
                                                                $checkIn = \Carbon\Carbon::parse($record->check_in_date . ' ' . $record->check_in_time);
                                                                $checkOut = \Carbon\Carbon::parse($record->check_out_date . ' ' . $record->check_out_time);
                                                                $totalHours = $checkOut->diffInHours($checkIn);
                                                                $totalMinutes = $checkOut->diffInMinutes($checkIn) % 60;
                                                            @endphp
                                                            <span class="badge badge-success">{{ $totalHours }}h {{ $totalMinutes }}m</span>
                                                        @else
                                                            <span class="text-muted">-</span>
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if($record->check_in_date && $record->check_out_date)
                                                            <span class="badge badge-success">Complete</span>
                                                        @elseif($record->check_in_date)
                                                            <span class="badge badge-warning">Incomplete</span>
                                                        @else
                                                            <span class="badge badge-danger">Absent</span>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            @else
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle mr-2"></i>
                                    No attendance records found for {{ \Carbon\Carbon::parse($month)->format('F Y') }}.
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Main Content  -->
@endsection

@push('scripts')
<script>
$(document).ready(function() {
    // Initialize DataTable if there are records
    @if($attendanceRecords->count() > 0)
        $('.table').DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
            "ordering": true,
            "info": true,
            "paging": false,
            "searching": false,
            "order": [[ 0, "asc" ]]
        });
    @endif
});
</script>

<style>
.description-block {
    text-align: center;
    padding: 15px;
}

.description-header {
    font-size: 16px;
    margin: 10px 0 5px 0;
    padding: 0;
    font-weight: 600;
    color: #444;
}

.description-text {
    font-size: 13px;
    color: #999;
}

.description-percentage {
    font-size: 20px;
    font-weight: bold;
}

.border-right {
    border-right: 1px solid #f0f0f0;
}

.progress-group {
    margin-bottom: 15px;
}

.progress-text {
    font-size: 13px;
    font-weight: 600;
}

.small-box {
    border-radius: 10px;
    box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    margin-bottom: 20px;
}

.small-box .inner {
    padding: 15px;
}

.small-box .inner h3 {
    font-size: 2.2rem;
    font-weight: bold;
    margin: 0 0 10px 0;
    white-space: nowrap;
    padding: 0;
}

.small-box .inner p {
    font-size: 15px;
    margin: 0;
}

.small-box .icon {
    color: rgba(0,0,0,0.15);
    z-index: 0;
}

.small-box .icon > i {
    font-size: 70px;
    position: absolute;
    right: 15px;
    top: 15px;
    transition: all .3s linear;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .small-box .inner h3 {
        font-size: 1.8rem;
    }
    
    .small-box .icon > i {
        font-size: 50px;
    }
    
    .description-header {
        font-size: 14px;
    }
    
    .description-percentage {
        font-size: 18px;
    }
}
</style>
@endpush
