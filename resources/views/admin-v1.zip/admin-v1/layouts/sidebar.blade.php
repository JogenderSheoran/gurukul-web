<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-light elevation-4">
    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
           
                @if(Auth::user()->isAdmin())
                    <!-- Admin Dashboard -->
                    <li class="nav-item">
                        <a href="{{ route('admin-v1.dashboard') }}" class="nav-link">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                @elseif(Auth::user()->isDriverManager())
                    <!-- Driver Manager Dashboard - Only Driver Related Dashboard -->
                    <li class="nav-item">
                        <a href="{{ route('admin-v1.driver-manager.dashboard') }}" class="nav-link">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                @endif
               
                @if(Auth::user()->isAdmin())
                    <!-- Website Leads Module -->
                    <li class="nav-item">
                        <a href="{{ route('admin-v1.wordpress-leads') }}" class="nav-link">
                            <i class="nav-icon fas fa-globe"></i>
                            <p>Website Leads</p>
                        </a>
                    </li>

                    <!-- Users Module -->
                    <li class="nav-item">
                        <a href="{{ route('admin-v1.users') }}" class="nav-link">
                            <i class="nav-icon fas fa-users"></i>
                            <p>Users</p>
                        </a>
                    </li>
                @endif
                @if(Auth::user()->isAdmin())
                    <!-- Admin sees full drivers module -->
                    <li class="nav-item has-treeview">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-car"></i>
                            <p>
                                Drivers Management
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.drivers') }}" class="nav-link">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>View Drivers</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.drivers.create') }}" class="nav-link">
                                    <i class="fas fa-plus nav-icon"></i>
                                    <p>Add Driver</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.drivers.locations') }}" class="nav-link">
                                    <i class="fas fa-map-marker-alt nav-icon"></i>
                                    <p>Driver Locations</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                @elseif(Auth::user()->isDriverManager())
                    <!-- Driver Manager sees specific drivers module -->
                    <li class="nav-item has-treeview">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-users"></i>
                            <p>
                                Drivers
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.drivers') }}" class="nav-link">
                                    <i class="fas fa-eye nav-icon"></i>
                                    <p>View Driver</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.drivers.create') }}" class="nav-link">
                                    <i class="fas fa-plus nav-icon"></i>
                                    <p>Add Driver</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.driver-manager.check-in-out') }}" class="nav-link">
                                    <i class="fas fa-clock nav-icon"></i>
                                    <p>Check-in / Check-out</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.driver-manager.attendance-overview') }}" class="nav-link">
                                    <i class="fas fa-chart-bar nav-icon"></i>
                                    <p>Attendance System</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                @endif



                <!-- Admin-only modules -->
                @if(Auth::user()->isAdmin())
                    <!-- Driver Attendance for Admin -->
                    <li class="nav-item has-treeview">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-calendar-check"></i>
                            <p>
                                Driver Attendance
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.driver-manager.attendance-overview') }}" class="nav-link">
                                    <i class="fas fa-chart-bar nav-icon"></i>
                                    <p>Attendance Overview</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.driver-manager.check-in-out') }}" class="nav-link">
                                    <i class="fas fa-clock nav-icon"></i>
                                    <p>Check-in Management</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                @endif

                @if(Auth::user()->isAdmin() || Auth::user()->isDriverManager())
                    <!-- Groups Module -->
                    <li class="nav-item">
                        <a href="{{ route('admin-v1.groups') }}" class="nav-link">
                            <i class="nav-icon fas fa-layer-group"></i>
                            <p>Groups</p>
                        </a>
                    </li>

                    <!-- Driver Notifications Module -->
                     <li class="nav-item">
                        <a href="{{ route('admin-v1.driver-notifications.index') }}" class="nav-link">
                            <i class="nav-icon fas fa-bell"></i>
                            <p>Driver Notifications</p>
                        </a>
                    </li> 
                @endif

                @if(Auth::user()->isAdmin())
                    <!-- Rides Module -->
                    <li class="nav-item">
                        <a href="{{ route('admin-v1.rides') }}" class="nav-link">
                            <i class="nav-icon fas fa-route"></i>
                            <p>Rides</p>
                        </a>
                    </li>

                    <!-- IVR Leads Module -->
                    <li class="nav-item has-treeview">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-phone-alt"></i>
                            <p>
                                IVR Leads
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.ivr-leads') }}" class="nav-link">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>All Leads</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('admin-v1.ivr-leads-stats') }}" class="nav-link">
                                    <i class="far fa-chart-bar nav-icon"></i>
                                    <p>Statistics & Analytics</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                @endif
            </ul>
        </nav>
    </div>
    <!--
 /.sidebar -->
</aside>
